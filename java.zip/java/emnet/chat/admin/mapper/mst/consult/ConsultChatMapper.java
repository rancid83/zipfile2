package emnet.chat.admin.mapper.mst.consult;

import emnet.chat.admin.domain.common.UserInfoVO;
import emnet.chat.admin.domain.consult.*;
import org.springframework.stereotype.Repository;

import java.util.ArrayList;
import java.util.List;

@Repository
public interface ConsultChatMapper {
    public ArrayList<MacroVO> selectHotKeyList(MacroVO params);

    public ArrayList<ResGetCustomerHisVO> selectCustomerHisList(ReqGetCustomerHisVO params);

    public ArrayList<KeywordCategoryVO> selectAllKeywordCategoryList();

    public ArrayList<ComCodeVO> selectComCodeByCateCd(String cateCd);

    public ComCodeVO selectComCode (ComCodeVO params);

    public ArrayList<ResGetConsultVO> selectConsultList(ReqGetConsultVO params);

    public ResGetConsultStateCountVO selectConsultStateCount(ReqGetConsultStateCountVO params);

    public ArrayList<ResGetKeywordVO> selectKeywordList(ReqGetKeywordVO params);

    public ArrayList<ResGetChatContentVO> selectChatContentList(ReqGetChatContentVO params);

    public ArrayList<ResGetResetChatRoomVO> selectResetChatRoomList(ReqGetResetChatRoomVO params);

    public ResGetPopupInitDataVO selectCounselorInfo(ReqGetPopupInitDataVO params);

    public List<ComComboVO> selectCategorySkillComboList(ReqGetPopupInitDataVO params);

    public List<ComComboVO> selectSkillMappedUserList(ReqGetSkillMappedUserVO params);

    public void updateChangeReq(ReqModifyChangeReqVO params);

    public List<ComComboVO> selectDepartmentComboList(ReqGetDepartmentComboVO params);

    public List<ComComboVO>  selectUserComboList(ReqGetUserComboVO params);

    public void insertBlackList(ReqAddBlackListVO params);

    public ResGetUserChatStateVO selectUserChatState(ReqUserChatStateVO params);

    public void updateUserDistribute(ReqModifyUserDistributeVO params);

    public void updateUserWorkState(UserWorkStateVO params);

    public WorkStateHistoryVO selectLastWorkHistoryByState(UserWorkStateVO params);

    public void insertWorkStateHistory(UserWorkStateVO params);

    public void updateWorkStateHistoryEndDt(WorkStateHistoryVO workStateHistory);

    public List<ConsultMenuVO> selectPermissionMenuByPNo(ReqGetMenuInfoVO params);

    public void insertMacro(MacroVO params);

    public void updateMacro(MacroVO params);

    public void deleteMacro(MacroVO params);

    public void insertChatContentHisLog(ReqGetChatContentVO params);

    public ConsultInfoVO selectConsultInfo(ConsultInfoVO params);

    public int selectUserChatRoomCount(UserInfoVO params);


}
