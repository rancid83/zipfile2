package emnet.chat.admin.mapper.mst.system;

import java.util.ArrayList;
import java.util.List;

import emnet.chat.admin.domain.common.ComCodeDtlVO;
import emnet.chat.admin.domain.common.ComCodeMstVO;
import org.springframework.stereotype.Repository;

@Repository
public interface ComCodeMapper {
	
	public List<ComCodeMstVO> selectComCodeGroupList(ComCodeMstVO param);

	public int insertComCodeMst(ComCodeMstVO param);

	public int updateComCodeMst(ComCodeMstVO param);

	public int deleteComCodeMst(ComCodeMstVO param);


	public ArrayList<ComCodeDtlVO> selectComCodeList(ComCodeDtlVO codeVO);


	public int insertComCode(ComCodeDtlVO param);

	public int updateComCode(ComCodeDtlVO param);

	public int deleteComCode(ComCodeDtlVO param);
}
