package emnet.chat.admin.mapper.mst.system;

public interface RequestLogMapper {
}
