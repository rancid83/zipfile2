package emnet.chat.admin.mapper.mst.system;

import java.util.List;

import emnet.chat.admin.domain.common.ColumnVO;
import org.springframework.stereotype.Repository;


public interface ColumnMapper {
	/**
	 * DB에 할당된 테이블 및 컬럼 리스트 리턴
	 * @param columnVO
	 * @return
	 */
	public List<ColumnVO> selectColumnList(ColumnVO columnVO);
}
