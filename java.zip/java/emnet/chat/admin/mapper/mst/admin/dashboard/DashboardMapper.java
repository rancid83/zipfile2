package emnet.chat.admin.mapper.mst.admin.dashboard;


import emnet.chat.admin.domain.admin.dashboard.*;
import org.springframework.stereotype.Repository;

import java.util.ArrayList;

@Repository
public interface DashboardMapper {

    ArrayList<ResDashboardSummaryVO> selectDailySummary(ReqDashboardVO dashboardVO);

    ArrayList<ResDashboardUserVO> selectDailyUser(ReqDashboardVO dashboardVO);

    ArrayList<ResDashboardHourVO> selectHour(ReqDashboardVO dashboardVO);

    ArrayList<ResDashboardDailyVO> selectDaily(ReqDashboardVO dashboardVO);

    ArrayList<ResDashboardHourVO> selectHourUser(ReqDashboardVO dashboardVO);

}
