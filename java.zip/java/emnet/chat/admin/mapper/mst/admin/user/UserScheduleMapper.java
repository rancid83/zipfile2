package emnet.chat.admin.mapper.mst.admin.user;

import emnet.chat.admin.domain.admin.user.userSchedule.ReqUserScheduleEtcVO;
import emnet.chat.admin.domain.admin.user.userSchedule.ReqUserScheduleVO;
import emnet.chat.admin.domain.admin.user.userSchedule.ResUserScheduleEtcVO;
import emnet.chat.admin.domain.admin.user.userSchedule.ResUserScheduleVO;
import org.springframework.stereotype.Repository;

import java.util.ArrayList;
import java.util.List;


@Repository
public interface UserScheduleMapper {


    public List<ResUserScheduleVO> selectUserScheduleList(ReqUserScheduleVO param);

    public int insertUserSchedule(ReqUserScheduleVO param);

    public int updateUserSchedule(ReqUserScheduleVO param);

    public int deleteUserSchedule(ReqUserScheduleVO param);

    public ArrayList<ResUserScheduleEtcVO> selectUserScheduleEtcList(ReqUserScheduleEtcVO scheduleVO);


    public int insertUserScheduleEtc(ReqUserScheduleEtcVO param);

    public int updateUserScheduleEtc(ReqUserScheduleEtcVO param);

    public int deleteUserScheduleEtc(ReqUserScheduleEtcVO param);
}
