package emnet.chat.admin.mapper.mst.admin.consult;

import emnet.chat.admin.domain.admin.consult.ReqConsultConfQuestionVO;
import emnet.chat.admin.domain.admin.consult.ReqConsultVipVO;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface ConsultConfQuestionMapper {

    public List<ReqConsultConfQuestionVO> selectConsultConfQuestionList(ReqConsultConfQuestionVO param);

    public int insertConsultConfQuestion(ReqConsultConfQuestionVO param);

    public int updateConsultConfQuestion(ReqConsultConfQuestionVO param);

    public int deleteConsultConfQuestion(ReqConsultConfQuestionVO param);

}
