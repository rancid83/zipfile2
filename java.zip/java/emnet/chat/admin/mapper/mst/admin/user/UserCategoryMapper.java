package emnet.chat.admin.mapper.mst.admin.user;

import emnet.chat.admin.domain.admin.user.userCategory.ReqUserCategoryVO;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface UserCategoryMapper {

    public List<ReqUserCategoryVO> selectUserCategoryList(ReqUserCategoryVO param);

    public int insertUserCategory(ReqUserCategoryVO param);

    public int updateUserCategory(ReqUserCategoryVO param);

    public int deleteUserCategory(ReqUserCategoryVO param);

}
