package emnet.chat.admin.mapper.mst.admin.statistics;

import emnet.chat.admin.domain.admin.statistics.ReqStatNotAccessVO;
import emnet.chat.admin.domain.admin.statistics.ResStatNotAccessVO;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface StatNotAccessMapper {

    public List<ResStatNotAccessVO> selectStatNotAccessList(ReqStatNotAccessVO param);
    public List<ResStatNotAccessVO> selectStatNotAccessSummaryList(ReqStatNotAccessVO param);
}
