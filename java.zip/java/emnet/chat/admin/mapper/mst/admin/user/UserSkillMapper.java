package emnet.chat.admin.mapper.mst.admin.user;

import emnet.chat.admin.domain.admin.user.userRest.ReqUserRestVO;
import emnet.chat.admin.domain.admin.user.userSkill.ReqUserSkillVO;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface UserSkillMapper {

    public List<ReqUserSkillVO> selectUserSkillList(ReqUserSkillVO param);

    public int insertUserSkill(ReqUserSkillVO param);

    public int updateUserSkill(ReqUserSkillVO param);

    public int deleteUserSkill(ReqUserSkillVO param);

}
