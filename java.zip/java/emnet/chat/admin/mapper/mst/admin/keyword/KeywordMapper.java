package emnet.chat.admin.mapper.mst.admin.keyword;

import emnet.chat.admin.domain.admin.keyword.ReqKeywordVO;
import emnet.chat.admin.domain.admin.keyword.ResKeywordVO;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface KeywordMapper {

    public List<ResKeywordVO> selectKeywordList(ReqKeywordVO param);

    public int insertKeyword(ReqKeywordVO param);

    public int updateKeyword(ReqKeywordVO param);

    public int deleteKeyword(ReqKeywordVO param);

}
