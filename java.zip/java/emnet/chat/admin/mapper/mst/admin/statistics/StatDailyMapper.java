package emnet.chat.admin.mapper.mst.admin.statistics;

import emnet.chat.admin.domain.admin.statistics.ReqStatDailyVO;
import emnet.chat.admin.domain.admin.statistics.ResStatDailyVO;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface StatDailyMapper {

    public List<ResStatDailyVO> selectStatDailyList(ReqStatDailyVO param);
    public List<ResStatDailyVO> selectStatDailySummaryList(ReqStatDailyVO param);
}
