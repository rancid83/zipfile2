package emnet.chat.admin.mapper.mst.admin.statistics;

import emnet.chat.admin.domain.admin.statistics.ReqStatSkillVO;
import emnet.chat.admin.domain.admin.statistics.ResStatSkillVO;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface StatSkillMapper {

    public List<ResStatSkillVO> selectStatSkillList(ReqStatSkillVO param);
    public List<ResStatSkillVO> selectStatSkillSummaryList(ReqStatSkillVO param);
}
