package emnet.chat.admin.mapper.mst.admin.user;

import emnet.chat.admin.domain.admin.user.userRest.ReqUserRestVO;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface UserRestMapper {

    public List<ReqUserRestVO> selectUserRestList(ReqUserRestVO param);

    public int insertUserRest(ReqUserRestVO param);

    public int updateUserRest(ReqUserRestVO param);

    public int deleteUserRest(ReqUserRestVO param);

}
