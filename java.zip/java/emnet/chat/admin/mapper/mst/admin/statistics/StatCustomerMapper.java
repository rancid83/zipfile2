package emnet.chat.admin.mapper.mst.admin.statistics;

import emnet.chat.admin.domain.admin.statistics.ReqStatCustomerVO;
import emnet.chat.admin.domain.admin.statistics.ReqStatWorkUserVO;
import emnet.chat.admin.domain.admin.statistics.ResStatCustomerVO;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface StatCustomerMapper {

    public List<ResStatCustomerVO> selectStatCustomerList(ReqStatCustomerVO param);

}
