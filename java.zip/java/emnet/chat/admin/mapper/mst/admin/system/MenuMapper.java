package emnet.chat.admin.mapper.mst.admin.system;

import emnet.chat.admin.domain.admin.menu.ReqMenuLevelVO;
import emnet.chat.admin.domain.admin.menu.ReqMenuPermissionMappingVO;
import emnet.chat.admin.domain.admin.menu.ReqPermissionMenuVO;
import emnet.chat.admin.domain.admin.menu.ResPermissionMenuVO;
import emnet.chat.admin.domain.admin.system.RspMenuVO;
import org.springframework.stereotype.Repository;

import java.util.ArrayList;
import java.util.List;

@Repository
public interface MenuMapper {

	// 시스템에 등록된 메뉴리스트 리턴 ( 메뉴 전체 목록 )
	ArrayList<ReqMenuLevelVO> selectMenuList(ReqMenuLevelVO param);

	// 권한에 등록된 메뉴리스트 리턴 (Admin Portal 메뉴리스트 )
	ArrayList<ResPermissionMenuVO> selectPermissionMenu(ReqPermissionMenuVO param);

	// 권한에 등록된 메뉴리스트 리턴 (메뉴권한 전체 )
	ArrayList<ResPermissionMenuVO> selectPermissionMappingMenuList(ReqPermissionMenuVO param);

	List<RspMenuVO> selectChildMenuList(int parentMenuNo);

	// 해당 권한에 등록된 메뉴권한 전체  삭제
	void deleteAllPermissionMenu(ReqMenuPermissionMappingVO param);

	// 해당 권한에 메뉴 등록
	void insertPermissionMenu(ReqMenuPermissionMappingVO param);

	void deletePermissionMapping(ReqMenuPermissionMappingVO param);

	void insertPermissionMapping(ReqMenuPermissionMappingVO param);

	void insertMenu(RspMenuVO param);

	String selectMenuViewIdByMenuUrl(RspMenuVO param);


	ArrayList<ReqPermissionMenuVO> selectMenuByNo(ReqPermissionMenuVO param);



	ArrayList<ReqPermissionMenuVO> selectMenuPermissionByUserNoMenuUrl(ReqPermissionMenuVO param);

}
