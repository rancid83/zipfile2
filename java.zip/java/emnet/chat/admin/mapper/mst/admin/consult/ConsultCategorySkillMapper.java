package emnet.chat.admin.mapper.mst.admin.consult;

import emnet.chat.admin.domain.admin.consult.ReqConsultCategorySkillVO;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface ConsultCategorySkillMapper {


    public List<ReqConsultCategorySkillVO> selectConsultCategorySkillList(ReqConsultCategorySkillVO param);

    public int insertConsultCategorySkill(ReqConsultCategorySkillVO param);

    public int updateConsultCategorySkill(ReqConsultCategorySkillVO param);

    public int deleteConsultCategorySkill(ReqConsultCategorySkillVO param);

}
