package emnet.chat.admin.mapper.mst.admin.consult;

import emnet.chat.admin.domain.admin.consult.ReqConsultVipVO;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface ConsultVipMapper {

    public List<ReqConsultVipVO> selectConsultVipList(ReqConsultVipVO param);

    public int insertVip(ReqConsultVipVO param);

    public int updateVip(ReqConsultVipVO param);

    public int deleteVip(ReqConsultVipVO param);

}
