package emnet.chat.admin.mapper.mst.admin.service;

import emnet.chat.admin.domain.admin.consult.ReqConsultVipVO;
import emnet.chat.admin.domain.admin.service.ResServiceScheduleVO;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface ServiceScheduleMapper {


    public List<ResServiceScheduleVO> selectServiceScheduleList(ResServiceScheduleVO param);

    public int insertServiceSchedule(ResServiceScheduleVO param);

    public int updateServiceSchedule(ResServiceScheduleVO param);

    public int deleteServiceSchedule(ResServiceScheduleVO param);

}
