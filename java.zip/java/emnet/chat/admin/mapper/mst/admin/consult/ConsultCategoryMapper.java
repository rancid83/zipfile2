package emnet.chat.admin.mapper.mst.admin.consult;

import emnet.chat.admin.domain.admin.consult.ReqConsultCategoryVO;
import emnet.chat.admin.domain.common.ComCodeMstVO;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface ConsultCategoryMapper {

    public List<ReqConsultCategoryVO> selectConsultCategoryList(ReqConsultCategoryVO param);

    public int insertConsultCategory(ReqConsultCategoryVO param);

    public int updateConsultCategory(ReqConsultCategoryVO param);

    public int deleteConsultCategory(ReqConsultCategoryVO param);

}
