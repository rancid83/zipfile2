package emnet.chat.admin.mapper.mst.admin.slang;

import emnet.chat.admin.domain.admin.slang.ReqSlangVO;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface SlangMapper {

    public List<ReqSlangVO> selectSlangList(ReqSlangVO param);

    public int insertSlang(ReqSlangVO param);

    public int updateSlang(ReqSlangVO param);

    public int deleteSlang(ReqSlangVO param);

}
