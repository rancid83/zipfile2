package emnet.chat.admin.mapper.mst.admin.statistics;

import emnet.chat.admin.domain.admin.statistics.ReqStatProductTermVO;
import emnet.chat.admin.domain.admin.statistics.ResStatProductTermVO;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface StatProductTermMapper {

    public List<ResStatProductTermVO> selectStatProductTermList(ReqStatProductTermVO param);

}
