package emnet.chat.admin.mapper.mst.admin.statistics;

import emnet.chat.admin.domain.admin.statistics.ReqStatProductTeamVO;
import emnet.chat.admin.domain.admin.statistics.ResStatProductTeamVO;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface StatProductTeamMapper {

    public List<ResStatProductTeamVO> selectStatProductTeamList(ReqStatProductTeamVO param);
    public List<ResStatProductTeamVO> selectStatProductTeamSummaryList(ReqStatProductTeamVO param);
}
