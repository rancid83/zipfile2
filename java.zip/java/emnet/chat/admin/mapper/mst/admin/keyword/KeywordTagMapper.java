package emnet.chat.admin.mapper.mst.admin.keyword;

import emnet.chat.admin.domain.admin.keyword.ReqKeywordTagVO;
import emnet.chat.admin.domain.admin.keyword.ReqKeywordVO;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface KeywordTagMapper {

    public List<ReqKeywordTagVO> selectKeywordTagList(ReqKeywordTagVO param);

    public int insertKeywordTag(ReqKeywordTagVO param);

    public int updateKeywordTag(ReqKeywordTagVO param);

    public int deleteKeywordTag(ReqKeywordTagVO param);

    public int deleteAll(ReqKeywordTagVO param);
}
