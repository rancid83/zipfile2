package emnet.chat.admin.mapper.mst.admin.statistics;

import emnet.chat.admin.domain.admin.statistics.ReqStatProductDailyVO;
import emnet.chat.admin.domain.admin.statistics.ResStatProductDailyVO;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface StatProductDailyMapper {

    public List<ResStatProductDailyVO> selectStatProductDailyList(ReqStatProductDailyVO param);

}
