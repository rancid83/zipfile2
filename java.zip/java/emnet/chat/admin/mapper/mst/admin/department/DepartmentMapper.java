package emnet.chat.admin.mapper.mst.admin.department;

import emnet.chat.admin.domain.admin.dept.ReqDepartmentVO;
import emnet.chat.admin.domain.common.ColumnVO;
import emnet.chat.admin.domain.common.ComCodeMstVO;
import org.springframework.stereotype.Repository;

import java.util.ArrayList;
import java.util.List;

@Repository
public interface DepartmentMapper {
	/**
	 * 조직코드 리턴
	 * @param departmentVO
	 * @return
	 */
	public ArrayList<ReqDepartmentVO> selectDepartmentList(ReqDepartmentVO departmentVO);


	public int insertDepartment(ReqDepartmentVO param);

	public int updateDepartment(ReqDepartmentVO param);

	public int deleteDepartment(ReqDepartmentVO param);
}
