package emnet.chat.admin.mapper.mst.admin.system;

import org.springframework.stereotype.Repository;

import java.util.HashMap;

@Repository
public interface AccessLogMapper {
    public void insertAccessLog(HashMap<String,Object> insertAccessLogParams);
}
