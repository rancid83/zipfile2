package emnet.chat.admin.mapper.mst.admin.holiday;

import emnet.chat.admin.domain.admin.consult.ReqConsultVipVO;
import emnet.chat.admin.domain.admin.holiday.ReqHolidayVO;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface HolidayMapper {

    public List<ReqHolidayVO> selectHolidayList(ReqHolidayVO param);

    public int insertHoliday(ReqHolidayVO param);

    public int updateHoliday(ReqHolidayVO param);

    public int deleteHoliday(ReqHolidayVO param);

}
