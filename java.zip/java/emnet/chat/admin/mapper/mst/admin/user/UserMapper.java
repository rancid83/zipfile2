package emnet.chat.admin.mapper.mst.admin.user;


import emnet.chat.admin.domain.admin.system.RspMenuVO;
import emnet.chat.admin.domain.admin.user.ReqUserVO;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface UserMapper {


    public List<ReqUserVO> selectUserList(ReqUserVO userVO);

    public void insertUser(ReqUserVO userVO);

    public void updateUser(ReqUserVO userVO);

    public void deleteUser(ReqUserVO userVO);

    public String selectCheckMenuChildYn(RspMenuVO params);

}
