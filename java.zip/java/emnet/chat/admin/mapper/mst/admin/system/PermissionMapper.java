package emnet.chat.admin.mapper.mst.admin.system;

import emnet.chat.admin.domain.admin.system.ReqPermissionVO;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface PermissionMapper {

    public List<ReqPermissionVO> selectPermissionList(ReqPermissionVO param);

    public int insertPermission(ReqPermissionVO param);

    public int updatePermission(ReqPermissionVO param);

    public int deletePermission(ReqPermissionVO param);

}
