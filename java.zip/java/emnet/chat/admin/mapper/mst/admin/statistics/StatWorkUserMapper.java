package emnet.chat.admin.mapper.mst.admin.statistics;

import emnet.chat.admin.domain.admin.holiday.ReqHolidayVO;
import emnet.chat.admin.domain.admin.statistics.ReqStatWorkUserVO;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface StatWorkUserMapper {

    public List<ReqStatWorkUserVO> selectStatWorkUserList(ReqStatWorkUserVO param);

}
