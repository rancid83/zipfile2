package emnet.chat.admin.mapper.mst.admin.keyword;

import emnet.chat.admin.domain.admin.consult.ReqConsultConfQuestionVO;
import emnet.chat.admin.domain.admin.keyword.ReqKeywordCategoryVO;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface KeywordCategoryMapper {

    public List<ReqKeywordCategoryVO> selectKeywordCategoryList(ReqKeywordCategoryVO param);

    public int insertKeywordCategory(ReqKeywordCategoryVO param);

    public int updateKeywordCategory(ReqKeywordCategoryVO param);

    public int deleteKeywordCategory(ReqKeywordCategoryVO param);

}
