package emnet.chat.admin.mapper.mst.admin.statistics;

import emnet.chat.admin.domain.admin.statistics.ReqStatAnswerVO;
import emnet.chat.admin.domain.admin.statistics.ResStatAnswerVO;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface StatAnswerMapper {

    public List<ResStatAnswerVO> selectStatAnswerList(ReqStatAnswerVO param);

}
