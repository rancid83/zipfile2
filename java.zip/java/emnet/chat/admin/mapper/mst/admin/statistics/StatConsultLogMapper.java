package emnet.chat.admin.mapper.mst.admin.statistics;

import emnet.chat.admin.domain.admin.statistics.ReqStatConsultLogVO;
import emnet.chat.admin.domain.admin.statistics.ResStatConsultLogVO;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface StatConsultLogMapper {

    public List<ResStatConsultLogVO> selectStatConsultLogList(ReqStatConsultLogVO param);
  
}
