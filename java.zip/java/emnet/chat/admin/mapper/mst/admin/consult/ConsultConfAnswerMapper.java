package emnet.chat.admin.mapper.mst.admin.consult;

import emnet.chat.admin.domain.admin.consult.ReqConsultConfAnswerVO;
import emnet.chat.admin.domain.admin.consult.ReqConsultConfQuestionVO;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface ConsultConfAnswerMapper {

    public List<ReqConsultConfAnswerVO> selectConsultConfAnswerList(ReqConsultConfAnswerVO param);

    public int insertConsultConfAnswer(ReqConsultConfAnswerVO param);

    public int updateConsultConfAnswer(ReqConsultConfAnswerVO param);

    public int deleteConsultConfAnswer(ReqConsultConfAnswerVO param);

}
