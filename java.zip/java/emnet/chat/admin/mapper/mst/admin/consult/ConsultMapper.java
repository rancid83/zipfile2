package emnet.chat.admin.mapper.mst.admin.consult;

import emnet.chat.admin.domain.admin.consult.*;
import org.springframework.stereotype.Repository;

import java.util.ArrayList;
import java.util.List;

@Repository
public interface ConsultMapper {

    public List<ResConsultVO> selectConsultList(ReqConsultVO param);

    public int insertConsult(ReqConsultVO param);

    public int updateConsult(ReqConsultVO param);

    public int deleteConsult(ReqConsultVO param);


    public ArrayList<ReqConsultChangeVO> selectChangeUserConsult(ReqConsultChangeVO changeVO);

    public ArrayList<ReqConsultStatusVO> selectConsultStats(ReqConsultStatusVO changeVO);

}
