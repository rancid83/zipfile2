package emnet.chat.admin.mapper.mst.admin.service;

import emnet.chat.admin.domain.admin.service.ReqServiceVO;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface ServiceMapper {


    public List<ReqServiceVO> selectServiceList(ReqServiceVO param);

    public int insertService(ReqServiceVO param);

    public int updateService(ReqServiceVO param);

    public int deleteService(ReqServiceVO param);

}
