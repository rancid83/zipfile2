package emnet.chat.admin.mapper.mst.admin.ars;

import emnet.chat.admin.domain.admin.ars.ReqArsVO;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface ArsMapper {

    public List<ReqArsVO> selectArsList(ReqArsVO param);

    public int insertArs(ReqArsVO param);

    public int updateArs(ReqArsVO param);

    public int deleteArs(ReqArsVO param);

}
