package emnet.chat.admin.controller.web.admin.system;

import java.util.List;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import emnet.chat.admin.common.define.CommonDefine;
import emnet.chat.admin.domain.admin.system.RspMenuVO;
import emnet.chat.admin.domain.common.UserInfoVO;
import emnet.chat.admin.service.admin.system.MenuService;

@Controller
@RequestMapping("/admin/system")
public class MenuController {
	
	@Autowired
	private MenuService menuService;
	
	@RequestMapping(value = "/getChildMenuList" , method = RequestMethod.POST)
	@ResponseBody
	public List<RspMenuVO> getChildMenuList(HttpSession session){		
		
		return menuService.getChildMenuList(0);
	}
	
	@RequestMapping(value = "/addMenu" , method = RequestMethod.POST)
	@ResponseBody
	public void addMenu(@RequestBody RspMenuVO rspMenuVO){
		
		menuService.addMenu(rspMenuVO);
	}
}
