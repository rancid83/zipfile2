package emnet.chat.admin.controller.web.admin.consult;

import emnet.chat.admin.common.utils.SessionUtils;
import emnet.chat.admin.domain.admin.consult.*;
import emnet.chat.admin.domain.common.CommonRestRtnVO;
import emnet.chat.admin.domain.common.UserInfoVO;
import emnet.chat.admin.service.admin.consult.ConsultCategoryService;
import emnet.chat.admin.service.admin.consult.ConsultService;
import emnet.chat.admin.service.admin.keyword.KeywordService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import java.util.ArrayList;

/**
 * 상담 VIP 고객관리
 * 사용자: 관리자 상담사
 * 화면유형 : 메인
 */
@RequestMapping("/admin/consult")
@Controller
public class ConsultController {


    @Autowired
    ConsultService service;


    @Autowired
    ConsultCategoryService consultCategoryService;


    @RequestMapping("/viewConsult.do")
    public String viewCategory(Model model) {

        UserInfoVO userInfoVO = SessionUtils.getUserInfo();

        ReqConsultCategoryVO reqConsultCategoryVO = new ReqConsultCategoryVO();
        reqConsultCategoryVO.setService_no(String.valueOf(userInfoVO.getService_no()));

        model.addAttribute("consultCategoryList", consultCategoryService.getCategoryList(reqConsultCategoryVO));

        return "admin/consult/viewConsult.main";

    }

    @RequestMapping("/getConsultList.do")
    @ResponseBody
    public ArrayList<ResConsultVO> getConsultList(ReqConsultVO param) {

        return service.getConsultList(param);
    }

    @RequestMapping("/processConsult.do")
    @ResponseBody
    public CommonRestRtnVO processConsult(@RequestBody ArrayList<ReqConsultVO> consultList) {

        service.processConsult(consultList);
        return new CommonRestRtnVO();

    }


    @RequestMapping("/getChangeUserConsult.do")
    @ResponseBody
    public ArrayList<ReqConsultChangeVO> getChangeUserConsult(ReqConsultChangeVO param) {

        return service.getChangeUserConsult(param);
    }


    /**
     * 상담원 검토요청 답변처리
     * @param param
     * @return
     */
    @RequestMapping("/processConsultReView.do")
    @ResponseBody
    public CommonRestRtnVO processConsultReView(@RequestBody ReqConsultReviewAPIVO param) {


        //TODO : API 연동 추가
        service.processConsultReview(param);
        return new CommonRestRtnVO();

    }

    /**
     * 상담원 변경요청 처리
     * @param param
     * @return
     */
    @RequestMapping("/processConsultChange.do")
    @ResponseBody
    public CommonRestRtnVO processConsultChange(@RequestBody ReqConsultChangeAPIVO param) {

        //TODO : API 연동 추가
        service.processConsultChange(param);
        return new CommonRestRtnVO();

    }


}
