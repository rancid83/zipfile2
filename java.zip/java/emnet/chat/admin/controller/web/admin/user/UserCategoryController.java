package emnet.chat.admin.controller.web.admin.user;


import emnet.chat.admin.domain.admin.user.userCategory.ReqUserCategoryVO;
import emnet.chat.admin.domain.common.CommonRestRtnVO;
import emnet.chat.admin.service.admin.user.UserCategoryService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import java.util.ArrayList;

/**
 * 사용자 스킬 관리
 * 사용자: 관리자
 * 화면유형 : 메인
 */
@RequestMapping("/admin/userCategory")
@Controller
public class UserCategoryController {

    @Autowired
    UserCategoryService service;


    @RequestMapping("/getUserCategoryList.do")
    @ResponseBody
    public ArrayList<ReqUserCategoryVO> getUserCategoryList(ReqUserCategoryVO userCategoryVO) {
        return service.selectUserCategoryList(userCategoryVO);
    }

    @RequestMapping("/processUserCategory.do")
    @ResponseBody
    public CommonRestRtnVO processUserCategory(@RequestBody ArrayList<ReqUserCategoryVO> categoryList) {
        service.processUserCategory(categoryList);
        return new CommonRestRtnVO();
    }

}
