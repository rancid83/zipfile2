package emnet.chat.admin.controller.web.admin.user;

import emnet.chat.admin.common.exception.CommonException;
import emnet.chat.admin.common.exception.ExHandler;
import emnet.chat.admin.common.exception.FaultCode;
import emnet.chat.admin.domain.admin.service.ReqServiceScheduleBatchVO;
import emnet.chat.admin.domain.admin.service.ResServiceScheduleVO;
import emnet.chat.admin.domain.admin.user.userSchedule.ReqUserScheduleEtcVO;
import emnet.chat.admin.domain.admin.user.userSchedule.ReqUserScheduleVO;
import emnet.chat.admin.domain.admin.user.userSchedule.ResUserScheduleEtcVO;
import emnet.chat.admin.domain.admin.user.userSchedule.ResUserScheduleVO;
import emnet.chat.admin.domain.common.CommonRestRtnVO;
import emnet.chat.admin.service.admin.service.ServiceScheduleService;
import emnet.chat.admin.service.admin.user.UserScheduleService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import java.util.ArrayList;

/**
 * 상담사 스케줄관리
 * 사용자: 관리자 상담사
 * 화면유형 : 메인
 */
@RequestMapping("/admin/userSchedule")
@Controller
public class UserScheduleController {


    @Autowired
    UserScheduleService service;

    @Autowired
    ServiceScheduleService serviceScheduleService;


    /**
     * 사용자 스케줄관리 화면 호출
     * @return
     */
    @RequestMapping("/viewUserSchedule.do")
    public String viewSchedule() {
        return "admin/user/viewUserSchedule.main";

    }

    /**
     * 상담사 스케줄 일괄생성 팝업
     * 사용자: 관리자 상담사
     * 화면유형 : 팝업
     */
    @RequestMapping("/viewUserScheduleBatchPopup.do")
    public String viewBatchSchedulePopup(Model model) {
        model.addAttribute("MENU_NAME", "스케줄일괄생성");
        return "admin/user/viewUserScheduleBatchPopup.pop";

    }


    /**
     * 상담사 스케줄 조회
     * @param vipVO
     * @return
     */
    @RequestMapping("/getUserScheduleList.do")
    @ResponseBody
    public ArrayList<ResUserScheduleVO> getUserScheduleList(ReqUserScheduleVO vipVO) {

        return service.getUserScheduleList(vipVO);
    }




    /**
     * 시스템 서비스 설정 스케줄 조회
     * @param serviceScheduleVO
     * @return
     */
    @RequestMapping("/getServiceScheduleList.do")
    @ResponseBody
    public ArrayList<ResServiceScheduleVO> getServiceScheduleList(ResServiceScheduleVO serviceScheduleVO) {

        return serviceScheduleService.getServiceScheduleList(serviceScheduleVO);
    }

    /**
     * 사용자 근무 스케줄 일괄 생성 처리
     *
     * @param batchVO 배치 요청전문
     * @return CommonRestRtnVO 처리 응답 결과
     */
    @RequestMapping("/batchServiceSchedule.do")
    @ResponseBody
    public CommonRestRtnVO batchServiceSchedule(@RequestBody ReqServiceScheduleBatchVO batchVO) {

        ExHandler.exceptionEmptyMsg(batchVO.getStart_date(), FaultCode.INVALID_REQ_BODY);
        ExHandler.exceptionEmptyMsg(batchVO.getEnd_date(), FaultCode.INVALID_REQ_BODY);

        if (batchVO.getUserList().isEmpty()) {
            throw new CommonException("USERLIST IS EMPTY ", "사용자를 선택해주세요");

        } else {

            if (batchVO.getDateList().isEmpty()) {
                throw new CommonException("USERLIST IS EMPTY ", "사용자를 선택해주세요");

            } else {
                serviceScheduleService.processBatchSchedule(batchVO.getDateList());
                service.processUserScheduleBatch(batchVO);
            }
        }

        return new CommonRestRtnVO();
    }





    @RequestMapping("/processUserSchedule.do")
    @ResponseBody
    public CommonRestRtnVO processUserSchedule(@RequestBody ArrayList<ReqUserScheduleVO> vipList) {

        service.processUserSchedule(vipList);
        return new CommonRestRtnVO();

    }


    /**
     * 상담사 스케줄 기타 근무 생성 / 변경 팝업
     * 사용자: 관리자 상담사
     * 화면유형 : 팝업
     */
    @RequestMapping("/viewUserScheduleEtcPopup.do")
    public String viewUserScheduleEtcPopup() {
        return "admin/user/viewUserScheduleEtcPopup.pop";

    }



    /**
     * 상담사 스케줄 조회 - 기타
     * @param etcVO
     * @return
     */
    @RequestMapping("/getUserScheduleEtcList.do")
    @ResponseBody
    public ArrayList<ResUserScheduleEtcVO> getUserScheduleEtcList(ReqUserScheduleEtcVO etcVO) {

        return service.getUserScheduleEtcList(etcVO);
    }



    @RequestMapping("/processUserScheduleEtc.do")
    @ResponseBody
    public CommonRestRtnVO processUserScheduleEtc(@RequestBody ArrayList<ReqUserScheduleEtcVO> etcList) {

        service.processUserScheduleEtc(etcList);
        return new CommonRestRtnVO();

    }


}
