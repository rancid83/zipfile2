package emnet.chat.admin.controller.web.admin.slang;

import emnet.chat.admin.domain.admin.slang.ReqSlangVO;
import emnet.chat.admin.domain.common.CommonRestRtnVO;
import emnet.chat.admin.service.admin.slang.SlangService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import java.util.ArrayList;

/**
 * 욕설 관리
 * 사용자: 관리자
 * 화면유형 : 메인
 */
@RequestMapping("/admin/slang")
@Controller
public class SlangController {

    @Autowired
    SlangService service;

    @RequestMapping("/viewSlangPopup.do")
    public String viewSlangPopup() {
        return "admin/slang/viewSlang.pop";
    }

    @RequestMapping("/getSlangList.do")
    @ResponseBody
    public ArrayList<ReqSlangVO> getSlangList(ReqSlangVO SlangVO) {
        return service.getSlangList(SlangVO);
    }

    @RequestMapping("/processSlang.do")
    @ResponseBody
    public CommonRestRtnVO processSlang(@RequestBody ArrayList<ReqSlangVO> slangList) {
        service.processSlang(slangList);
        return new CommonRestRtnVO();
    }

}
