package emnet.chat.admin.controller.web.admin.holiday;

import emnet.chat.admin.common.exception.ExHandler;
import emnet.chat.admin.common.exception.FaultCode;
import emnet.chat.admin.domain.admin.consult.ReqConsultVipVO;
import emnet.chat.admin.domain.admin.holiday.ReqHolidayVO;
import emnet.chat.admin.domain.common.CommonRestRtnVO;
import emnet.chat.admin.mapper.mst.admin.holiday.HolidayMapper;
import emnet.chat.admin.service.admin.consult.ConsultVipService;
import emnet.chat.admin.service.admin.holiday.HolidayService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import java.util.ArrayList;

/**
 * 공휴일 관리
 * 사용자: 관리자
 * 화면유형 : 메인
 */
@RequestMapping("/admin/holiday")
@Controller
public class HolidayController {

    @Autowired
    HolidayService service;

    @RequestMapping("/viewHoliday.do")
    public String viewHoliday() {
        return "admin/holiday/viewHoliday.main";
    }

    @RequestMapping("/getHolidayList.do")
    @ResponseBody
    public ArrayList<ReqHolidayVO> getHolidayList(ReqHolidayVO param) {
        ExHandler.exceptionEmptyMsg(param.getSch_end_date(), FaultCode.INVALID_REQ_BODY);
        ExHandler.exceptionEmptyMsg(param.getSch_start_date(), FaultCode.INVALID_REQ_BODY);
        ExHandler.exceptionDateFormat(param.getSch_start_date());
        ExHandler.exceptionDateFormat(param.getSch_end_date());
        return service.getHolidayList(param);
    }

    @RequestMapping("/processHoliday.do")
    @ResponseBody
    public CommonRestRtnVO processHoliday(@RequestBody ArrayList<ReqHolidayVO> holidayList) {
        service.processHoliday(holidayList);
        return new CommonRestRtnVO();
    }

}
