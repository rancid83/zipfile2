package emnet.chat.admin.controller.web.admin.statistics;


import emnet.chat.admin.common.utils.SessionUtils;
import emnet.chat.admin.domain.admin.consult.ReqConsultCategoryVO;
import emnet.chat.admin.domain.admin.statistics.ReqStatHourVO;
import emnet.chat.admin.domain.admin.statistics.ReqStatSkillVO;
import emnet.chat.admin.domain.common.UserInfoVO;
import emnet.chat.admin.service.admin.consult.ConsultCategoryService;
import emnet.chat.admin.service.admin.statistics.StatSkillService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.util.HashMap;

/**
 * 일별 상담 현황
 * 사용자: 관리자
 * 화면유형 : 메인
 */
@RequestMapping("/admin/statSkill")
@Controller
public class StatSkillController {

    @Autowired
    StatSkillService service;

    @Autowired
    ConsultCategoryService consultCategoryService;


    @RequestMapping("/viewStatSkill.do")
    public String viewStatSkill(Model model) {
        UserInfoVO userInfoVO = SessionUtils.getUserInfo();

        ReqConsultCategoryVO reqConsultCategoryVO = new ReqConsultCategoryVO();
        reqConsultCategoryVO.setService_no(String.valueOf(userInfoVO.getService_no()));

        model.addAttribute("consultCategoryList", consultCategoryService.getCategoryList(reqConsultCategoryVO));
        return "admin/statistics/viewStatSkill.main";
    }

    @RequestMapping("/getStatSkillList.do")
    @ResponseBody
    public HashMap<String, Object> getStatSkillList(ReqStatSkillVO SkillVO) {

        HashMap resultMap = new HashMap();

        resultMap.put("SkillList", service.getStatSkillList(SkillVO));
        resultMap.put("SkillSummaryList", service.getStatSkillSummaryList(SkillVO));

        return resultMap;
    }

    @RequestMapping("/exceldownload.do")
    @ResponseBody
    public void exceldownload(ReqStatSkillVO skillVO, HttpServletRequest request, HttpServletResponse response) {

        service.downExcel(skillVO, request, response);
    }
}
