package emnet.chat.admin.controller.web.admin.statistics;


import emnet.chat.admin.common.define.CommonDefine;
import emnet.chat.admin.common.exception.ExHandler;
import emnet.chat.admin.common.exception.FaultCode;
import emnet.chat.admin.common.utils.SessionUtils;
import emnet.chat.admin.domain.admin.consult.ReqConsultCategoryVO;
import emnet.chat.admin.domain.admin.statistics.ReqStatHourVO;
import emnet.chat.admin.domain.admin.statistics.ReqStatProductDailyVO;
import emnet.chat.admin.domain.common.UserInfoVO;
import emnet.chat.admin.service.admin.consult.ConsultCategoryService;
import emnet.chat.admin.service.admin.statistics.StatProductDailyService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.util.HashMap;

/**
 * 일별 상담 현황
 * 사용자: 관리자
 * 화면유형 : 메인
 */
@RequestMapping("/admin/statProductDaily")
@Controller
public class StatProductDailyController {

    @Autowired
    StatProductDailyService service;

    @Autowired
    ConsultCategoryService consultCategoryService;


    @RequestMapping("/viewStatProductDaily.do")
    public String viewStatProductDaily(Model model) {
        UserInfoVO userInfoVO = SessionUtils.getUserInfo();

        ReqConsultCategoryVO reqConsultCategoryVO = new ReqConsultCategoryVO();
        reqConsultCategoryVO.setService_no(String.valueOf(userInfoVO.getService_no()));

        model.addAttribute("consultCategoryList", consultCategoryService.getCategoryList(reqConsultCategoryVO));
        return "admin/statistics/viewStatProductDaily.main";
    }


    @RequestMapping("/viewStatProductDailyPopup.do")
    public String viewStatProductDailyPopup(Model model) {

        UserInfoVO userInfoVO = SessionUtils.getUserInfo();
        if (userInfoVO.getPermission_no() != CommonDefine.PERMISSION_MANAGER) {
            model.addAttribute("PRIVATE_YN", "Y");
        }
        model.addAttribute("MENU_NAME", "고객현황");
        model.addAttribute("consultCategoryList", consultCategoryService.getCategoryList(new ReqConsultCategoryVO()));
        return "admin/statistics/viewStatProductDailyPopup.pop";
    }


    @RequestMapping("/getStatProductDailyUserList.do")
    @ResponseBody
    public HashMap<String, Object> getStatProductDailyUserList(ReqStatProductDailyVO productDailyVO) {



        ExHandler.exceptionEmptyMsg(productDailyVO.getSch_end_date(), FaultCode.INVALID_REQ_BODY);
        ExHandler.exceptionEmptyMsg(productDailyVO.getSch_start_date(), FaultCode.INVALID_REQ_BODY);
        ExHandler.exceptionDateFormat(productDailyVO.getSch_start_date());
        ExHandler.exceptionDateFormat(productDailyVO.getSch_end_date());

        UserInfoVO userInfoVO = SessionUtils.getUserInfo();
        productDailyVO.setUser_no(String.valueOf(userInfoVO.getUser_no()));


        HashMap resultMap = new HashMap();

        resultMap.put("productDailyList", service.getStatProductDailyList(productDailyVO));


        return resultMap;
    }

    @RequestMapping("/getStatProductDailyList.do")
    @ResponseBody
    public HashMap<String, Object> getStatProductDailyList(ReqStatProductDailyVO productDailyVO) {

        ExHandler.exceptionEmptyMsg(productDailyVO.getLevel1_no(), FaultCode.INVALID_REQ_BODY);
        ExHandler.exceptionEmptyMsg(productDailyVO.getLevel2_no(), FaultCode.INVALID_REQ_BODY);
        ExHandler.exceptionEmptyMsg(productDailyVO.getLevel3_no(), FaultCode.INVALID_REQ_BODY);
        ExHandler.exceptionEmptyMsg(productDailyVO.getSch_end_date(), FaultCode.INVALID_REQ_BODY);
        ExHandler.exceptionEmptyMsg(productDailyVO.getSch_start_date(), FaultCode.INVALID_REQ_BODY);
        ExHandler.exceptionDateFormat(productDailyVO.getSch_start_date());
        ExHandler.exceptionDateFormat(productDailyVO.getSch_end_date());

        UserInfoVO userInfoVO = SessionUtils.getUserInfo();
        if (userInfoVO.getPermission_no() != CommonDefine.PERMISSION_MANAGER) {
            productDailyVO.setUser_no(String.valueOf(userInfoVO.getUser_no()));
        }

        HashMap resultMap = new HashMap();

        resultMap.put("productDailyList", service.getStatProductDailyList(productDailyVO));


        return resultMap;
    }


    @RequestMapping("/exceldownload.do")
    @ResponseBody
    public void exceldownload(ReqStatProductDailyVO productDailyVO , HttpServletRequest request , HttpServletResponse response) {

        service.downExcel(productDailyVO , request , response);
    }


}
