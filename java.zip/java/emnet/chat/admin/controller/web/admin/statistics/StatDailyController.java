package emnet.chat.admin.controller.web.admin.statistics;


import emnet.chat.admin.common.utils.SessionUtils;
import emnet.chat.admin.domain.admin.consult.ReqConsultCategoryVO;
import emnet.chat.admin.domain.admin.statistics.ReqStatDailyVO;
import emnet.chat.admin.domain.admin.statistics.ReqStatUserWorkLogVO;
import emnet.chat.admin.domain.admin.statistics.ResStatDailyVO;
import emnet.chat.admin.domain.common.UserInfoVO;
import emnet.chat.admin.service.admin.consult.ConsultCategoryService;
import emnet.chat.admin.service.admin.statistics.StatDailyService;
import emnet.chat.admin.service.admin.statistics.StatDailyService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.util.ArrayList;
import java.util.HashMap;

/**
 * 일별 상담 현황
 * 사용자: 관리자
 * 화면유형 : 메인
 */
@RequestMapping("/admin/statDaily")
@Controller
public class StatDailyController {

    @Autowired
    StatDailyService service;

    @Autowired
    ConsultCategoryService consultCategoryService;


    @RequestMapping("/viewStatDaily.do")
    public String viewStatDaily(Model model) {
        model.addAttribute("MENU_NAME", "일별 상담 현황");

        UserInfoVO userInfoVO = SessionUtils.getUserInfo();

        ReqConsultCategoryVO reqConsultCategoryVO = new ReqConsultCategoryVO();
        reqConsultCategoryVO.setService_no(String.valueOf(userInfoVO.getService_no()));

        model.addAttribute("consultCategoryList", consultCategoryService.getCategoryList(reqConsultCategoryVO));
        return "admin/statistics/viewStatDaily.main";
    }

    @RequestMapping("/getStatDailyList.do")
    @ResponseBody
    public HashMap<String, Object> getStatDailyList(ReqStatDailyVO dailyVO) {

        HashMap resultMap = new HashMap();

        resultMap.put("dailyList", service.getStatDailyList(dailyVO));
        resultMap.put("dailySummaryList", service.getStatDailySummaryList(dailyVO));

        return resultMap;
    }

    @RequestMapping("/exceldownload.do")
    @ResponseBody
    public void exceldownload(ReqStatDailyVO dailyVO , HttpServletRequest request , HttpServletResponse response) {




        service.downExcel(dailyVO , request , response);
    }
}
