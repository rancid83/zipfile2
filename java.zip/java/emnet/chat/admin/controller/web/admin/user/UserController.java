package emnet.chat.admin.controller.web.admin.user;

import emnet.chat.admin.common.define.CommonDefine;
import emnet.chat.admin.common.exception.CommonException;
import emnet.chat.admin.common.exception.FaultCode;
import emnet.chat.admin.common.utils.SessionUtils;
import emnet.chat.admin.domain.admin.user.ReqUserVO;
import emnet.chat.admin.domain.admin.user.userRest.ReqUserRestVO;
import emnet.chat.admin.domain.common.CommonRestRtnVO;
import emnet.chat.admin.domain.common.UserInfoVO;
import emnet.chat.admin.service.admin.user.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import java.util.ArrayList;

@RequestMapping("/admin/user")
@Controller
public class UserController {



    @Autowired
    private UserService service;


    @RequestMapping("/viewUser.do")
    public String viewUser() {
        return "admin/user/viewUser.main";

    }

    @RequestMapping("/viewUserSearchBar.do")
    public String viewUserSearchBar() {

        return "admin/user/viewUserSearchBar.body";
    }

    @RequestMapping("/viewUserListPopup.do")
    public String viewUserListPopup() {

        return "admin/user/viewUserListPopup.pop";
    }


    @RequestMapping("/viewUserDetailPopup.do")
    public String viewUserDetailPopup() {

        return "admin/user/viewUserDetailPopup.pop";
    }



    @RequestMapping("/getUserList.do")
    @ResponseBody
    public ArrayList<ReqUserVO> getUserList(ReqUserVO reqUserVO) {

        return service.getUserList(reqUserVO);
    }

    @RequestMapping("/processUser.do")
    @ResponseBody
    public CommonRestRtnVO processUser(@RequestBody ArrayList<ReqUserVO> userList) {

        UserInfoVO userInfoVO = SessionUtils.getUserInfo();
        if(userInfoVO.getPermission_no() != CommonDefine.PERMISSION_MANAGER){
            throw new CommonException(FaultCode.INVLID_AUTHORIZATION);
        }

        service.processUser(userList);
        return new CommonRestRtnVO();
    }


}
