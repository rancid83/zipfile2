package emnet.chat.admin.controller.web.admin.consult;

import emnet.chat.admin.domain.admin.consult.ReqConsultConfAnswerVO;
import emnet.chat.admin.domain.admin.consult.ReqConsultConfQuestionVO;
import emnet.chat.admin.domain.admin.consult.ReqConsultVipVO;
import emnet.chat.admin.domain.common.CommonRestRtnVO;
import emnet.chat.admin.service.admin.consult.ConsultConfQuestionService;
import emnet.chat.admin.service.admin.consult.ConsultVipService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import java.util.ArrayList;

/**
 * 상담 만족도 조사 질문 Controller
 * 사용자: 관리자 상담사
 * 화면유형 : 메인
 */
@RequestMapping("/admin/consultConfQuestion")
@Controller
public class ConsultConfQuestionController {


    @Autowired
    ConsultConfQuestionService service;


    @RequestMapping("/viewConfQuestion.do")
    public String viewConfQuestion() {
        return "admin/consultConf/viewConfQuestion.main";

    }

    @RequestMapping("/getConfQuestionList.do")
    @ResponseBody
    public ArrayList<ReqConsultConfQuestionVO> getConfQuestionList(ReqConsultConfQuestionVO questionVO) {

        return service.getConfQuestionList(questionVO);
    }

    @RequestMapping("/processConfQuestion.do")
    @ResponseBody
    public CommonRestRtnVO processConfQuestion(@RequestBody ArrayList<ReqConsultConfQuestionVO> questionList) {

        service.processConfQuestion(questionList);
        return new CommonRestRtnVO();

    }

    @RequestMapping("/getConsultConfAnswerList.do")
    @ResponseBody
    public ArrayList<ReqConsultConfAnswerVO> getConsultConfAnswerList(ReqConsultConfAnswerVO answerVO) {

        return service.getConsultConfAnswerList(answerVO);
    }

    @RequestMapping("/processConsultConfAnswer.do")
    @ResponseBody
    public CommonRestRtnVO processConsultConfAnswer(@RequestBody ArrayList<ReqConsultConfAnswerVO> answerList) {

        service.processConsultConfAnswer(answerList);
        return new CommonRestRtnVO();

    }

}
