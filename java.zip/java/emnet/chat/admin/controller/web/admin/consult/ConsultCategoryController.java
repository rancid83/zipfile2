package emnet.chat.admin.controller.web.admin.consult;

import emnet.chat.admin.domain.admin.consult.ReqConsultCategorySkillVO;
import emnet.chat.admin.domain.admin.consult.ReqConsultCategoryVO;
import emnet.chat.admin.domain.admin.service.ReqServiceVO;
import emnet.chat.admin.domain.common.ComCodeMstVO;
import emnet.chat.admin.domain.common.CommonRestRtnVO;
import emnet.chat.admin.service.admin.consult.ConsultCategoryService;
import emnet.chat.admin.service.admin.consult.ConsultCategorySkillService;
import emnet.chat.admin.service.admin.service.ServiceDefineService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import java.util.ArrayList;

/**
 * 상담유형별 키워드관리
 * 사용자: 관리자 상담사
 * 화면유형 : 메인
 */
@RequestMapping("/admin/consultCategory")
@Controller
public class ConsultCategoryController {

    @Autowired
    ConsultCategoryService service;

    @Autowired
    ServiceDefineService defineService;

    @Autowired
    ConsultCategorySkillService skillService;

    @RequestMapping("/viewCategory.do")
    public String viewCategory(Model model) {
        model.addAttribute("MENU_NAME","상담유형관리");
        return "admin/consult/viewCategory.main";
    }

    @RequestMapping("/getCategoryList.do")
    @ResponseBody
    public ArrayList<ReqConsultCategoryVO> getCategoryList(ReqConsultCategoryVO consultCategoryVO) {
        return service.getCategoryList(consultCategoryVO);
    }


    @RequestMapping("/processCategory.do")
    @ResponseBody
    public CommonRestRtnVO processCategory(@RequestBody ArrayList<ReqConsultCategoryVO> categoryList) {

        service.processCategory(categoryList);
        return new CommonRestRtnVO();

    }


    @RequestMapping("/getConsultCategorySkillList.do")
    @ResponseBody
    public ArrayList<ReqConsultCategorySkillVO> getConsultCategorySkillList(ReqConsultCategorySkillVO categorySkillVO) {

        return skillService.getConsultCategorySkillList(categorySkillVO);
    }


    @RequestMapping("/processConsultCategorySkill.do")
    @ResponseBody
    public CommonRestRtnVO processConsultCategorySkill(@RequestBody ArrayList<ReqConsultCategorySkillVO> categorySkillList) {

        skillService.processConsultCategorySkill(categorySkillList);
        return new CommonRestRtnVO();

    }

    @RequestMapping("/getServiceDefineList.do")
    @ResponseBody
    public ArrayList<ReqServiceVO> getServiceDefineList(ReqServiceVO reqServiceVO) {

        return defineService.getServiceList(reqServiceVO);
    }


    @RequestMapping("/processServiceDefine.do")
    @ResponseBody
    public CommonRestRtnVO processServiceDefine(@RequestBody ReqServiceVO reqServiceVO) {

        defineService.processServiceDefine(reqServiceVO);
        return new CommonRestRtnVO();

    }

}
