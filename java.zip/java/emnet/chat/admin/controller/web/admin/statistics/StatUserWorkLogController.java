package emnet.chat.admin.controller.web.admin.statistics;


import emnet.chat.admin.common.utils.SessionUtils;
import emnet.chat.admin.domain.admin.consult.ReqConsultCategoryVO;
import emnet.chat.admin.domain.admin.statistics.ReqStatUserWorkLogVO;
import emnet.chat.admin.domain.admin.statistics.ResStatUserWorkLogVO;
import emnet.chat.admin.domain.common.UserInfoVO;
import emnet.chat.admin.service.admin.consult.ConsultCategoryService;
import emnet.chat.admin.service.admin.statistics.StatUserWorkLogService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.util.ArrayList;

/**
 * 일별 상담 현황
 * 사용자: 관리자
 * 화면유형 : 메인
 */
@RequestMapping("/admin/statUserWorkLog")
@Controller
public class StatUserWorkLogController {

    @Autowired
    StatUserWorkLogService service;

    @Autowired
    ConsultCategoryService consultCategoryService;

    @RequestMapping("/viewStatUserWorkLog.do")
    public String viewStatUserWorkLog(Model model) {

        UserInfoVO userInfoVO = SessionUtils.getUserInfo();

        ReqConsultCategoryVO reqConsultCategoryVO = new ReqConsultCategoryVO();
        reqConsultCategoryVO.setService_no(String.valueOf(userInfoVO.getService_no()));

        model.addAttribute("consultCategoryList", consultCategoryService.getCategoryList(reqConsultCategoryVO));

        return "admin/statistics/viewStatUserWorkLog.main";
    }

    @RequestMapping("/getStatUserWorkLogList.do")
    @ResponseBody
    public ArrayList<ResStatUserWorkLogVO> getStatUserWorkLogList(ReqStatUserWorkLogVO UserWorkLogVO) {



        return service.getStatUserWorkLogList(UserWorkLogVO);
    }


    @RequestMapping("/exceldownload.do")
    @ResponseBody
    public void exceldownload(ReqStatUserWorkLogVO userWorkLogVO , HttpServletRequest request , HttpServletResponse response) {


        userWorkLogVO.setSch_start_date(userWorkLogVO.getSch_start_date().replaceAll("-","")+userWorkLogVO.getSch_start_time().replaceAll(":","")+"00");
        userWorkLogVO.setSch_end_date(userWorkLogVO.getSch_end_date().replaceAll("-","")+userWorkLogVO.getSch_end_time().replaceAll(":","")+"00");

        service.downExcel(userWorkLogVO , request , response);
    }
}
