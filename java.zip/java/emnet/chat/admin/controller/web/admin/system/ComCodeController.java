package emnet.chat.admin.controller.web.admin.system;

import emnet.chat.admin.domain.common.ComCodeDtlVO;
import emnet.chat.admin.domain.common.ComCodeMstVO;
import emnet.chat.admin.domain.common.CommonRestRtnVO;
import emnet.chat.admin.domain.common.cache.ComCodeCacheVO;
import emnet.chat.admin.service.admin.comCode.ComCodeService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import java.util.ArrayList;

@RequestMapping("/admin/comCode")
@Controller
public class ComCodeController {


    @Autowired
    private ComCodeService service;


    @RequestMapping("/viewComCode.do")
    public String viewComCode() {
        return "admin/comCode/viewComCode.main";

    }

    @RequestMapping("/getComCodeGroupList.do")
    @ResponseBody
    public ArrayList<ComCodeMstVO> getComCodeGroupList(ComCodeMstVO codeMstVO) {

        return service.getComCodeGroupList(codeMstVO);
    }

    /**
     * 공통코드 캐쉬에서 공통코드 Return
     * @param cacheCodeList
     * @return
     */
    @RequestMapping("/getComComboCache.do")
    @ResponseBody
    public ArrayList<ComCodeCacheVO> getComComboCache(@RequestBody ArrayList<ComCodeCacheVO> cacheCodeList) {

        return service.getComComboCache(cacheCodeList);
    }

    @RequestMapping("/processComGroupCode.do")
    @ResponseBody
    public CommonRestRtnVO processComGroupCode( @RequestBody ArrayList<ComCodeMstVO> codeGroupList) {

        service.processComGroupCode(codeGroupList);

        return new CommonRestRtnVO();
    }

    @RequestMapping("/getComCodeList.do")
    @ResponseBody
    public ArrayList<ComCodeDtlVO> getComCodeList(ComCodeDtlVO codeVO) {

        return service.getComCodeList(codeVO);
    }

    @RequestMapping("/processComCode.do")
    @ResponseBody
    public CommonRestRtnVO processComCode( @RequestBody ArrayList<ComCodeDtlVO> codeList) {

        service.processComCode(codeList);

        return new CommonRestRtnVO();
    }
}

