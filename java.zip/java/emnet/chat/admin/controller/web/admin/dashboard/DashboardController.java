package emnet.chat.admin.controller.web.admin.dashboard;


import emnet.chat.admin.common.exception.ExHandler;
import emnet.chat.admin.common.exception.FaultCode;
import emnet.chat.admin.domain.admin.consult.ReqConsultCategoryVO;
import emnet.chat.admin.domain.admin.dashboard.ReqDashboardVO;
import emnet.chat.admin.domain.admin.dashboard.ResDashboardHourVO;
import emnet.chat.admin.domain.admin.statistics.ReqStatAnswerVO;
import emnet.chat.admin.service.admin.consult.ConsultCategoryService;
import emnet.chat.admin.service.admin.dashboard.DashboardService;
import emnet.chat.admin.service.admin.statistics.StatAnswerService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import java.util.ArrayList;
import java.util.HashMap;

/**
 * 대시보드
 * 사용자: 관리자
 * 화면유형 : 메인
 */
@RequestMapping("/admin/dashboard")
@Controller
public class DashboardController {

    @Autowired
    DashboardService service;

    @Autowired
    ConsultCategoryService consultCategoryService;


    @RequestMapping("/viewDashboard.do")
    public String viewDashboard(Model model) {
        model.addAttribute("MENU_NAME", "대시보드");
        model.addAttribute("consultCategoryList", consultCategoryService.getCategoryList(new ReqConsultCategoryVO()));
        return "admin/dashboard/viewDashboard.main";
    }

    @RequestMapping("/viewDashboardPopup.do")
    public String viewDashboardPopup(Model model) {
        model.addAttribute("MENU_NAME", "대시보드");
        model.addAttribute("consultCategoryList", consultCategoryService.getCategoryList(new ReqConsultCategoryVO()));
        return "admin/dashboard/viewDashboardPopup.pop";
    }


    @RequestMapping("/getDashboardList.do")
    @ResponseBody
    public HashMap<String, Object> getDashboardList(ReqDashboardVO reqDashboardVO) {


        ExHandler.exceptionEmptyMsg(reqDashboardVO.getService_no(), FaultCode.INVALID_REQ_BODY);

        HashMap resultMap = new HashMap();

        resultMap.put("SUMMARY_INFO", service.getDailySummary(reqDashboardVO));
        resultMap.put("USER_INFO", service.getDailyUser(reqDashboardVO));
        resultMap.put("HOUR_INFO", service.getHour(reqDashboardVO));

        // 5일간 변화량 조회
        resultMap.put("DAILY_INFO", service.getDaily(reqDashboardVO));


        return resultMap;
    }

    /**
     * 상담사 시간별 처리 현황
     * @param reqDashboardVO
     * @return
     */
    @RequestMapping("/getDashboardUserHour.do")
    @ResponseBody
    public ArrayList<ResDashboardHourVO> getDashboardUserHour(ReqDashboardVO reqDashboardVO) {


        ExHandler.exceptionEmptyMsg(reqDashboardVO.getService_no(), FaultCode.INVALID_REQ_BODY);
        ExHandler.exceptionEmptyMsg(reqDashboardVO.getUser_no(), FaultCode.INVALID_REQ_BODY);

        return service.getHourUser(reqDashboardVO);

    }

}
