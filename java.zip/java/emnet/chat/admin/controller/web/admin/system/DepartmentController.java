package emnet.chat.admin.controller.web.admin.system;

import emnet.chat.admin.domain.admin.dept.ReqDepartmentVO;
import emnet.chat.admin.domain.common.ComCodeDtlVO;
import emnet.chat.admin.domain.common.ComCodeMstVO;
import emnet.chat.admin.domain.common.CommonRestRtnVO;
import emnet.chat.admin.service.admin.comCode.ComCodeService;
import emnet.chat.admin.service.admin.dept.DepartmentService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import java.util.ArrayList;

@RequestMapping("/admin/department")
@Controller
public class DepartmentController {


    @Autowired
    private DepartmentService service;


    @RequestMapping("/viewDepartment.do")
    public String viewUser() {

        return "admin/department/viewDepartment.main";

    }


    @RequestMapping("/viewDepartmentSearchBar.do")
    public String viewDepartmentSearchBar() {

        return "admin/department/viewDepartmentSearchBar.body";

    }

    @RequestMapping("/getDepartmentList.do")
    @ResponseBody
    public ArrayList<ReqDepartmentVO> getDepartmentList(ReqDepartmentVO departmentVO) {

        return service.getDepartmentList(departmentVO);
    }

    @RequestMapping("/processDepartment.do")
    @ResponseBody
    public CommonRestRtnVO processDepartment(@RequestBody ArrayList<ReqDepartmentVO> departmentList) {

        service.processDepartment(departmentList);

        return new CommonRestRtnVO();
    }

}

