package emnet.chat.admin.controller.web.admin.statistics;



public class StatRoomController {

}
