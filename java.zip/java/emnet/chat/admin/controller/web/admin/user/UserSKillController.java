package emnet.chat.admin.controller.web.admin.user;

import emnet.chat.admin.domain.admin.user.userRest.ReqUserRestVO;
import emnet.chat.admin.domain.admin.user.userSkill.ReqUserSkillVO;
import emnet.chat.admin.domain.common.CommonRestRtnVO;
import emnet.chat.admin.service.admin.user.UserRestService;
import emnet.chat.admin.service.admin.user.UserSkillService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import java.util.ArrayList;

/**
 * 사용자 스킬 관리
 * 사용자: 관리자
 * 화면유형 : 메인
 */
@RequestMapping("/admin/userSkill")
@Controller
public class UserSKillController {

    @Autowired
    UserSkillService service;

    @RequestMapping("/viewUserSkillPop.do")
    public String viewUserSkillPop(ReqUserSkillVO skillVO) {
         return "admin/user/viewUserSkillPop.pop";
    }


    @RequestMapping("/getUserSkillList.do")
    @ResponseBody
    public ArrayList<ReqUserSkillVO> getUserSkillList(ReqUserSkillVO skillVO) {
        return service.getUserSkillList(skillVO);
    }

    @RequestMapping("/processUserSkill.do")
    @ResponseBody
    public CommonRestRtnVO processUserSkill(@RequestBody ArrayList<ReqUserSkillVO> skillList) {
        service.processUserSkill(skillList);
        return new CommonRestRtnVO();
    }

}
