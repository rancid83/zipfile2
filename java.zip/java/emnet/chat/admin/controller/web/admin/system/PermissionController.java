package emnet.chat.admin.controller.web.admin.system;

import emnet.chat.admin.common.exception.CommonException;
import emnet.chat.admin.common.exception.FaultCode;
import emnet.chat.admin.common.utils.SessionUtils;
import emnet.chat.admin.domain.admin.menu.ReqMenuLevelVO;
import emnet.chat.admin.domain.admin.menu.ReqMenuPermissionMappingVO;
import emnet.chat.admin.domain.admin.menu.ReqPermissionMenuVO;
import emnet.chat.admin.domain.admin.menu.ResPermissionMenuVO;
import emnet.chat.admin.domain.admin.system.ReqPermissionVO;
import emnet.chat.admin.domain.common.CommonRestRtnVO;
import emnet.chat.admin.domain.common.UserInfoVO;
import emnet.chat.admin.mapper.mst.admin.system.MenuMapper;
import emnet.chat.admin.service.admin.system.PermissionService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import java.util.ArrayList;

@Controller
@RequestMapping("/admin/permission")
public class PermissionController {

    @Autowired
    PermissionService service;


    /**
     * 권한 관리 메뉴화면 이동
     *
     * @param model
     * @return
     */
    @RequestMapping("/viewPermission.do")
    public String viewPermission(Model model) {

        UserInfoVO loginUser = SessionUtils.getUserInfo();
        ReqMenuLevelVO permissionVO = new ReqMenuLevelVO();
        permissionVO.setService_no(String.valueOf(loginUser.getService_no()));

        //시스템에 등록된 전체 메뉴 리스트를 UI model에  "ALL_MENU_LIST"로 추가
        model.addAttribute("ALL_MENU_LIST", service.getMenuList(permissionVO));

        return "admin/system/viewPermission.main";
    }

    /**
     * 권한 리스트 리턴
     *
     * @param permissionVO
     * @return
     */
    @RequestMapping("/getPermissionList.do")
    @ResponseBody
    public ArrayList<ReqPermissionVO> getPermissionList(ReqPermissionVO permissionVO) {

        return service.getPermissionList(permissionVO);
    }

    /**
     * 권한(Permission) 처리
     *
     * @param permissionList
     * @return
     */
    @RequestMapping("/processPermission.do")
    @ResponseBody
    public CommonRestRtnVO processPermission(@RequestBody ArrayList<ReqPermissionVO> permissionList) {
        service.processPermission(permissionList);
        return new CommonRestRtnVO();
    }


    /**
     * 권한이 부여된 메뉴 리스트 리턴
     *
     * @param permissionVO
     * @return
     */
    @RequestMapping("/getPermissionMappingMenuList.do")
    @ResponseBody
    public ArrayList<ResPermissionMenuVO> getPermissionMappingMenuList(ReqPermissionMenuVO permissionVO) {

        return service.getPermissionMappingMenuList(permissionVO);
    }


    /**
     * 권한 별 메뉴 등록 처리
     *
     * @param permissionMappingList
     * @return CommonRestRtnVO
     */
    @RequestMapping("/processPermissionMappingMenu.do")
    @ResponseBody
    public CommonRestRtnVO processPermissionMappingMenu(@RequestBody ArrayList<ReqMenuPermissionMappingVO> permissionMappingList) {


        if (permissionMappingList.isEmpty()) {
            throw new CommonException(FaultCode.BAD_REQUEST);
        }

        service.processPermissionMapping(permissionMappingList);

        return new CommonRestRtnVO();
    }


}
