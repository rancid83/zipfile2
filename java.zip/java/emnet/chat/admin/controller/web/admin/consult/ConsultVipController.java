package emnet.chat.admin.controller.web.admin.consult;

import emnet.chat.admin.domain.admin.consult.ReqConsultCategorySkillVO;
import emnet.chat.admin.domain.admin.consult.ReqConsultCategoryVO;
import emnet.chat.admin.domain.admin.consult.ReqConsultVipVO;
import emnet.chat.admin.domain.common.CommonRestRtnVO;
import emnet.chat.admin.mapper.mst.admin.consult.ConsultVipMapper;
import emnet.chat.admin.service.admin.consult.ConsultCategoryService;
import emnet.chat.admin.service.admin.consult.ConsultCategorySkillService;
import emnet.chat.admin.service.admin.consult.ConsultVipService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import java.util.ArrayList;

/**
 * 상담 VIP 고객관리
 * 사용자: 관리자 상담사
 * 화면유형 : 메인
 */
@RequestMapping("/admin/consultVip")
@Controller
public class ConsultVipController {


    @Autowired
    ConsultVipService service;


    @RequestMapping("/viewVip.do")
    public String viewCategory() {
        return "admin/consult/viewVip.main";

    }

    @RequestMapping("/getConsultVipList.do")
    @ResponseBody
    public ArrayList<ReqConsultVipVO> getConsultVipList(ReqConsultVipVO vipVO) {

        return service.getConsultVipList(vipVO);
    }

    @RequestMapping("/processConsultVip.do")
    @ResponseBody
    public CommonRestRtnVO processConsultVip(@RequestBody ArrayList<ReqConsultVipVO> vipList) {

        service.processCategoryVip(vipList);
        return new CommonRestRtnVO();

    }


}
