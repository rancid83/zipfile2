package emnet.chat.admin.controller.web.admin.statistics;

import emnet.chat.admin.domain.admin.holiday.ReqHolidayVO;
import emnet.chat.admin.domain.admin.statistics.ReqStatWorkUserVO;
import emnet.chat.admin.domain.common.CommonRestRtnVO;
import emnet.chat.admin.service.admin.holiday.HolidayService;
import emnet.chat.admin.service.admin.statistics.StatWorkUserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import java.util.ArrayList;

/**
 * 근무일수 현황
 * 사용자: 관리자
 * 화면유형 : 메인
 */
@RequestMapping("/admin/statWorkUser")
@Controller
public class StatWorkUserController {

    @Autowired
    StatWorkUserService service;
 
    @RequestMapping("/viewStatWorkUser.do")
    public String viewStatWorkUser() {
        return "admin/statistics/viewStatWorkUser.main";
    }

    @RequestMapping("/getStatWorkUserList.do")
    @ResponseBody
    public ArrayList<ReqStatWorkUserVO> getStatWorkUserList(ReqStatWorkUserVO reqStatWorkUserVOVO) {
        return service.getStatWorkUserList(reqStatWorkUserVOVO);
    }

}
