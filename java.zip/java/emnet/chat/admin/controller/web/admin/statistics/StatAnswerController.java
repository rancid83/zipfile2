package emnet.chat.admin.controller.web.admin.statistics;


import emnet.chat.admin.common.define.CommonDefine;
import emnet.chat.admin.common.exception.ExHandler;
import emnet.chat.admin.common.exception.FaultCode;
import emnet.chat.admin.common.utils.SessionUtils;
import emnet.chat.admin.domain.admin.consult.ReqConsultCategoryVO;
import emnet.chat.admin.domain.admin.statistics.ReqStatAnswerVO;
import emnet.chat.admin.domain.admin.statistics.ReqStatSkillVO;
import emnet.chat.admin.domain.common.UserInfoVO;
import emnet.chat.admin.service.admin.consult.ConsultCategoryService;
import emnet.chat.admin.service.admin.statistics.StatAnswerService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.util.HashMap;

/**
 * 일별 상담 현황
 * 사용자: 관리자
 * 화면유형 : 메인
 */
@RequestMapping("/admin/statAnswer")
@Controller
public class StatAnswerController {

    @Autowired
    StatAnswerService service;

    @Autowired
    ConsultCategoryService consultCategoryService;


    @RequestMapping("/viewStatAnswer.do")
    public String viewStatAnswer(Model model) {

        UserInfoVO userInfoVO = SessionUtils.getUserInfo();

        ReqConsultCategoryVO reqConsultCategoryVO = new ReqConsultCategoryVO();
        reqConsultCategoryVO.setService_no(String.valueOf(userInfoVO.getService_no()));

        model.addAttribute("consultCategoryList", consultCategoryService.getCategoryList(reqConsultCategoryVO));
        return "admin/statistics/viewStatAnswer.main";
    }



    @RequestMapping("/getStatAnswerList.do")
    @ResponseBody
    public HashMap<String, Object> getStatAnswerList(ReqStatAnswerVO answerVO) {
        ExHandler.exceptionEmptyMsg(answerVO.getService_no(),FaultCode.INVALID_REQ_BODY);
        ExHandler.exceptionEmptyMsg(answerVO.getLevel3_no(), FaultCode.INVALID_REQ_BODY);
        ExHandler.exceptionEmptyMsg(answerVO.getSch_end_date(), FaultCode.INVALID_REQ_BODY);
        ExHandler.exceptionEmptyMsg(answerVO.getSch_start_date(), FaultCode.INVALID_REQ_BODY);
        ExHandler.exceptionDateFormat(answerVO.getSch_start_date());
        ExHandler.exceptionDateFormat(answerVO.getSch_end_date());

        HashMap resultMap = new HashMap();

        resultMap.put("answerList", service.getStatAnswerList(answerVO));


        return resultMap;
    }



    @RequestMapping("/exceldownload.do")
    @ResponseBody
    public void exceldownload(ReqStatAnswerVO answerVO, HttpServletRequest request, HttpServletResponse response) {

        service.downExcel(answerVO, request, response);
    }
}
