package emnet.chat.admin.controller.web.admin.ars;

import emnet.chat.admin.common.exception.ExHandler;
import emnet.chat.admin.common.exception.FaultCode;
import emnet.chat.admin.domain.admin.ars.ReqArsVO;
import emnet.chat.admin.domain.common.CommonRestRtnVO;
import emnet.chat.admin.service.admin.ars.ArsService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import java.util.ArrayList;

/**
 * ARS(자동안내메시지) 관리
 * 사용자: 관리자
 * 화면유형 : 메인
 */
@RequestMapping("/admin/ars")
@Controller
public class ArsController {

    @Autowired
    ArsService service;

    @RequestMapping("/viewArs.do")
    public String viewArs() {
        return "admin/ars/viewArs.main";
    }

    @RequestMapping("/getArsList.do")
    @ResponseBody
    public ArrayList<ReqArsVO> getArsList(ReqArsVO param) {
        ExHandler.exceptionEmptyMsg(param.getService_no(), FaultCode.INVALID_REQ_BODY);
        return service.getArsList(param);
    }

    @RequestMapping("/processArs.do")
    @ResponseBody
    public CommonRestRtnVO processArs(@RequestBody ArrayList<ReqArsVO> ArsList) {
        service.processArs(ArsList);
        return new CommonRestRtnVO();
    }

}
