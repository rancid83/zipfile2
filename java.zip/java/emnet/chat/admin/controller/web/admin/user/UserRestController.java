package emnet.chat.admin.controller.web.admin.user;

import emnet.chat.admin.common.exception.ExHandler;
import emnet.chat.admin.common.exception.FaultCode;
import emnet.chat.admin.domain.admin.user.userRest.ReqUserRestVO;
import emnet.chat.admin.domain.common.CommonRestRtnVO;
import emnet.chat.admin.service.admin.user.UserRestService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import java.util.ArrayList;

/**
 * 공휴일 관리
 * 사용자: 관리자
 * 화면유형 : 메인
 */
@RequestMapping("/admin/userRest")
@Controller
public class UserRestController {

    @Autowired
    UserRestService service;

    /**
     * 관리자 화면 > 휴가관리
     * */
    @RequestMapping("/viewUserRest.do")
    public String viewUserHoliday() {

        return "admin/user/viewUserRest.main";
    }


    /**
    * 상담사 화면 > 휴가관리
    * */
    @RequestMapping("/viewUserRestRegistPop.do")
    public String viewUserRestRegistPop() {
        return "admin/user/viewUserRestRegistPop.pop";
    }

    /**
     * 관리자 화면 > 신규 > 상담사선택 팝업
     * */
    @RequestMapping("/viewUserRestPopup.do")
    public String viewUserRestPopup() {
        return "admin/user/viewUserRestPopup.pop";
    }


    /**
     * 휴가 리스트 조회
     * */
    @RequestMapping("/getUserRestList.do")
    @ResponseBody
    public ArrayList<ReqUserRestVO> getUserHolidayList(ReqUserRestVO param) {
        ExHandler.exceptionEmptyMsg(param.getSch_end_date(), FaultCode.INVALID_REQ_BODY);
        ExHandler.exceptionEmptyMsg(param.getSch_start_date(), FaultCode.INVALID_REQ_BODY);
        ExHandler.exceptionDateFormat(param.getSch_start_date());
        ExHandler.exceptionDateFormat(param.getSch_end_date());
        return service.getUserRestList(param);
    }

    /**
     * 휴가 DB처리
     * */
    @RequestMapping("/processUserRest.do")
    @ResponseBody
    public CommonRestRtnVO processUserHoliday(@RequestBody ArrayList<ReqUserRestVO> holidayList) {
        service.processUserRest(holidayList);
        return new CommonRestRtnVO();
    }

}
