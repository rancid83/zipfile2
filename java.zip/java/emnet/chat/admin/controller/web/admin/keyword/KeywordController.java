package emnet.chat.admin.controller.web.admin.keyword;

import emnet.chat.admin.common.exception.ExHandler;
import emnet.chat.admin.common.exception.FaultCode;
import emnet.chat.admin.domain.admin.consult.ReqConsultConfAnswerVO;
import emnet.chat.admin.domain.admin.consult.ReqConsultConfQuestionVO;
import emnet.chat.admin.domain.admin.keyword.ReqKeywordCategoryVO;
import emnet.chat.admin.domain.admin.keyword.ReqKeywordTagVO;
import emnet.chat.admin.domain.admin.keyword.ReqKeywordVO;
import emnet.chat.admin.domain.admin.keyword.ResKeywordVO;
import emnet.chat.admin.domain.common.CommonRestRtnVO;
import emnet.chat.admin.service.admin.consult.ConsultConfQuestionService;
import emnet.chat.admin.service.admin.keyword.KeywordService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.servlet.http.HttpSession;
import java.util.ArrayList;

/**
 * 키워드 / 키워드 카테고리 관리 Controller
 * 사용자: 관리자 상담사
 * 화면유형 : 메인
 */
@RequestMapping("/admin/keyword")
@Controller
public class KeywordController {


    @Autowired
    KeywordService service;

    // 키워드

    @RequestMapping("/viewKeyword.do")
    public String viewKeyword() {
        return "admin/keyword/viewKeyword.main";
    }

    @RequestMapping("/viewKeywordPop.do")
    public String viewKeywordPopup() {
        return "admin/keyword/viewKeywordPop.pop";
    }


    @RequestMapping("/processKeyword.do")
    @ResponseBody
    public CommonRestRtnVO processKeyword(@RequestBody ArrayList<ReqKeywordVO> keywordList) {

        service.processKeyword(keywordList);
        return new CommonRestRtnVO();
    }

    @RequestMapping("/getKeywordList.do")
    @ResponseBody
    public ArrayList<ResKeywordVO> getKeywordList(ReqKeywordVO keywordVO) {
        ExHandler.exceptionEmptyMsg(keywordVO.getService_no(), FaultCode.INVALID_REQ_BODY);
        return service.getKeywordList(keywordVO);
    }


    // 키워드 카테고리

    @RequestMapping("/viewKeywordCategoryPopup.do")
    public String viewKeywordCategory(Model model) {
        model.addAttribute("MENU_NAME","키워드 카테고리 관리");
        return "admin/keyword/viewKeywordCategoryPopup.pop";

    }


    @RequestMapping("/getKeywordCategoryList.do")
    @ResponseBody
    public ArrayList<ReqKeywordCategoryVO> getKeywordCategoryList(ReqKeywordCategoryVO keywordCategoryVO) {
        ExHandler.exceptionEmptyMsg(keywordCategoryVO.getService_no(), FaultCode.INVALID_REQ_BODY);
        return service.getKeywordCategoryList(keywordCategoryVO);
    }

    @RequestMapping("/processKeywordCategory.do")
    @ResponseBody
    public CommonRestRtnVO processKeywordCategory(@RequestBody ArrayList<ReqKeywordCategoryVO> keywordCategoryList) {

        service.processKeywordCategory(keywordCategoryList);
        return new CommonRestRtnVO();
    }


    // 키워드 카테고리 태그
    @RequestMapping("/getKeywordCategoryTagList.do")
    @ResponseBody
    public ArrayList<ReqKeywordTagVO> getKeywordCategoryTagList(ReqKeywordTagVO keywordTagVO) {
        ExHandler.exceptionEmptyMsg(keywordTagVO.getService_no(), FaultCode.INVALID_REQ_BODY);
        return service.getKeywordTagList(keywordTagVO);
    }

}
