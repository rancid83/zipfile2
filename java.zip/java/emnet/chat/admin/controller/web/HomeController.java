package emnet.chat.admin.controller.web;

import emnet.chat.admin.common.define.CommonDefine;
import emnet.chat.admin.common.utils.SessionUtils;
import emnet.chat.admin.domain.admin.statistics.ReqStatUserWorkLogVO;
import emnet.chat.admin.domain.admin.system.RspMenuVO;
import emnet.chat.admin.domain.admin.user.ReqUserVO;
import emnet.chat.admin.domain.common.UserInfoVO;
import emnet.chat.admin.service.HomeService;
import emnet.chat.admin.service.admin.statistics.StatUserWorkLogService;
import emnet.chat.admin.service.admin.user.UserService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.util.ArrayList;

@Controller
public class HomeController {

    Logger logger = LoggerFactory.getLogger(HomeController.class);

    @Autowired
    UserService userService;

    @Autowired
    HomeService service;


    @Autowired
    StatUserWorkLogService userWorkLogService;

    @RequestMapping(value = {"/", ""})
    public ModelAndView test(HttpServletResponse res, ModelMap model) throws Exception {


        ModelAndView mav = new ModelAndView();

        UserInfoVO userInfo = SessionUtils.getUserInfo();

        if (userInfo != null) {
            model.addAttribute("PRIVATE_YN", "Y");

            if (userInfo.getAuth_type().equals("ADMIN") || userInfo.getAuth_type().equals("ALL") ) {

                mav.setViewName("redirect:/admin/consult/viewConsult.do");
            } else {
                mav.setViewName("redirect:/chatConsult/viewChatConsult.do");
            }
        }else{
            mav.setViewName("home.login");
        }

        return mav;
    }

    @RequestMapping(value = {"/login.do"})
    public void test(HttpSession session, HttpServletRequest request, HttpServletResponse response, ModelMap model, @RequestParam("emp_no") String emp_no,@RequestParam("service_no") String service_no) throws Exception {
        ReqUserVO userVO = new ReqUserVO();
        userVO.setEmp_no(emp_no);
        userVO.setService_no(service_no);
        ArrayList<ReqUserVO> userList = userService.getUserList(userVO);
        if (!userList.isEmpty()) {
            ReqUserVO loginUserInfo = userList.get(0);

            //사용자 권한 타입 리턴
            //ADMIN: 관리자, COUNSELOR: 상담사, ALL:관리자,상담사,NONE: 무권한
            RspMenuVO params = new RspMenuVO();
            params.setService_no(Integer.valueOf(loginUserInfo.getService_no()));
            params.setUser_no(Integer.valueOf(loginUserInfo.getUser_no()));
            String authType = userService.getUserAuthType(params);

            UserInfoVO sessionUserInfo = new UserInfoVO();
            sessionUserInfo.setService_no(Integer.valueOf(loginUserInfo.getService_no()));
            sessionUserInfo.setUser_no(Integer.valueOf(loginUserInfo.getUser_no()));
            sessionUserInfo.setPermission_no(Integer.valueOf(loginUserInfo.getPermission_no()));
            sessionUserInfo.setUser_id(loginUserInfo.getEmp_no());
            sessionUserInfo.setName(loginUserInfo.getName());
            sessionUserInfo.setEmp_no(loginUserInfo.getEmp_no());
            sessionUserInfo.setDepartment_no(Integer.valueOf(loginUserInfo.getDepartment_no()));
            sessionUserInfo.setAuth_type(authType);
            sessionUserInfo.setReqAddr(request.getRemoteAddr());

            // 세션 위변조 방지 추가
            session.invalidate();
            session = request.getSession(true);

            session.setAttribute(CommonDefine.SESSION_USER, sessionUserInfo);

            ReqStatUserWorkLogVO worklogVO = new ReqStatUserWorkLogVO();
            worklogVO.setService_no(loginUserInfo.getService_no());
            worklogVO.setUser_no(loginUserInfo.getUser_no());
            worklogVO.setIp(request.getRemoteAddr());
            worklogVO.setLog_type(CommonDefine.USER_WORK_LOG_TYPE_LOGIN);
            worklogVO.setContent(loginUserInfo.getEmp_no()+" 접속!");
            worklogVO.setData_regr_id(loginUserInfo.getEmp_no());
            worklogVO.setData_chgr_id(loginUserInfo.getEmp_no());
            userWorkLogService.addUserWorkLog(worklogVO);

            if ("ALL".equals(authType) || "ADMIN".equals(authType)) {
                response.sendRedirect(request.getContextPath()+"/admin/consult/viewConsult.do");
            }else if("COUNSELOR".equals(authType)) {
                response.sendRedirect(request.getContextPath()+"/chatConsult/viewChatConsult.do");
            }else{
                response.sendRedirect(request.getContextPath()+"/");
            }
        }

    }

    @RequestMapping(value = {"/logout.do"})
    public void logout(HttpSession session, HttpServletResponse res, ModelMap model) throws Exception {
        session.removeAttribute(CommonDefine.SESSION_USER);
        res.sendRedirect( "");
    }

}
