package emnet.chat.admin.controller.web.exception;

import emnet.chat.admin.common.exception.CommonException;
import emnet.chat.admin.common.exception.FaultCode;
import emnet.chat.admin.domain.common.CommonRestRtnVO;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

import javax.servlet.http.HttpServletResponse;

@RestControllerAdvice
public class ExceptionController {

    @ExceptionHandler(CommonException.class)
    public CommonRestRtnVO commonException(HttpServletResponse response,CommonException exception) {
        response.setStatus(exception.getStatus().value());
        CommonRestRtnVO rtnVO = new CommonRestRtnVO();
        rtnVO.setResultCode(exception.getError_code());
        rtnVO.setResultMessage(exception.getError_message());
        return rtnVO;
    }


    @ExceptionHandler(Exception.class)
    public CommonRestRtnVO commonException(HttpServletResponse response,Exception exception) {

        exception.printStackTrace();

        response.setStatus(FaultCode.INTERNAL_SERVER_ERROR.getStatus().value());
        CommonRestRtnVO rtnVO = new CommonRestRtnVO();
        rtnVO.setResultCode(FaultCode.INTERNAL_SERVER_ERROR.getCode());
        rtnVO.setResultMessage(FaultCode.INTERNAL_SERVER_ERROR.getDescription());
        return rtnVO;
    }
}
