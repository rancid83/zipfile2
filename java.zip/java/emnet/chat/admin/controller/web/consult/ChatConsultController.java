package emnet.chat.admin.controller.web.consult;

import emnet.chat.admin.common.define.CommonDefine;
import emnet.chat.admin.common.utils.SessionUtils;
import emnet.chat.admin.domain.admin.statistics.ReqStatUserWorkLogVO;
import emnet.chat.admin.domain.common.UserInfoVO;
import emnet.chat.admin.domain.consult.*;
import emnet.chat.admin.service.admin.statistics.StatUserWorkLogService;
import emnet.chat.admin.service.consult.ChatConsultService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

@Controller
@RequestMapping("/chatConsult")
public class ChatConsultController {
    private Logger logger = LoggerFactory.getLogger(ChatConsultController.class);

    @Autowired
    private ChatConsultService chatConsultService;

    @Autowired
    private StatUserWorkLogService userWorkLogService;

    @Value("${websocket.ip}")
    private String websocketIp;

    @RequestMapping("/viewChatConsult.do")
    public String viewChatConsult(HttpSession session, HttpServletRequest request) {
       // [JM]변경
        /*UserInfoVO inSserInfo = new UserInfoVO();
        inSserInfo.setPermission_no(1);
        inSserInfo.setService_no(1);
        inSserInfo.setUser_no(1);
        inSserInfo.setUser_id("USER01");
        inSserInfo.setName("김소희");
        inSserInfo.setAuth_type("ALL");
        session.setAttribute(CommonDefine.SESSION_USER,inSserInfo);*/
        //

        request.setAttribute("websocketIp",websocketIp);

        UserInfoVO userInfo = SessionUtils.getUserInfo();
        ReqGetMenuInfoVO params = new ReqGetMenuInfoVO();
        params.setService_no(userInfo.getService_no());
        params.setUser_no(userInfo.getUser_no());
        ResGetMenuInfoVO menuInfo = chatConsultService.getMenuInfo(params);
        int roomCount = chatConsultService.getUserChatRoomCount(userInfo);
        if(roomCount ==0 || roomCount > 20){
            roomCount = 20;
        }
        menuInfo.setAuthType(userInfo.getAuth_type());
        request.setAttribute("menuInfo",menuInfo);
        request.setAttribute("roomCount",roomCount);

        request.setAttribute("userName",userInfo.getName());

        return "consult/chatConsult.body";
    }

    @RequestMapping("/getHotKeyList.do")
    @ResponseBody
    public ArrayList<MacroVO> getHotKeyList() {

        UserInfoVO userInfo = SessionUtils.getUserInfo();
        MacroVO params = new MacroVO();
        params.setService_no(userInfo.getService_no());
        params.setUser_no(userInfo.getUser_no());
        return chatConsultService.getHotKeyList(params);
    }

    @RequestMapping("/getCustomerHisList.do")
    @ResponseBody
    public ArrayList<ResGetCustomerHisVO> getCustomerHisList(@RequestBody ReqGetCustomerHisVO params) {
        UserInfoVO userInfo = SessionUtils.getUserInfo();
        params.setService_no(userInfo.getService_no());

        return chatConsultService.getCustomerHisList(params);
    }

    @RequestMapping("/getAllKeywordCategoryList.do")
    @ResponseBody
    public ArrayList<KeywordCategoryVO> getAllKeywordCategoryList() {
        return chatConsultService.getAllKeywordCategoryList();
    }

    @RequestMapping("/getCusReqInfoList.do")
    @ResponseBody
    public ArrayList<ComCodeVO> getCusReqInfoList() {
        return chatConsultService.getCusReqInfoList();
    }

    @RequestMapping("/getConsultStateList.do")
    @ResponseBody
    public ArrayList<ComCodeVO> getConsultStateList() {
        return chatConsultService.getConsultStateList();
    }

    @RequestMapping("/getConsultList.do")
    @ResponseBody
    public ArrayList<ResGetConsultVO> getConsultList(@RequestBody ReqGetConsultVO params) {
        UserInfoVO userInfo = SessionUtils.getUserInfo();
        params.setService_no(userInfo.getService_no());
        params.setUser_no(userInfo.getUser_no());

        return chatConsultService.getConsultList(params);
    }

    @RequestMapping("/getConsultStateCount.do")
    @ResponseBody
    public ResGetConsultStateCountVO getConsultStateCount() {

        UserInfoVO userInfo = SessionUtils.getUserInfo();
        ReqGetConsultStateCountVO params = new ReqGetConsultStateCountVO();
        params.setService_no(userInfo.getService_no());
        params.setUser_no(userInfo.getUser_no());

        return chatConsultService.getConsultStateCount(params);
    }

    @RequestMapping("/getKeywordList.do")
    @ResponseBody
    public ArrayList<ResGetKeywordVO> getKeywordList(@RequestBody ReqGetKeywordVO params) {

        UserInfoVO userInfo = SessionUtils.getUserInfo();
        params.setService_no(userInfo.getService_no());
        params.setUser_no(userInfo.getUser_no());

        return chatConsultService.getKeywordList(params);
    }

    @RequestMapping("/getChatContentList.do")
    @ResponseBody
    public ArrayList<ResGetChatContentVO> getChatContentList(@RequestBody ReqGetChatContentVO params) {
        UserInfoVO userInfo = SessionUtils.getUserInfo();
        params.setService_no(userInfo.getService_no());

        return chatConsultService.getChatContentList(params);
    }

    @RequestMapping("/getResetChatRoomList.do")
    @ResponseBody
    public ArrayList<ResGetResetChatRoomVO> getResetChatRoomList() {
        UserInfoVO userInfo = SessionUtils.getUserInfo();
        ReqGetResetChatRoomVO params = new ReqGetResetChatRoomVO();
        params.setService_no(userInfo.getService_no());
        params.setUser_no(userInfo.getUser_no());

        return chatConsultService.getResetChatRoomList(params);
    }


    @RequestMapping("/getPopupInitData.do")
    @ResponseBody
    public ResGetPopupInitDataVO getPopupInitData(){
        UserInfoVO userInfo = SessionUtils.getUserInfo();
        ReqGetPopupInitDataVO params = new ReqGetPopupInitDataVO();
        params.setService_no(userInfo.getService_no());
        params.setUser_no(userInfo.getUser_no());

        return chatConsultService.getPopupInitData(params);
    }

    @RequestMapping("/getSkillMappedUserList.do")
    @ResponseBody
    public List<ComComboVO> getSkillMappedUserList(@RequestBody ReqGetSkillMappedUserVO params){
        UserInfoVO userInfo = SessionUtils.getUserInfo();
        params.setService_no(userInfo.getService_no());

        return chatConsultService.getSkillMappedUserList(params);
    }

    @RequestMapping("/modifyChangeReqCounselor.do")
    @ResponseBody
    public ResMsgVO modifyChangeReqCounselor(@RequestBody ReqModifyChangeReqVO params){
        UserInfoVO userInfo = SessionUtils.getUserInfo();
        params.setService_no(userInfo.getService_no());
        params.setUser_id(userInfo.getUser_id());

        chatConsultService.modifyChangeReqCounselor(params);
        return new ResMsgVO("OK");
    }

    @RequestMapping("/getDepartmentComboList.do")
    @ResponseBody
    public List<ComComboVO> getDepartmentComboList(@RequestBody ReqGetDepartmentComboVO params){
        return chatConsultService.getDepartmentComboList(params);
    }

    @RequestMapping("/getUserComboList.do")
    @ResponseBody
    public List<ComComboVO> getUserComboList(@RequestBody ReqGetUserComboVO params){
        UserInfoVO userInfo = SessionUtils.getUserInfo();
        params.setService_no(userInfo.getService_no());

        return chatConsultService.getUserComboList(params);
    }

    @RequestMapping("/modifyCheckReqCounselor.do")
    @ResponseBody
    public ResMsgVO modifyCheckReqCounselor(@RequestBody ReqModifyChangeReqVO params){

        UserInfoVO userInfo = SessionUtils.getUserInfo();
        params.setService_no(userInfo.getService_no());
        params.setUser_id(userInfo.getUser_id());

        chatConsultService.modifyCheckReqCounselor(params);
        return new ResMsgVO("OK");
    }

    @RequestMapping("/addBlackList.do")
    @ResponseBody
    public ResMsgVO addBlackList(@RequestBody ReqAddBlackListVO params){


        UserInfoVO userInfo = SessionUtils.getUserInfo();
        params.setService_no(userInfo.getService_no());
        params.setUser_no(userInfo.getUser_no());

        chatConsultService.addBlackList(params);
        return new ResMsgVO("OK");
    }

    @RequestMapping("/getUserChatState.do")
    @ResponseBody
    public ResGetUserChatStateVO getUserChatState(){

        UserInfoVO userInfo = SessionUtils.getUserInfo();
        ReqUserChatStateVO params = new ReqUserChatStateVO();
        params.setService_no(userInfo.getService_no());
        params.setUser_no(userInfo.getUser_no());

        return chatConsultService.getUserChatState(params);
    }

    @RequestMapping("/modifyUserDistribute.do")
    @ResponseBody
    public ResMsgVO modifyUserDistribute(@RequestBody ReqModifyUserDistributeVO params){

        UserInfoVO userInfo = SessionUtils.getUserInfo();
        params.setService_no(userInfo.getService_no());
        params.setUser_no(userInfo.getUser_no());
        params.setUser_id(userInfo.getUser_id());

        chatConsultService.modifyUserDistribute(params);
        return new ResMsgVO("OK");
    }

    @RequestMapping("/modifyUserWorkState.do")
    @ResponseBody
    public ResMsgVO modifyUserWorkState(@RequestBody UserWorkStateVO params){
        UserInfoVO userInfo = SessionUtils.getUserInfo();
        params.setService_no(userInfo.getService_no());
        params.setUser_no(userInfo.getUser_no());
        params.setUser_id(userInfo.getUser_id());

        chatConsultService.modifyUserWorkState(params);
        return new ResMsgVO("OK");
    }

    @RequestMapping("/viewChatConsultChatPop.do")
    public String viewChatConsultChatPop(HttpServletRequest request) {


        return "consult/chatConsultPop.body";
    }

    @RequestMapping("/logout.do")
    public void logout(HttpSession session, HttpServletResponse res) throws IOException {
        session.removeAttribute(CommonDefine.SESSION_USER);
        res.sendRedirect("../");
    }

    @RequestMapping("/viewChatContentHisPop.do")
    public String viewChatContentHisPop(HttpServletRequest request) {
        UserInfoVO userInfo = SessionUtils.getUserInfo();

        ConsultInfoVO params = new ConsultInfoVO();
        params.setService_no(userInfo.getService_no());
        params.setConsult_no(request.getParameter("consult_no"));

        ConsultInfoVO consultInfo = chatConsultService.getConsultInfo(params);
        request.setAttribute("consultInfo",consultInfo);

        return "consult/chatContentHisPop.body";
    }

    @RequestMapping("/getChatContentHisList.do")
    @ResponseBody
    public ArrayList<ResGetChatContentVO> getChatContentHisList(@RequestBody ReqGetChatContentVO params) {
        UserInfoVO userInfo = SessionUtils.getUserInfo();
        params.setService_no(userInfo.getService_no());
        params.setUser_no(userInfo.getUser_no());
        params.setData_chgr_id(userInfo.getUser_id());
        params.setData_regr_id(userInfo.getUser_id());

        chatConsultService.addChatContentHisLog(params);

        return chatConsultService.getChatContentList(params);
    }



    @RequestMapping("/viewMecroManagePop.do")
    public String viewMecroManagePop(HttpServletRequest request) {
        return "consult/chatMecroManage.body";
    }

    //grid 테스트
    @RequestMapping("/processPrivateMacro.do")
    @ResponseBody
    public ResMsgVO processPrivateMacro(@RequestBody ArrayList<ReqProcessPrivateMacroVO> reqProcessPrivateMacroList) {
        UserInfoVO userInfo = SessionUtils.getUserInfo();

        chatConsultService.processPrivateMacro(reqProcessPrivateMacroList,userInfo);
        return new ResMsgVO("OK");
    }

    @RequestMapping("/addUserWorkLog.do")
    @ResponseBody
    public ResMsgVO addUserWorkLog(HttpServletRequest request,@RequestBody ComCodeVO comCode){


        UserInfoVO userInfo = SessionUtils.getUserInfo();

        ComCodeVO comCodeParams = new ComCodeVO();
        comCodeParams.setCom_cd(comCode.getCom_cd());
        comCodeParams.setCom_group_cd("CONSULT_REQ_TYPE");
        ComCodeVO dbComCode = chatConsultService.getComCode(comCodeParams);

        ReqStatUserWorkLogVO worklogVO = new ReqStatUserWorkLogVO();
        worklogVO.setService_no(String.valueOf(userInfo.getService_no()));
        worklogVO.setUser_no(String.valueOf(userInfo.getUser_no()));
        worklogVO.setIp(request.getRemoteAddr());
        worklogVO.setLog_type(CommonDefine.USER_WORK_LOG_TYPE_CHAT);
        worklogVO.setContent(userInfo.getEmp_no()+" 정보확인["+dbComCode.getCom_cd_nm()+"]");
        worklogVO.setData_regr_id(userInfo.getEmp_no());
        worklogVO.setData_chgr_id(userInfo.getEmp_no());
        userWorkLogService.addUserWorkLog(worklogVO);

        return new ResMsgVO("OK");
    }



}
