package emnet.chat.admin.common.Filter;

import com.google.gson.Gson;
import com.google.gson.JsonElement;
import emnet.chat.admin.common.utils.JsonUtils;
import emnet.chat.admin.common.utils.SessionUtils;
import emnet.chat.admin.common.utils.StringUtils;
import emnet.chat.admin.domain.admin.system.RspMenuVO;
import emnet.chat.admin.domain.common.UserInfoVO;
import emnet.chat.admin.mapper.mst.admin.system.AccessLogMapper;
import emnet.chat.admin.mapper.mst.admin.system.MenuMapper;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestHeader;

import javax.servlet.*;
import javax.servlet.http.HttpServletRequest;
import java.io.IOException;
import java.util.Enumeration;
import java.util.HashMap;


@Slf4j
public class AccessLogFilter implements Filter {
	@Autowired
	private emnet.chat.admin.mapper.mst.admin.system.MenuMapper menuMapper;

	@Autowired
	private AccessLogMapper accessLogMapper;


	@Override
	public void doFilter(ServletRequest req, ServletResponse res, FilterChain chain)
			throws IOException, ServletException {
		String url = ((HttpServletRequest)req).getRequestURL().toString();
		RereadableRequestWrapper rereadableRequestWrapper = new RereadableRequestWrapper((HttpServletRequest)req);

		if(url.contains("/resources")) {
			chain.doFilter(rereadableRequestWrapper, res);
			return;
		}

		int serviceNo = 0;
		String method = null;
		String fullUrl = null;
		String uri = null;
		String parameters = null;
		String rBody = null;
		String id = null;
		String userName = null;
		int userNo = 0;
		String ip = null;


		
		uri = ((HttpServletRequest)req).getRequestURI();
		String servletPath = ((HttpServletRequest)req).getServletPath();
		String contextPath = ((HttpServletRequest)req).getContextPath();

		parameters = ((HttpServletRequest)req).getQueryString();
		fullUrl = url+(parameters == null ? "" : "?" + parameters);		
		

		
		
		rBody = rereadableRequestWrapper.getRequestBody();


		if(rBody.length() > 2000){
			rBody= "long body";
		}
		/*
		 * Enumeration<String> paramNames = req.getParameterNames();
		 * while(paramNames.hasMoreElements()) { String paramName =
		 * paramNames.nextElement(); String[] paramValues=
		 * req.getParameterMap().get(paramName); for(String value : paramValues) {
		 * System.out.println("Parameter "+paramName+" \t:  " + value); } }
		 */
		
		
		UserInfoVO userInfoVO = (UserInfoVO)SessionUtils.getUserInfo();
		
		if(userInfoVO != null) {
			
			serviceNo = userInfoVO.getService_no();
			userNo = userInfoVO.getUser_no();
			id = userInfoVO.getUser_id();
			userName = userInfoVO.getName();
		}
		
		method = ((HttpServletRequest)req).getMethod();

		//POST Parameter DB처리
		if(method.equalsIgnoreCase("POST")){
			Enumeration<String> paramNames = req.getParameterNames();
			HashMap<String,Object> paramMap = new HashMap<>();
			try {
				while (paramNames.hasMoreElements()) {
					String name = paramNames.nextElement().toString();
					String value = req.getParameter(name);
					paramMap.put(name,value);
				}

			} catch (Exception e) {
				e.printStackTrace();
			}
			parameters = JsonUtils.serialize(paramMap);
		}
		
		HttpServletRequest request = ((HttpServletRequest)req);
		
		ip = request.getHeader("X-Forwarded-For");
		if (ip == null || ip.length() == 0 || "unknown".equalsIgnoreCase(ip)) { 
			ip = request.getHeader("Proxy-Client-IP"); 
		} 
		if (ip == null || ip.length() == 0 || "unknown".equalsIgnoreCase(ip)) { 
			ip = request.getHeader("WL-Proxy-Client-IP"); 
		} 
		if (ip == null || ip.length() == 0 || "unknown".equalsIgnoreCase(ip)) { 
			ip = request.getHeader("HTTP_CLIENT_IP"); 
		} 
		if (ip == null || ip.length() == 0 || "unknown".equalsIgnoreCase(ip)) { 
			ip = request.getHeader("HTTP_X_FORWARDED_FOR"); 
		} 
		if (ip == null || ip.length() == 0 || "unknown".equalsIgnoreCase(ip)) { 
			ip = request.getRemoteAddr(); 
		}

		String viewId = ((HttpServletRequest) req).getHeader("viewId");

		if(viewId == null || "".equals(viewId)){
			if(uri.indexOf("/view") != -1 && serviceNo != 0){
				RspMenuVO param = new RspMenuVO();
				param.setService_no(serviceNo);
				param.setMenu_url(servletPath);
				viewId = menuMapper.selectMenuViewIdByMenuUrl(param);
			}

			if(viewId == null){
				viewId = "";
			}
			req.setAttribute("viewId",viewId);
		}

		String regId = (id != null && "".equals(id)) ? id : "system";

        HashMap<String,Object> insertAccessLogParams = new HashMap<String,Object>();
		insertAccessLogParams.put("view_id", viewId);
		insertAccessLogParams.put("service_no", serviceNo);
		insertAccessLogParams.put("user_no",userNo);
		insertAccessLogParams.put("user_id",id);
		insertAccessLogParams.put("user_name",userName);
		insertAccessLogParams.put("method", method);
		insertAccessLogParams.put("full_url", fullUrl);
		insertAccessLogParams.put("uri", uri);
		insertAccessLogParams.put("parameters", parameters);
		insertAccessLogParams.put("req_body", rBody);
		insertAccessLogParams.put("ip", ip);
		insertAccessLogParams.put("servlet_path",servletPath);
		insertAccessLogParams.put("context_path",contextPath);
		insertAccessLogParams.put("regId",regId);

		/*log.info(insertAccessLogParams.toString(), "System Logging");
		accessLogMapper.insertAccessLog(insertAccessLogParams);*/
		chain.doFilter(rereadableRequestWrapper, res);
		
	}

	@Override
	public void init(FilterConfig filterConfig) throws ServletException {
		
	}

	@Override
	public void destroy() {
		
	}
}
