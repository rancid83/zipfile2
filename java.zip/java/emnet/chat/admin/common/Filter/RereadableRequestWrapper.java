package emnet.chat.admin.common.Filter;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.util.Map;

import javax.servlet.ReadListener;
import javax.servlet.ServletInputStream;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletRequestWrapper;

import com.google.gson.*;
import emnet.chat.admin.common.utils.StringUtils;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.io.IOUtils;
import org.apache.commons.text.StringEscapeUtils;
import org.owasp.encoder.Encode;
import org.springframework.web.bind.annotation.RequestHeader;

@Slf4j
public class RereadableRequestWrapper extends HttpServletRequestWrapper {
    private byte[] bytes;
    private String requestBody;

    public RereadableRequestWrapper(HttpServletRequest request) throws IOException {
        super(request);
        InputStream in = super.getInputStream();
        bytes = IOUtils.toByteArray(in);
        if (request.getHeaderNames() != null) {

            log.debug("header : {}", StringUtils.isEmptyDefault(request.getHeader("Content-Type"), "empty"));
            if (StringUtils.isEmptyDefault(request.getHeader("Content-Type"), "empty").indexOf("application/json") >= 0) {
                bytes = xssFilter(bytes);
            }
        }
        requestBody = new String(bytes);


    }


    private byte[] xssFilter(byte[] bytes) {
        String reqJsonBody = new String(bytes, StandardCharsets.UTF_8);

        log.debug("reqJsonBodyStr : {}" , reqJsonBody);
        JsonElement element = new JsonParser().parse(reqJsonBody);
        element = clean(element);

        String uncapedJsonStr = element.toString();
        return uncapedJsonStr.getBytes(StandardCharsets.UTF_8);

    }


    private static JsonElement clean(JsonElement elem) {
        if (elem.isJsonPrimitive()) { // Base case - we have a Number, Boolean or String
            JsonPrimitive primitive = elem.getAsJsonPrimitive();
            if (primitive.isString()) {
                // Escape all String values
                return new JsonPrimitive(cleanXss(primitive.getAsString()));
            } else {
                return primitive;
            }
        } else if (elem.isJsonArray()) { // We have an array - GSON requires handling this separately
            JsonArray cleanArray = new JsonArray();
            for (JsonElement arrayElement : elem.getAsJsonArray()) {
                cleanArray.add(clean(arrayElement));
            }
            return cleanArray;
        } else if(elem.isJsonNull()) { // Recursive case - iterate over JSON object entries
            JsonNull obj = elem.getAsJsonNull();

            return null;
        }else { // Recursive case - iterate over JSON object entries
            JsonObject obj = elem.getAsJsonObject();
            JsonObject clean = new JsonObject();
            for (Map.Entry<String, JsonElement> entry : obj.entrySet()) {
                // Encode the key right away and encode the value recursively
                clean.add(Encode.forHtml(entry.getKey()), clean(entry.getValue()));
            }
            return clean;
        }


    }

    private static String cleanXss(String value) {
        value = StringEscapeUtils.unescapeHtml4(value);
        value = StringEscapeUtils.escapeHtml4(value);
        value = value.replaceAll("&lt;script&gt;", "");
        value = value.replaceAll("&lt;/script&gt;", "");
        value = value.replaceAll("&lt;br&gt;", "<br>");
        value = value.replaceAll("&lt;waiting_time&gt;" ,"<waiting_time>");

        return value;
    }

    @Override
    public ServletInputStream getInputStream() throws IOException {
        final ByteArrayInputStream bis = new ByteArrayInputStream(bytes);
        return new ServletImpl(bis);
    }

    public String getRequestBody() {
        return this.requestBody;
    }

    class ServletImpl extends ServletInputStream {
        private InputStream is;

        public ServletImpl(InputStream bis) {
            is = bis;
        }

        @Override
        public int read() throws IOException {
            return is.read();
        }

        @Override
        public int read(byte[] b) throws IOException {
            return is.read(b);
        }

        @Override
        public boolean isFinished() {
            // TODO Auto-generated method stub
            return false;
        }

        @Override
        public boolean isReady() {
            // TODO Auto-generated method stub
            return false;
        }

        @Override
        public void setReadListener(ReadListener arg0) {
            // TODO Auto-generated method stub

        }
    }

}
