package emnet.chat.admin.common.interceptor;

import emnet.chat.admin.common.exception.CommonException;
import emnet.chat.admin.common.exception.FaultCode;
import emnet.chat.admin.common.utils.SessionUtils;
import emnet.chat.admin.domain.admin.menu.ReqPermissionMenuVO;
import emnet.chat.admin.domain.common.UserInfoVO;
import emnet.chat.admin.mapper.mst.admin.system.MenuMapper;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.servlet.handler.HandlerInterceptorAdapter;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.util.ArrayList;

@Slf4j
public class AuthCheckInterceptor extends HandlerInterceptorAdapter {


    @Autowired
    MenuMapper menuMapper;

    @Override
    public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler) throws Exception {

        UserInfoVO userInfoVO = SessionUtils.getUserInfo();
        String[] reqPathArr = request.getRequestURI().toString().split("/");


        try {

            if (userInfoVO != null) {

                if (reqPathArr.length == 4) {

                    String baseURL = String.format("/%s/%s/", reqPathArr[1], reqPathArr[2]);

                    ReqPermissionMenuVO reqPermissionMenuVO = new ReqPermissionMenuVO();
                    reqPermissionMenuVO.setService_no(String.valueOf(userInfoVO.getService_no()));
                    reqPermissionMenuVO.setUser_no(String.valueOf(userInfoVO.getUser_no()));

                    reqPermissionMenuVO.setMenu_url(baseURL);
                    ArrayList<ReqPermissionMenuVO> rtnList = menuMapper.selectMenuPermissionByUserNoMenuUrl(reqPermissionMenuVO);


                    if (rtnList.isEmpty()) {
                        //return false;
                        throw new CommonException(FaultCode.INVLID_AUTHORIZATION);

                    } else {
                        log.debug("auth check pass");
                    }
                }
            }
        } catch (Exception e) {
            throw new CommonException(FaultCode.INVLID_AUTHORIZATION);
        }


        return super.preHandle(request, response, handler);
    }
}
