package emnet.chat.admin.common.interceptor;

import java.util.ArrayList;
import java.util.Enumeration;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import emnet.chat.admin.common.exception.CommonException;
import emnet.chat.admin.common.exception.FaultCode;
import emnet.chat.admin.common.utils.JsonUtils;
import emnet.chat.admin.common.utils.SessionUtils;
import emnet.chat.admin.common.utils.StringUtils;
import emnet.chat.admin.domain.admin.menu.ReqPermissionMenuVO;
import emnet.chat.admin.domain.admin.menu.ResPermissionMenuVO;
import emnet.chat.admin.domain.common.UserInfoVO;
import emnet.chat.admin.mapper.mst.admin.system.MenuMapper;
import lombok.extern.slf4j.Slf4j;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.servlet.HandlerInterceptor;

import emnet.chat.admin.common.define.CommonDefine;


@Slf4j
public class LoginCheckInterceptor implements HandlerInterceptor {

    private Logger logger = LoggerFactory.getLogger(LoginCheckInterceptor.class);

    @Autowired
    MenuMapper menuMapper;

    @Override
    public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler) throws Exception {
        HttpSession session = request.getSession();

        if (session.getAttribute(CommonDefine.SESSION_USER) == null) {

            if (request.getHeader("viewId") != null) {
                throw new CommonException(FaultCode.SESSION_FAILED);
            }
            response.setStatus(HttpServletResponse.SC_UNAUTHORIZED);
            response.sendRedirect(request.getContextPath() + "/");
            logger.debug("session check :  fail");

            return true;
        } else {


            UserInfoVO userInfoVO = SessionUtils.getUserInfo();

            //세션 위변조 방지 기능 추가
            if (!userInfoVO.getReqAddr().equals(request.getRemoteAddr())) {
                log.debug("reqAddr : {} : connAddr : {}" , userInfoVO.getReqAddr() , request.getRemoteAddr() );
                session.invalidate();
                throw new CommonException(FaultCode.INVLID_AUTHORIZATION);
            }else{
                log.debug("req Ip address check Success!!!!!!!!!!!!!!!!!");
            }

            if (request.getRequestURL().indexOf("/view") > 0) {

                ReqPermissionMenuVO permissionMenuVO = new ReqPermissionMenuVO();
                permissionMenuVO.setService_no(String.valueOf(userInfoVO.getService_no()));
                permissionMenuVO.setPermission_no(String.valueOf(userInfoVO.getPermission_no()));
                ArrayList<ResPermissionMenuVO> menuList = menuMapper.selectPermissionMenu(permissionMenuVO);
                ResPermissionMenuVO selectedMenu = new ResPermissionMenuVO();

                for (ResPermissionMenuVO menuVO : menuList) {

                    if (!StringUtils.isEmpty(menuVO.getMenu_url())) {
                        if (request.getRequestURL().indexOf(menuVO.getMenu_url()) > 0) {
                            menuVO.setActivate("Y");
                            selectedMenu = menuVO;
                        } else {
                            menuVO.setActivate("N");
                        }
                    }
                }


                request.setAttribute("CURRENT_MENU", selectedMenu);
                request.setAttribute(CommonDefine.MENU_LIST, menuList);
            }




            request.setAttribute(CommonDefine.PRIVATE_YN, userInfoVO.getPermission_no() == CommonDefine.PERMISSION_MANAGER ? "Y" : "N");

            logger.debug("session check :  success");
        }


        return HandlerInterceptor.super.preHandle(request, response, handler);
    }

    /**
     * Show Request Parameter
     *
     * @param request
     * @return void
     * @throws Exception
     */
    public void showParameters(HttpServletRequest request) {


        Enumeration<String> paramNames = request.getParameterNames();

        try {
            while (paramNames.hasMoreElements()) {
                String name = paramNames.nextElement().toString();
                String value = request.getParameter(name);

                logger.debug("PARAM : {} , VALUE : {} ", name, value);

            }

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

}
