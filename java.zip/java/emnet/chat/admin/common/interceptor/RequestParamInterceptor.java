package emnet.chat.admin.common.interceptor;

import java.util.ArrayList;
import java.util.Enumeration;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import emnet.chat.admin.common.define.CommonDefine;
import emnet.chat.admin.common.utils.SessionUtils;
import emnet.chat.admin.domain.admin.consult.ReqConsultStatusVO;
import emnet.chat.admin.domain.common.UserInfoVO;
import emnet.chat.admin.mapper.mst.admin.consult.ConsultMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.web.servlet.HandlerInterceptor;


public class RequestParamInterceptor implements HandlerInterceptor {

    private Logger logger = LoggerFactory.getLogger(RequestParamInterceptor.class);

    @Value("${was.mode:local}")
    private String was_mode;


    @Autowired
    ConsultMapper consultMapper;


    @Override
    public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler)
            throws Exception {
        // TODO Auto-generated method stub
        logger.info("------------------------------------------------------------------------------");
        logger.info("req url : {}", request.getRequestURL());
        showParameters(request);
        logger.info("------------------------------------------------------------------------------");
        request.setAttribute("was_mode", was_mode);
        request.setAttribute("contextPath", request.getContextPath());

        if (request.getRequestURL().indexOf("view") > 0) {
            UserInfoVO userInfoVO = SessionUtils.getUserInfo();

            if (userInfoVO != null) {
                ReqConsultStatusVO statusVO = new ReqConsultStatusVO();
                statusVO.setService_no(String.valueOf(userInfoVO.getService_no()));

                ArrayList<ReqConsultStatusVO> consultStatusList = consultMapper.selectConsultStats(statusVO);
                request.setAttribute("consultStatus", consultStatusList.isEmpty() ? new ReqConsultStatusVO() : consultStatusList.get(0));
            }
        }

        // SESSION INFO PUT
        HttpSession session = request.getSession();

        if (session.getAttribute(CommonDefine.SESSION_USER) != null) {
            UserInfoVO loginUserInfo = SessionUtils.getUserInfo();
            request.setAttribute("SYS_LOGIN_USER_INFO", loginUserInfo);
        }

        return HandlerInterceptor.super.preHandle(request, response, handler);
    }

    /**
     * Show Request Parameter
     *
     * @param request
     * @return void
     * @throws Exception
     */
    public void showParameters(HttpServletRequest request) {


        Enumeration<String> paramNames = request.getParameterNames();

        try {
            while (paramNames.hasMoreElements()) {
                String name = paramNames.nextElement().toString();
                String value = request.getParameter(name);

                logger.debug("PARAM : {} , VALUE : {} ", name, value);

            }

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

}
