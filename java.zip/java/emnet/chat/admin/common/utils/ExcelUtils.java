package emnet.chat.admin.common.utils;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.URLEncoder;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.tomcat.util.buf.Utf8Encoder;
import org.jxls.common.Context;
import org.jxls.util.JxlsHelper;
import org.springframework.core.io.ClassPathResource;
/*
 * Copyright (c) 2020 Emnetworks.
 * All right reserved.
 *
 * This software is the confidential and proprietary information of Emnetworks
 * You shall not disclose such Confidential Information and
 * shall use it only in accordance with the terms of the license agreement
 * you entered into with Emnetworks.
 *
 */
public class ExcelUtils {
	public static void simpleJxlsExcelDownload(HttpServletRequest request, HttpServletResponse response, Object dataList, String prefixFileName, String tempExelFilePath) throws IOException {

		String fileName = prefixFileName+"_"+DateUtils.getDate(DateUtils.FLOW_FULL_FORMAT)+".xls";




		response.setContentType("application/msexcel");
		response.setHeader("Content-Disposition", "attachment; filename="+ URLEncoder.encode(fileName,"UTF-8").replaceAll("\\+","%20") +"");
		InputStream io = new ClassPathResource("templates"+tempExelFilePath).getInputStream();
		OutputStream os = response.getOutputStream();
		Context context = new Context();
		context.putVar("dataList", dataList);
		
		JxlsHelper.getInstance().processTemplate(io, os, context);
	}

	public static void simpleJxlsExcelDownload(HttpServletRequest request, HttpServletResponse response, Object dataList, Object summaryList, String prefixFileName, String tempExelFilePath) throws IOException {

		String fileName = prefixFileName+"_"+DateUtils.getDate(DateUtils.FLOW_FULL_FORMAT)+".xls";




		response.setContentType("application/msexcel");
		response.setHeader("Content-Disposition", "attachment; filename="+ URLEncoder.encode(fileName,"UTF-8").replaceAll("\\+","%20") +"");
		InputStream io = new ClassPathResource("templates"+tempExelFilePath).getInputStream();
		OutputStream os = response.getOutputStream();
		Context context = new Context();
		context.putVar("dataList", dataList);
		context.putVar("dataSummaryList", summaryList);
		JxlsHelper.getInstance().processTemplate(io, os, context);
	}

}
