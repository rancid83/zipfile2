package emnet.chat.admin.common.utils;

import java.util.ArrayList;

import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.AbstractHttpEntity;
import org.apache.http.entity.ByteArrayEntity;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.util.EntityUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

@Component
public class SmsUtils {
	
	

	Logger logger = LoggerFactory.getLogger(SmsUtils.class);
	
	public void sendSmsV2(String callback_No, String phone_No, String msg) {
		HttpClient httpClient = null;
		try {
			NaverSensVO comSmsVO = new NaverSensVO();
			comSmsVO.setType("sms");
			comSmsVO.setFrom("18997275");
			ArrayList<String> toArray = new ArrayList<>();
			toArray.add(phone_No);
			comSmsVO.setTo(toArray);
			comSmsVO.setContent(msg);

			 httpClient = new DefaultHttpClient();
			HttpPost httpPost = new HttpPost(
					"https://api-sens.ncloud.com/v1/sms/services/ncp:sms:kr:125149648351:amano_message/messages");
			httpPost.setHeader("Content-type", "application/json");
			httpPost.setHeader("X-NCP-auth-key", "V28QJcp1KiJefjI20S34");
			httpPost.setHeader("X-NCP-service-secret", "7894516442e8488395fbace1037bed1c");

			AbstractHttpEntity entity;
			entity = new ByteArrayEntity(JsonUtils.serialize(comSmsVO).getBytes("UTF8"));
			httpPost.setEntity(entity);

			// httpClient.execute(post);

			CloseableHttpResponse httpResponse = null;

			httpResponse = (CloseableHttpResponse) httpClient.execute(httpPost);

			String rtn = EntityUtils.toString(httpResponse.getEntity());

			logger.debug("send: {} receive : {}", JsonUtils.serialize(comSmsVO), rtn);
			
		} catch (Exception e) {
			e.printStackTrace();
		}finally {
			if(httpClient != null) {
				httpClient = null;
			}
		}

	}

	public void sendSmsV2(String callback_No, String phone_No, String msg, String subject, String type) {
		HttpClient httpClient = null;
		try {

			if (StringUtils.isMobileNo(phone_No)) {
				NaverSensVO comSmsVO = new NaverSensVO();
				comSmsVO.setType(type);
				comSmsVO.setSubject(subject);
				comSmsVO.setFrom("18997275");
				ArrayList<String> toArray = new ArrayList<>();
				toArray.add(phone_No);
				comSmsVO.setTo(toArray);
				comSmsVO.setContent(msg);

				httpClient = new DefaultHttpClient();
				HttpPost httpPost = new HttpPost(
						"https://api-sens.ncloud.com/v1/sms/services/ncp:sms:kr:125149648351:amano_message/messages");
				httpPost.setHeader("Content-type", "application/json");
				httpPost.setHeader("X-NCP-auth-key", "V28QJcp1KiJefjI20S34");
				httpPost.setHeader("X-NCP-service-secret", "7894516442e8488395fbace1037bed1c");

				AbstractHttpEntity entity;
				entity = new ByteArrayEntity(JsonUtils.serialize(comSmsVO).getBytes("UTF8"));
				httpPost.setEntity(entity);

				// httpClient.execute(post);

				CloseableHttpResponse httpResponse = null;

				httpResponse = (CloseableHttpResponse) httpClient.execute(httpPost);

				String rtn = EntityUtils.toString(httpResponse.getEntity());
				logger.debug("send: {} receive : {}", JsonUtils.serialize(comSmsVO), rtn);

			}

		} catch (Exception e) {
			e.printStackTrace();
		}finally {
			if(httpClient != null) {
				httpClient = null;
			}
		}


	}

	class NaverSensVO {
		private String type;
		private String from;
		private ArrayList<String> to;
		private String subject;
		private String content;

		public String getType() {
			return type;
		}

		public void setType(String type) {
			this.type = type;
		}

		public String getFrom() {
			return from;
		}

		public void setFrom(String from) {
			this.from = from;
		}

		public ArrayList<String> getTo() {
			return to;
		}

		public void setTo(ArrayList<String> to) {
			this.to = to;
		}

		public String getSubject() {
			return subject;
		}

		public void setSubject(String subject) {
			this.subject = subject;
		}

		public String getContent() {
			return content;
		}

		public void setContent(String content) {
			this.content = content;
		}

	}
}