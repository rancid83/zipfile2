package emnet.chat.admin.common.utils;

public class ShortUrlRtnVO {
	
	private String id;
	private String kind;
	private String urlshortener;
	private String longUrl;
	
	
	
	public String getKind() {
		return kind;
	}
	
	public void setKind(String kind) {
		this.kind = kind;
	}
	
	public String getUrlshortener() {
		return urlshortener;
	}
	
	public void setUrlshortener(String urlshortener) {
		this.urlshortener = urlshortener;
	}
	
	public String getLongUrl() {
		return longUrl;
	}
	
	public void setLongUrl(String longUrl) {
		this.longUrl = longUrl;
	}
	
	public String getId() {
		return id;
	}
	
	public void setId(String id) {
		this.id = id;
	}
	
}