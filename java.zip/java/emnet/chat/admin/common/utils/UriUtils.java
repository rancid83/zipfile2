package emnet.chat.admin.common.utils;

public enum UriUtils {

	PARTNER_PARKING_SITE("^(\\/partnerParking\\/v1\\/partnerParkingSite\\/)[a-zA-Z0-9]*$", "N"),
	SUBSCRIBSE("^(\\/partnerParking\\/v1\\/subscription\\/)[a-zA-Z0-9]*$", "Y"),
	GET_PARKING_SITE_BASICS_INFO_LIST("^(\\/partnerParking\\/v1\\/getParkingSiteBasicsInfoList)$", "N"),
	GET_PARKING_TICKET_LIST("^(\\/partnerParking\\/v1\\/getParkingTicketList)$", "N"),
	GET_COUPON_LIST("^(\\/partnerParking\\/v1\\/)[a-zA-Z0-9]*(\\/getCouponList)$", "Y"),
	AUTOMATIC_PAYMENT("^(\\/partnerParking\\/v1\\/)[a-zA-Z0-9]*(\\/automaticPayment)$", "Y"),
	GET_PARKING_IDT_LIST("^(\\/partnerParking\\/v1\\/)[a-zA-Z0-9]*(\\/getParkingIdtList)$", "Y"),
	REQUEST_ADJUSTMENT("^(\\/partnerParking\\/v1\\/)[a-zA-Z0-9]*(\\/requestAdjustment)$", "Y"),
	REQUEST_PAYMENT_COMPLETION_PROCESSING("^(\\/partnerParking\\/v1\\/)[a-zA-Z0-9]*(\\/requestPaymentCompletionProcessing)$", "Y"),
	REQUEST_AUTOMATIC_PAYMENT("^(\\/partnerParking\\/v1\\/)[a-zA-Z0-9]*(\\/requestAutomaticPayment)$", "Y"),
	REQUEST_PAYMENT_CANCEL("^(\\/partnerParking\\/v1\\/)[a-zA-Z0-9]*(\\/requestPaymentCancel)$", "Y");
	
	private String pattern;
	private String checkId;


	UriUtils(String pattern, String checkId) {
		this.pattern = pattern;
		this.checkId = checkId;
	}
	
	public String getPattern() {
		return this.pattern;
	}
	
	public String getCheckId() {
		return this.checkId;
	}
}
