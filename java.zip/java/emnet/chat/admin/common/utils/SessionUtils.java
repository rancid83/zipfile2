package emnet.chat.admin.common.utils;

import org.springframework.web.context.request.RequestAttributes;
import org.springframework.web.context.request.RequestContextHolder;

import emnet.chat.admin.common.define.CommonDefine;
import emnet.chat.admin.domain.common.UserInfoVO;

public class SessionUtils {
    public static UserInfoVO getUserInfo() {

    	return (UserInfoVO) RequestContextHolder.getRequestAttributes().getAttribute(CommonDefine.SESSION_USER, RequestAttributes.SCOPE_SESSION);
    }

}
