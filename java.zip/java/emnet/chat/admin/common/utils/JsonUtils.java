package emnet.chat.admin.common.utils;

import org.springframework.beans.factory.annotation.Value;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

import emnet.chat.admin.common.exception.CommonException;



/**
 * @author hongjae.chu
 * 		
 */
public class JsonUtils {
	
	@Value("${pretty.flag:true}")
	private static boolean PRETTY_FLAG;
	
	/**
	 * Object to String
	 * 
	 * @param obj
	 * @param pretty
	 * @return
	 */
	public static String serialize(Object obj, boolean pretty) {
		String result = "";
		GsonBuilder builder = new GsonBuilder().serializeNulls();
		Gson mapper = new Gson(); 
		try {
			if ( pretty ) {
				mapper = builder.setPrettyPrinting().create();
				result = mapper.toJson(obj);
			} else {
				result = mapper.toJson(obj);
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return result;
	}
	
	
	
	/**
	 * Stirng to Object
	 * 
	 * @param content
	 * @param valueType
	 * @return
	 */
	
	public static <T> T deserialize(String content, Class<T> valueType) throws CommonException {
		
		return null;
	}
	
	public static String serialize(Object obj) {
		return serialize(obj, PRETTY_FLAG);
	}
	
	/**
	 * Stirng to Object
	 * 
	 * @param content
	 * @param valueType
	 * @return
	 */
	
	public static <T> T deserialize(String content) {
		
		return null;
	}



	
	
}
