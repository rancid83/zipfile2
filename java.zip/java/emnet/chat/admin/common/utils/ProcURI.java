package emnet.chat.admin.common.utils;

import java.util.regex.Pattern;

public class ProcURI {
	
	private String api;
	private String checkId;
	
	public ProcURI(String uri, String method) {
		
		if(Pattern.matches(UriUtils.PARTNER_PARKING_SITE.getPattern(),uri))
		{
		     api = "IF_PTNR_001";
		     checkId = UriUtils.PARTNER_PARKING_SITE.getCheckId();
		}
		else if(Pattern.matches(UriUtils.SUBSCRIBSE.getPattern(),uri) && method.equals("POST"))
		{
		     api = "IF_PTNR_002";
		     checkId = UriUtils.SUBSCRIBSE.getCheckId();
		}
		else if(Pattern.matches(UriUtils.SUBSCRIBSE.getPattern(),uri) && method.equals("DELETE"))
		{
		     api = "IF_PTNR_003";
		     checkId = UriUtils.SUBSCRIBSE.getCheckId();
		}
		else if(Pattern.matches(UriUtils.GET_PARKING_SITE_BASICS_INFO_LIST.getPattern(),uri))
		{
		     api = "IF_PTNR_011";
		     checkId = UriUtils.GET_PARKING_SITE_BASICS_INFO_LIST.getCheckId();
		}
		else if(Pattern.matches(UriUtils.GET_PARKING_TICKET_LIST.getPattern(),uri))
		{
		     api = "IF_PTNR_012";
		     checkId = UriUtils.GET_PARKING_TICKET_LIST.getCheckId();
		}
		else if(Pattern.matches(UriUtils.GET_COUPON_LIST.getPattern(),uri))
		{
		     api = "IF_PTNR_013";
		     checkId = UriUtils.GET_COUPON_LIST.getCheckId();
		}
		else if(Pattern.matches(UriUtils.AUTOMATIC_PAYMENT.getPattern(),uri))
		{
		     api = "IF_PTNR_015";
		     checkId = UriUtils.AUTOMATIC_PAYMENT.getCheckId();
		}
		else if(Pattern.matches(UriUtils.GET_PARKING_IDT_LIST.getPattern(),uri))
		{
		     api = "IF_PTNR_016";
		     checkId = UriUtils.GET_PARKING_IDT_LIST.getCheckId();
		}
		else if(Pattern.matches(UriUtils.REQUEST_AUTOMATIC_PAYMENT.getPattern(),uri))
		{
			api = "IF_PTNR_017";
			checkId = UriUtils.REQUEST_AUTOMATIC_PAYMENT.getCheckId();
		}
		else if(Pattern.matches(UriUtils.REQUEST_PAYMENT_CANCEL.getPattern(),uri))
		{
			api = "IF_PTNR_018";
			checkId = UriUtils.REQUEST_PAYMENT_CANCEL.getCheckId();
		}
		else if(Pattern.matches(UriUtils.REQUEST_ADJUSTMENT.getPattern(),uri))
		{
		     api = "IF_PTNR_101";
		     checkId = UriUtils.REQUEST_ADJUSTMENT.getCheckId();
		}
		else if(Pattern.matches(UriUtils.REQUEST_PAYMENT_COMPLETION_PROCESSING.getPattern(),uri))
		{
		     api = "IF_PTNR_102";
		     checkId = UriUtils.REQUEST_PAYMENT_COMPLETION_PROCESSING.getCheckId();
		}
//        else throw new HMException(FaultCode.INVLID_PATH);
	}
	
	public String getApi() {
		return api;
	}
	
	public String getCheckId() {
		return checkId;
	}
}
