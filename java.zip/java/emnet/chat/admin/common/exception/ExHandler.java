package emnet.chat.admin.common.exception;

import org.springframework.http.HttpStatus;

import emnet.chat.admin.common.utils.StringUtils;

public class ExHandler {
	private static final String ONLY_NUMBER_REG = "\\d+";
	
	// null checking - no default value (null --> exception)
	public static void exceptionMsg(String msg, FaultCode faultCode) throws CommonException {
		if ( StringUtils.isBlank(msg) ) {
			throw new CommonException(faultCode);
		}
	}
	
	public static void exceptionMsg(String msg, FaultCode faultCode, String item) throws CommonException {
		if ( StringUtils.isBlank(msg) ) {
			throw new CommonException(faultCode);
		}
	}
	
	
	public static void exceptionNullMsg(Object msg, String code, String message, HttpStatus status) throws CommonException {
		if ( msg == null ) {
			throw new CommonException(code, message, status);
		}
		
		
	}
	
	public static void exceptionNullMsg(Object msg,  FaultCode faultCode) throws CommonException {
		if ( msg == null ) {
			throw new CommonException(faultCode);
		}
		
		
	}
	
	public static void exceptionMsg(Object msg, String code, String message, HttpStatus status) throws CommonException {
		if ( msg == null ) {
			throw new CommonException(code, message, status);
		}
	}
	
	public static void exceptionEmptyMsg(String msg, FaultCode faultCode) throws CommonException {
		if (  StringUtils.isEmpty(msg)  ) {
			throw new CommonException(faultCode);
		}
	}
	
	public static void exceptionEmptyMsg(String msg, String code, String message, HttpStatus status) throws CommonException {
		if ( StringUtils.isEmpty(msg) ) {
			throw new CommonException(code, message, status);
		}
	}
	
	public static void exceptionLimitSize(int compareNum, int limit, FaultCode faultCode) throws CommonException {
		if ( compareNum >= limit ) {
			throw new CommonException(faultCode);
		}
	}
	
	// Number
	public static void exceptionNumber(String msg) throws CommonException {
		if ( msg != null && msg.matches(ONLY_NUMBER_REG) == false ) {
			throw new CommonException(FaultCode.IS_NOT_NUMBER);
		}
	}
	
	// Number
	public static void exceptionNumber(String msg, FaultCode faultCode) throws CommonException {
		if ( msg != null && msg.matches(ONLY_NUMBER_REG) == false ) {
			throw new CommonException(faultCode);
		}
	}
	
	public static void exceptionIncludeMsg(String[] args, String value, FaultCode faultCode) throws CommonException {
		boolean result = false;
		for (String item : args) {
			
			if ( item.equals(value) ) {
				result = true;
			}
		}
		
		if ( !result ) {
			throw new CommonException(faultCode);
		}
	}

	public static void exceptionDateStrFormat(String msg) {
		String dateRule = "((19|20)\\d\\d)(0?[1-9]|1[012])(0?[1-9]|[12][0-9]|3[01])([01]?[0-9]|2[0-3])[0-5][0-9][0-5][0-9]";

		if(msg.length() != 14) {
			throw new CommonException(FaultCode.INVALID_REQ_BODY);
		}
		if ( !msg.matches(dateRule) ) {
			throw new CommonException(FaultCode.INVALID_REQ_BODY);
		}

	}
	
	public static void exceptionDateFormat(String msg) {
		String dateRule = "^\\d{4}[\\-\\/\\s]?((((0[13578])|(1[02]))[\\-\\/\\s]?(([0-2][0-9])|(3[01])))|(((0[469])|(11))[\\-\\/\\s]?(([0-2][0-9])|(30)))|(02[\\-\\/\\s]?[0-2][0-9]))$";

		if ( !msg.matches(dateRule) ) {
			throw new CommonException(FaultCode.INVALID_REQ_BODY);
		}
		
	}
	
}
