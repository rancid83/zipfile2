package emnet.chat.admin.common.exception;

import org.springframework.http.HttpStatus;

/**
 * @author dukkyoo.kim
 * 
 */
public enum FaultCode {

	  SUCCESS(HttpStatus.ACCEPTED, "EMNET-00000", "Success")	
	, SESSION_FAILED(HttpStatus.FORBIDDEN, "EMNET-00000", "세션이  종료 되었습니다.")	

	, IS_MANDATORY(HttpStatus.BAD_REQUEST, "EMNET-41000", "Mandatory")

	
	, NO_RESULT(HttpStatus.ACCEPTED, "EMNET-21000", " No Result")
	, IS_NOT_NUMBER(HttpStatus.BAD_REQUEST, "EMNET-40000", "Is Not Number")
	, IS_NOT_DATETIME(HttpStatus.BAD_REQUEST, "EMNET-40000", "Is Not DateTime{yyyymmddHHMiss} Format")
	, DUPLICATE_KEY(HttpStatus.INTERNAL_SERVER_ERROR, "EMNET-60000","Duplicate Key")
	
	, DUPLICATE_REQUEST_ID(HttpStatus.INTERNAL_SERVER_ERROR, "EMNET-400-000","DUPLICATE_REQUEST_ID")
	, INVALID_ACCESS_KEY(HttpStatus.BAD_REQUEST, "EMNET-42000", " INVALID ACCESS_KEY")
	, INVALID_ID(HttpStatus.BAD_REQUEST, "EMNET-42000", " INVALID ID")
	, BAD_REQUEST(HttpStatus.BAD_REQUEST, "EMNET-42000", " 잘못된 요청입니다. ")
	, INVALID_REQ_BODY(HttpStatus.BAD_REQUEST, "EMNET-42000", " 올바른 조회조건이 아닙니다.")
	, INTERNAL_SERVER_ERROR(HttpStatus.INTERNAL_SERVER_ERROR, "EMNET-50000", "Internal server error")
	, INVLID_AUTHORIZATION(HttpStatus.BAD_REQUEST, "EMNET-400-002", "권한이 없습니다. ")
	, INVLID_SUBSCRIBE_INFO(HttpStatus.BAD_REQUEST, "EMNET-400-003", "INVLID_SUBSCRIBE_INFO")
	, INVLID_PARTNER_PARKING_ID_INFO(HttpStatus.BAD_REQUEST, "EMNET-400-004", "INVLID_PARTNER_PARKING_ID_INFO")
	, NO_CONTENT(HttpStatus.BAD_REQUEST, "EMNET-400-011", "NO_CONTENT")
	
	;

	private final String code;
	private final HttpStatus status;
	private final String description;

	private FaultCode(HttpStatus status, String code, String description) {
		this.status = status;
		this.code = code;
		this.description = description;
	}

	public String getCode() {
		return code;
	}

	public String getDescription() {
		return description;
	}

	public String toString() {

		return code + ": " + description;
	}

	/**
	 * @return the status
	 */
	public HttpStatus getStatus() {
		return status;
	}

}

