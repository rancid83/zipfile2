package emnet.chat.admin.common.define;

public class CommonDefine {
    public static final String SESSION_USER = "UserInfo";
    public static final String PRIVATE_YN = "PRIVATE_YN";
    public static final String MENU_LIST = "MENU_LIST";
    public static final int PERMISSION_MANAGER = 1;
    public static final int PERMISSION_CONSULT = 2;
    public static final String USER_WORK_LOG_TYPE_LOGIN = "LOGIN";
    public static final String USER_WORK_LOG_TYPE_CHAT = "CHAT";
}
