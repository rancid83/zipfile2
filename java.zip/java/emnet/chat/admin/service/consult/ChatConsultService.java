package emnet.chat.admin.service.consult;

import emnet.chat.admin.domain.common.UserInfoVO;
import emnet.chat.admin.domain.consult.*;
import emnet.chat.admin.mapper.mst.consult.ConsultChatMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service
public class ChatConsultService {

    @Autowired
    private ConsultChatMapper consultChatMapper;

    public ArrayList<MacroVO> getHotKeyList(MacroVO params) {


        return consultChatMapper.selectHotKeyList(params);
    }

    public ArrayList<ResGetCustomerHisVO> getCustomerHisList(ReqGetCustomerHisVO params) {
        return consultChatMapper.selectCustomerHisList(params);
    }

    public ArrayList<KeywordCategoryVO> getAllKeywordCategoryList() {
        return consultChatMapper.selectAllKeywordCategoryList();
    }

    public ArrayList<ComCodeVO> getCusReqInfoList() {
        return consultChatMapper.selectComCodeByCateCd("CONSULT_REQ_TYPE");
    }

    public ArrayList<ComCodeVO> getConsultStateList() {
        return consultChatMapper.selectComCodeByCateCd("CONSULT_STATUS");
    }

    public ComCodeVO getComCode(ComCodeVO params) {
        return consultChatMapper.selectComCode(params);
    }

    public ArrayList<ResGetConsultVO> getConsultList(ReqGetConsultVO params) {
        return consultChatMapper.selectConsultList(params);
    }

    public ResGetConsultStateCountVO getConsultStateCount(ReqGetConsultStateCountVO params) {
        return consultChatMapper.selectConsultStateCount(params);
    }

    public ArrayList<ResGetKeywordVO> getKeywordList(ReqGetKeywordVO params) {
        return consultChatMapper.selectKeywordList(params);
    }

    public ArrayList<ResGetChatContentVO> getChatContentList(ReqGetChatContentVO params) {
        return consultChatMapper.selectChatContentList(params);
    }

    public ArrayList<ResGetResetChatRoomVO> getResetChatRoomList(ReqGetResetChatRoomVO params) {
        return consultChatMapper.selectResetChatRoomList(params);
    }

    public ResGetPopupInitDataVO getPopupInitData(ReqGetPopupInitDataVO params) {
        ResGetPopupInitDataVO returnValue = consultChatMapper.selectCounselorInfo(params);
        List<ComComboVO> categorySkillComboList =  consultChatMapper.selectCategorySkillComboList(params);

        ReqGetDepartmentComboVO departmentComboParam = new ReqGetDepartmentComboVO();
        departmentComboParam.setDepartment_no(0);
        List<ComComboVO> departmentComboList = consultChatMapper.selectDepartmentComboList(departmentComboParam);
        returnValue.setDepartmentComboList(departmentComboList);
        returnValue.setCategorySkillComboList(categorySkillComboList);
        return returnValue;
    }

    public List<ComComboVO> getSkillMappedUserList(ReqGetSkillMappedUserVO params) {
        return consultChatMapper.selectSkillMappedUserList(params);
    }

    public void modifyChangeReqCounselor(ReqModifyChangeReqVO params) {
        params.setReq_type("CHANGE");
        consultChatMapper.updateChangeReq(params);
    }

    public List<ComComboVO> getDepartmentComboList(ReqGetDepartmentComboVO params) {
        return consultChatMapper.selectDepartmentComboList(params);
    }

    public List<ComComboVO> getUserComboList(ReqGetUserComboVO params) {
        return consultChatMapper.selectUserComboList(params);
    }

    public void modifyCheckReqCounselor(ReqModifyChangeReqVO params) {
        params.setReq_type("REVIEW");
        consultChatMapper.updateChangeReq(params);
    }

    public void addBlackList(ReqAddBlackListVO params) {
        consultChatMapper.insertBlackList(params);
    }

    public ResGetUserChatStateVO getUserChatState(ReqUserChatStateVO params) {
        return consultChatMapper.selectUserChatState(params);
    }

    public void modifyUserDistribute(ReqModifyUserDistributeVO params) {
        consultChatMapper.updateUserDistribute(params);

    }

    public void modifyUserWorkState(UserWorkStateVO params) {
        //
        WorkStateHistoryVO workStateHistory = consultChatMapper.selectLastWorkHistoryByState(params);

        if(workStateHistory != null || workStateHistory.getEnd_date() == null){
            workStateHistory.setUser_id(params.getUser_id());
            consultChatMapper.updateWorkStateHistoryEndDt(workStateHistory);
        }

        params.setWork_status_type(params.getNew_work_status_type());
        consultChatMapper.insertWorkStateHistory(params);

        String newWorkStateType = params.getNew_work_status_type();
        //상담사의 상태 셋팅
        String workYn = null;
        if("CONSULT".equals(newWorkStateType)){
            workYn = "Y";
        }else{
            workYn = "N";
        }

        params.setWork_yn(workYn);
        params.setWork_status_type(params.getNew_work_status_type());
        consultChatMapper.updateUserWorkState(params);
    }

    public ResGetMenuInfoVO getMenuInfo(ReqGetMenuInfoVO params) {
        ResGetMenuInfoVO returnValue = new ResGetMenuInfoVO();
        //마이메뉴하위 조회
        params.setParent_menu_no(3);
        List<ConsultMenuVO> myMenuList = consultChatMapper.selectPermissionMenuByPNo(params);

        //통계 메뉴 하위 조회
        params.setParent_menu_no(4);
        List<ConsultMenuVO> statisticsMenuList = consultChatMapper.selectPermissionMenuByPNo(params);

        returnValue.setMyMenuList(myMenuList);
        returnValue.setStatisticsMenuList(statisticsMenuList);
        return returnValue;
    }

    public void processPrivateMacro(ArrayList<ReqProcessPrivateMacroVO> reqProcessPrivateMacroList, UserInfoVO userInfo) {
        for(int i=0; i < reqProcessPrivateMacroList.size(); i++){
            ReqProcessPrivateMacroVO reqProcessPrivateMacro = reqProcessPrivateMacroList.get(i);
            MacroVO params = new MacroVO();
            params.setUser_no(userInfo.getUser_no());
            params.setService_no(userInfo.getService_no());
            params.setMacro_content(reqProcessPrivateMacro.getMacro_content());
            params.setMacro_key(reqProcessPrivateMacro.getMacro_key());
            params.setData_chgr_id(userInfo.getUser_id());
            params.setData_regr_id(userInfo.getUser_id());

            switch (reqProcessPrivateMacro.getDt_state_flag()){
                case "I" :
                    consultChatMapper.insertMacro(params);
                    break;
                case "U" :
                    params.setMacro_no(reqProcessPrivateMacro.getMacro_no());
                    consultChatMapper.updateMacro(params);
                    break;
                case "D" :
                    params.setMacro_no(reqProcessPrivateMacro.getMacro_no());
                    consultChatMapper.deleteMacro(params);
                    break;
            }
        }


    }

    public void addChatContentHisLog(ReqGetChatContentVO params) {
        consultChatMapper.insertChatContentHisLog(params);
    }

    public ConsultInfoVO getConsultInfo(ConsultInfoVO params) {
        return consultChatMapper.selectConsultInfo(params);
    }

    public int getUserChatRoomCount(UserInfoVO params) {
        return consultChatMapper.selectUserChatRoomCount(params);
    }
}
