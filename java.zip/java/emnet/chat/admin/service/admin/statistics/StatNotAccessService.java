package emnet.chat.admin.service.admin.statistics;

import emnet.chat.admin.common.utils.ExcelUtils;
import emnet.chat.admin.domain.admin.statistics.ReqStatNotAccessVO;
import emnet.chat.admin.domain.admin.statistics.ResStatNotAccessVO;
import emnet.chat.admin.mapper.mst.admin.statistics.StatNotAccessMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.util.ArrayList;
import java.util.List;

@Service
public class StatNotAccessService {

    @Autowired
    private StatNotAccessMapper mapper;

    /**
     * 일자별 상담현황 통계조회
     *
     * @param reqStatNotAccessVO
     * @return
     */
    public ArrayList<ResStatNotAccessVO> getStatNotAccessList(ReqStatNotAccessVO reqStatNotAccessVO) {
        return (ArrayList<ResStatNotAccessVO>) mapper.selectStatNotAccessList(reqStatNotAccessVO);
    }

    /**
     * 일자별 상담현황 통계조회
     *
     * @param reqStatNotAccessVO
     * @return
     */
    public ArrayList<ResStatNotAccessVO> getStatNotAccessSummaryList(ReqStatNotAccessVO reqStatNotAccessVO) {
        return (ArrayList<ResStatNotAccessVO>) mapper.selectStatNotAccessSummaryList(reqStatNotAccessVO);
    }
    public void downExcel(ReqStatNotAccessVO param, HttpServletRequest request, HttpServletResponse response) {
        try {
            String prefixFileName = "미분배 상담현황";
            String tempExelFilePath = "/statistics/StatNotAccess_template.xls";
            List<ResStatNotAccessVO> dataList = mapper.selectStatNotAccessList(param);
            List<ResStatNotAccessVO> summaryList = mapper.selectStatNotAccessSummaryList(param);
            ExcelUtils.simpleJxlsExcelDownload(request, response, dataList, summaryList,prefixFileName, tempExelFilePath);
        } catch (Exception e) {
            e.printStackTrace();
        }

    }

}
