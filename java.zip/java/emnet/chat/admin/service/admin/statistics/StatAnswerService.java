package emnet.chat.admin.service.admin.statistics;

import emnet.chat.admin.common.utils.ExcelUtils;
import emnet.chat.admin.domain.admin.statistics.ReqStatAnswerVO;
import emnet.chat.admin.domain.admin.statistics.ReqStatCustomerVO;
import emnet.chat.admin.domain.admin.statistics.ResStatAnswerVO;
import emnet.chat.admin.domain.admin.statistics.ResStatCustomerVO;
import emnet.chat.admin.mapper.mst.admin.statistics.StatAnswerMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.util.ArrayList;
import java.util.List;

@Service
public class StatAnswerService {

    @Autowired
    private StatAnswerMapper mapper;

    /**
     * 만족도 현황 통계조회
     *
     * @param reqStatAnswerVO
     * @return
     */
    public ArrayList<ResStatAnswerVO> getStatAnswerList(ReqStatAnswerVO reqStatAnswerVO) {
        return (ArrayList<ResStatAnswerVO>) mapper.selectStatAnswerList(reqStatAnswerVO);
    }

    public void downExcel(ReqStatAnswerVO param, HttpServletRequest request, HttpServletResponse response) {
        try {
            String prefixFileName = "만족도현황";
            String tempExelFilePath = "/statistics/StatAnswer_template.xls";
            List<ResStatAnswerVO> dataList = mapper.selectStatAnswerList(param);
            ExcelUtils.simpleJxlsExcelDownload(request, response, dataList,prefixFileName, tempExelFilePath);
        } catch (Exception e) {
            e.printStackTrace();
        }

    }


}
