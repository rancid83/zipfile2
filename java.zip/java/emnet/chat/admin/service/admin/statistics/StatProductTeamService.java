package emnet.chat.admin.service.admin.statistics;

import emnet.chat.admin.common.utils.ExcelUtils;
import emnet.chat.admin.domain.admin.statistics.*;
import emnet.chat.admin.domain.admin.statistics.ReqStatProductTeamVO;
import emnet.chat.admin.domain.admin.statistics.ResStatProductTeamVO;
import emnet.chat.admin.mapper.mst.admin.statistics.StatProductTeamMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.util.ArrayList;
import java.util.List;

@Service
public class StatProductTeamService {

    @Autowired
    private StatProductTeamMapper mapper;

    /**
     * 생산성 - 팀별
     *
     * @param reqStatProductTeamVO
     * @return
     */
    public ArrayList<ResStatProductTeamVO> getStatProductTeamList(ReqStatProductTeamVO reqStatProductTeamVO) {

        return (ArrayList<ResStatProductTeamVO>) mapper.selectStatProductTeamList(reqStatProductTeamVO);
    }

    /**
     * 생산성 - 팀별 누적
     *
     * @param reqStatProductTeamVO
     * @return
     */
    public ArrayList<ResStatProductTeamVO> getStatProductTeamSummaryList(ReqStatProductTeamVO reqStatProductTeamVO) {
        return (ArrayList<ResStatProductTeamVO>) mapper.selectStatProductTeamSummaryList(reqStatProductTeamVO);
    }

    public void downExcel(ReqStatProductTeamVO param, HttpServletRequest request, HttpServletResponse response) {
        try {
            String prefixFileName = "팀별 생산성 현황";
            String tempExelFilePath = "/statistics/StatProductTeam_template.xls";
            List<ResStatProductTeamVO> dataList = mapper.selectStatProductTeamList(param);
            List<ResStatProductTeamVO> dataSummaryList = mapper.selectStatProductTeamSummaryList(param);

            ExcelUtils.simpleJxlsExcelDownload(request, response, dataList, dataSummaryList,prefixFileName, tempExelFilePath);
        } catch (Exception e) {
            e.printStackTrace();
        }

    }

}
