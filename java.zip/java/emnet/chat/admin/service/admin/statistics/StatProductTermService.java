package emnet.chat.admin.service.admin.statistics;

import emnet.chat.admin.common.utils.ExcelUtils;
import emnet.chat.admin.domain.admin.statistics.ReqStatProductDailyVO;
import emnet.chat.admin.domain.admin.statistics.ReqStatProductTermVO;
import emnet.chat.admin.domain.admin.statistics.ResStatProductDailyVO;
import emnet.chat.admin.domain.admin.statistics.ResStatProductTermVO;
import emnet.chat.admin.mapper.mst.admin.statistics.StatProductTermMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.util.ArrayList;
import java.util.List;

@Service
public class StatProductTermService {

    @Autowired
    private StatProductTermMapper mapper;

    /**
     * 생산성 - 기간별
     *
     * @param reqStatProductTermVO
     * @return
     */
    public ArrayList<ResStatProductTermVO> getStatProductTermList(ReqStatProductTermVO reqStatProductTermVO) {

        return (ArrayList<ResStatProductTermVO>) mapper.selectStatProductTermList(reqStatProductTermVO);
    }

    public void downExcel(ReqStatProductTermVO param, HttpServletRequest request, HttpServletResponse response) {
        try {
            String prefixFileName = "기간별 생산성 현황";
            String tempExelFilePath = "/statistics/StatProductTerm_template.xls";
            List<ResStatProductTermVO> dataList = mapper.selectStatProductTermList(param);

            ExcelUtils.simpleJxlsExcelDownload(request, response, dataList, prefixFileName, tempExelFilePath);
        } catch (Exception e) {
            e.printStackTrace();
        }

    }

}
