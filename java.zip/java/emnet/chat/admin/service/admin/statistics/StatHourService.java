package emnet.chat.admin.service.admin.statistics;

import emnet.chat.admin.common.utils.ExcelUtils;
import emnet.chat.admin.domain.admin.statistics.ReqStatDailyVO;
import emnet.chat.admin.domain.admin.statistics.ReqStatHourVO;
import emnet.chat.admin.domain.admin.statistics.ResStatDailyVO;
import emnet.chat.admin.domain.admin.statistics.ResStatHourVO;
import emnet.chat.admin.mapper.mst.admin.statistics.StatHourMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.util.ArrayList;
import java.util.List;

@Service
public class StatHourService {

    @Autowired
    private StatHourMapper mapper;

    /**
     * 일자별 상담현황 통계조회
     *
     * @param reqStatHourVO
     * @return
     */
    public ArrayList<ResStatHourVO> getStatHourList(ReqStatHourVO reqStatHourVO) {
        return (ArrayList<ResStatHourVO>) mapper.selectStatHourList(reqStatHourVO);
    }

    /**
     * 일자별 상담현황 통계조회
     *
     * @param reqStatHourVO
     * @return
     */
    public ArrayList<ResStatHourVO> getStatHourSummaryList(ReqStatHourVO reqStatHourVO) {
        return (ArrayList<ResStatHourVO>) mapper.selectStatHourSummaryList(reqStatHourVO);
    }
    public void downExcel(ReqStatHourVO param, HttpServletRequest request, HttpServletResponse response) {
        try {
            String prefixFileName = "시간대별상담현황";
            String tempExelFilePath = "/statistics/StatHour_template.xls";
            List<ResStatHourVO> dataList = mapper.selectStatHourList(param);
            List<ResStatHourVO> summaryList = mapper.selectStatHourSummaryList(param);
            ExcelUtils.simpleJxlsExcelDownload(request, response, dataList, summaryList,prefixFileName, tempExelFilePath);
        } catch (Exception e) {
            e.printStackTrace();
        }

    }

}
