package emnet.chat.admin.service.admin.statistics;

import emnet.chat.admin.common.utils.ExcelUtils;
import emnet.chat.admin.domain.admin.statistics.ReqStatCustomerVO;
import emnet.chat.admin.domain.admin.statistics.ReqStatSkillVO;
import emnet.chat.admin.domain.admin.statistics.ResStatCustomerVO;
import emnet.chat.admin.domain.admin.statistics.ResStatSkillVO;
import emnet.chat.admin.mapper.mst.admin.statistics.StatSkillMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.util.ArrayList;
import java.util.List;

@Service
public class StatSkillService {

    @Autowired
    private StatSkillMapper mapper;

    /**
     * 일자별 상담현황 통계조회
     *
     * @param reqStatSkillVO
     * @return
     */
    public ArrayList<ResStatSkillVO> getStatSkillList(ReqStatSkillVO reqStatSkillVO) {
        return (ArrayList<ResStatSkillVO>) mapper.selectStatSkillList(reqStatSkillVO);
    }

    /**
     * 일자별 상담현황 통계조회
     *
     * @param reqStatSkillVO
     * @return
     */
    public ArrayList<ResStatSkillVO> getStatSkillSummaryList(ReqStatSkillVO reqStatSkillVO) {
        return (ArrayList<ResStatSkillVO>) mapper.selectStatSkillSummaryList(reqStatSkillVO);
    }
    public void downExcel(ReqStatSkillVO param, HttpServletRequest request, HttpServletResponse response) {
        try {
            String prefixFileName = "유형별현황";
            String tempExelFilePath = "/statistics/StatSkill_template.xls";
            List<ResStatSkillVO> dataList = mapper.selectStatSkillList(param);
            List<ResStatSkillVO> dataSummaryList = mapper.selectStatSkillSummaryList(param);

            ExcelUtils.simpleJxlsExcelDownload(request, response, dataList,dataSummaryList,prefixFileName, tempExelFilePath);
        } catch (Exception e) {
            e.printStackTrace();
        }

    }


}
