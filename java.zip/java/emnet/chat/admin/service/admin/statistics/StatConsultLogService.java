package emnet.chat.admin.service.admin.statistics;

import emnet.chat.admin.common.utils.ExcelUtils;
import emnet.chat.admin.domain.admin.statistics.ReqStatConsultLogVO;
import emnet.chat.admin.domain.admin.statistics.ReqStatHourVO;
import emnet.chat.admin.domain.admin.statistics.ResStatConsultLogVO;
import emnet.chat.admin.domain.admin.statistics.ResStatHourVO;
import emnet.chat.admin.mapper.mst.admin.statistics.StatConsultLogMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.util.ArrayList;
import java.util.List;

@Service
public class StatConsultLogService {

    @Autowired
    private StatConsultLogMapper mapper;

    /**
     * 일자별 상담현황 통계조회
     *
     * @param reqStatConsultLogVO
     * @return
     */
    public ArrayList<ResStatConsultLogVO> getStatConsultLogList(ReqStatConsultLogVO reqStatConsultLogVO) {
        return (ArrayList<ResStatConsultLogVO>) mapper.selectStatConsultLogList(reqStatConsultLogVO);
    }




    public void downExcel(ReqStatConsultLogVO param, HttpServletRequest request, HttpServletResponse response) {
        try {
            String prefixFileName = "고객현황";
            String tempExelFilePath = "/statistics/StatConsultLog_template.xls";
            List<ResStatConsultLogVO> dataList = mapper.selectStatConsultLogList(param);
            ExcelUtils.simpleJxlsExcelDownload(request, response, dataList,prefixFileName, tempExelFilePath);
        } catch (Exception e) {
            e.printStackTrace();
        }

    }

}
