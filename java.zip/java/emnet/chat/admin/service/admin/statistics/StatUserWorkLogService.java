package emnet.chat.admin.service.admin.statistics;

import emnet.chat.admin.common.utils.ExcelUtils;
import emnet.chat.admin.domain.admin.statistics.ReqStatUserWorkLogVO;
import emnet.chat.admin.domain.admin.statistics.ResStatUserWorkLogVO;
import emnet.chat.admin.mapper.mst.admin.statistics.StatUserWorkLogMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.util.ArrayList;
import java.util.List;

@Service
public class StatUserWorkLogService {

    @Autowired
    private StatUserWorkLogMapper mapper;

    public ArrayList<ResStatUserWorkLogVO> getStatUserWorkLogList(ReqStatUserWorkLogVO reqStatUserWorkLogVO) {
        return (ArrayList<ResStatUserWorkLogVO>) mapper.selectStatUserWorkLogList(reqStatUserWorkLogVO);
    }

    public void addUserWorkLog(ReqStatUserWorkLogVO param) {
        mapper.insertUserWorkLog(param);
    }


    public void downExcel(ReqStatUserWorkLogVO param, HttpServletRequest request, HttpServletResponse response) {
        try {
            String prefixFileName = "접속현황";
            String tempExelFilePath = "/statistics/StatWorkLog_template.xls";
            List<ResStatUserWorkLogVO> dataList = mapper.selectStatUserWorkLogList(param);

            ExcelUtils.simpleJxlsExcelDownload(request, response, dataList, prefixFileName, tempExelFilePath);
        } catch (Exception e) {
            e.printStackTrace();
        }

    }

}
