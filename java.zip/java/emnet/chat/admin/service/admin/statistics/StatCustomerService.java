package emnet.chat.admin.service.admin.statistics;

import emnet.chat.admin.common.utils.ExcelUtils;
import emnet.chat.admin.domain.admin.statistics.ReqStatConsultLogVO;
import emnet.chat.admin.domain.admin.statistics.ReqStatCustomerVO;
import emnet.chat.admin.domain.admin.statistics.ResStatConsultLogVO;
import emnet.chat.admin.domain.admin.statistics.ResStatCustomerVO;
import emnet.chat.admin.mapper.mst.admin.statistics.StatCustomerMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.util.ArrayList;
import java.util.List;

@Service
public class StatCustomerService {

    @Autowired
    private StatCustomerMapper mapper;

    /**
     * 상담 카테고리 그룹  리스트 리턴
     *
     * @param reqStatCustomerVO
     * @return
     */
    public ArrayList<ResStatCustomerVO> getStatCustomerList(ReqStatCustomerVO reqStatCustomerVO) {
        return (ArrayList<ResStatCustomerVO>) mapper.selectStatCustomerList(reqStatCustomerVO);
    }

    public void downExcel(ReqStatCustomerVO param, HttpServletRequest request, HttpServletResponse response) {
        try {
            String prefixFileName = "고객현황";
            String tempExelFilePath = "/statistics/StatCustomer_template.xls";
            List<ResStatCustomerVO> dataList = mapper.selectStatCustomerList(param);
            ExcelUtils.simpleJxlsExcelDownload(request, response, dataList,prefixFileName, tempExelFilePath);
        } catch (Exception e) {
            e.printStackTrace();
        }

    }

}
