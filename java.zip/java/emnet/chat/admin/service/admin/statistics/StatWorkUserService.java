package emnet.chat.admin.service.admin.statistics;

import emnet.chat.admin.domain.admin.statistics.ReqStatWorkUserVO;
import emnet.chat.admin.mapper.mst.admin.statistics.StatWorkUserMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;

@Service
public class StatWorkUserService {

    @Autowired
    StatWorkUserMapper mapper;

    /**
     * 상담 카테고리 그룹  리스트 리턴
     *
     * @param reqStatWorkUserVO
     * @return
     */
    public ArrayList<ReqStatWorkUserVO> getStatWorkUserList(ReqStatWorkUserVO reqStatWorkUserVO) {
        return (ArrayList<ReqStatWorkUserVO>) mapper.selectStatWorkUserList(reqStatWorkUserVO);
    }


}
