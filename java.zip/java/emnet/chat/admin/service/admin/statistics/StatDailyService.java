package emnet.chat.admin.service.admin.statistics;

import emnet.chat.admin.common.utils.ExcelUtils;
import emnet.chat.admin.domain.admin.statistics.ReqStatDailyVO;
import emnet.chat.admin.domain.admin.statistics.ReqStatUserWorkLogVO;
import emnet.chat.admin.domain.admin.statistics.ResStatDailyVO;
import emnet.chat.admin.domain.admin.statistics.ResStatUserWorkLogVO;
import emnet.chat.admin.mapper.mst.admin.statistics.StatDailyMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.util.ArrayList;
import java.util.List;

@Service
public class StatDailyService {

    @Autowired
    private StatDailyMapper mapper;

    /**
     * 일자별 상담현황 통계조회
     *
     * @param reqStatDailyVO
     * @return
     */
    public ArrayList<ResStatDailyVO> getStatDailyList(ReqStatDailyVO reqStatDailyVO) {
        return (ArrayList<ResStatDailyVO>) mapper.selectStatDailyList(reqStatDailyVO);
    }

    /**
     * 일자별 상담현황 통계조회
     *
     * @param reqStatDailyVO
     * @return
     */
    public ArrayList<ResStatDailyVO> getStatDailySummaryList(ReqStatDailyVO reqStatDailyVO) {
        return (ArrayList<ResStatDailyVO>) mapper.selectStatDailySummaryList(reqStatDailyVO);
    }


    public void downExcel(ReqStatDailyVO param, HttpServletRequest request, HttpServletResponse response) {
        try {
            String prefixFileName = "일별상담현황";
            String tempExelFilePath = "/statistics/StatDaily_template.xls";
            List<ResStatDailyVO> dataList = mapper.selectStatDailyList(param);
            List<ResStatDailyVO> summaryList = mapper.selectStatDailySummaryList(param);
            ExcelUtils.simpleJxlsExcelDownload(request, response, dataList, summaryList,prefixFileName, tempExelFilePath);
        } catch (Exception e) {
            e.printStackTrace();
        }

    }


}
