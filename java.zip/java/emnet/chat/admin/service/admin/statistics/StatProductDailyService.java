package emnet.chat.admin.service.admin.statistics;

import emnet.chat.admin.common.utils.ExcelUtils;
import emnet.chat.admin.domain.admin.statistics.ReqStatHourVO;
import emnet.chat.admin.domain.admin.statistics.ReqStatProductDailyVO;
import emnet.chat.admin.domain.admin.statistics.ResStatHourVO;
import emnet.chat.admin.domain.admin.statistics.ResStatProductDailyVO;
import emnet.chat.admin.mapper.mst.admin.statistics.StatProductDailyMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.util.ArrayList;
import java.util.List;

@Service
public class StatProductDailyService {

    @Autowired
    private StatProductDailyMapper mapper;

    /**
     * 생산성 - 일자별
     *
     * @param reqStatProductDailyVO
     * @return
     */
    public ArrayList<ResStatProductDailyVO> getStatProductDailyList(ReqStatProductDailyVO reqStatProductDailyVO) {

        return (ArrayList<ResStatProductDailyVO>) mapper.selectStatProductDailyList(reqStatProductDailyVO);
    }

    public void downExcel(ReqStatProductDailyVO param, HttpServletRequest request, HttpServletResponse response) {
        try {
            String prefixFileName = "일자별 생산성 현황";
            String tempExelFilePath = "/statistics/StatProductDaily_template.xls";
            List<ResStatProductDailyVO> dataList = mapper.selectStatProductDailyList(param);

            ExcelUtils.simpleJxlsExcelDownload(request, response, dataList, prefixFileName, tempExelFilePath);
        } catch (Exception e) {
            e.printStackTrace();
        }

    }
}
