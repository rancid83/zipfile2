package emnet.chat.admin.service.admin.holiday;

import emnet.chat.admin.common.utils.SessionUtils;
import emnet.chat.admin.domain.admin.holiday.ReqHolidayVO;
import emnet.chat.admin.domain.common.UserInfoVO;
import emnet.chat.admin.mapper.mst.admin.holiday.HolidayMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;

@Service
public class HolidayService {

    @Autowired
    HolidayMapper mapper;

    /**
     * 상담 카테고리 그룹  리스트 리턴
     *
     * @param reqConsultVipVO
     * @return
     */
    public ArrayList<ReqHolidayVO> getHolidayList(ReqHolidayVO reqConsultVipVO) {
        return (ArrayList<ReqHolidayVO>) mapper.selectHolidayList(reqConsultVipVO);
    }
    /**
     * 상담 카테고리 그룹  리스트 리턴
     *
     * @param holidayList
     * @return
     */
    public void processHoliday(ArrayList<ReqHolidayVO> holidayList) {

        UserInfoVO userInfoVO = SessionUtils.getUserInfo();

        for (ReqHolidayVO param : holidayList) {

            param.setData_chgr_id(userInfoVO.getEmp_no());
            param.setData_regr_id(userInfoVO.getEmp_no());

            if (param.getDel_flag().equals("1")) {
                mapper.deleteHoliday(param);
            } else {
                switch (param.getDat_flag()) {
                    case "I":
                        mapper.insertHoliday(param);
                        break;
                    case "U":
                        mapper.updateHoliday(param);
                        break;
                }
            }
        }
    }

}
