package emnet.chat.admin.service.admin.user;

import emnet.chat.admin.common.utils.SessionUtils;
import emnet.chat.admin.domain.admin.user.userRest.ReqUserRestVO;
import emnet.chat.admin.domain.admin.user.userSkill.ReqUserSkillVO;
import emnet.chat.admin.domain.common.ComCodeDtlVO;
import emnet.chat.admin.domain.common.UserInfoVO;
import emnet.chat.admin.mapper.mst.admin.user.UserRestMapper;
import emnet.chat.admin.mapper.mst.admin.user.UserSkillMapper;
import emnet.chat.admin.mapper.mst.system.ComCodeMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.HashMap;

@Service
public class UserSkillService {

    @Autowired
    UserSkillMapper mapper;


    /**
     * 사용자 휴일(휴무) 리스트 리턴
     *
     * @param userSkillVO
     * @return
     */
    public ArrayList<ReqUserSkillVO> getUserSkillList(ReqUserSkillVO userSkillVO) {
        return (ArrayList<ReqUserSkillVO>) mapper.selectUserSkillList(userSkillVO);
    }

    /**
     * 사용자 휴일(휴무) DB 처리
     *
     * @param holidayList
     * @return
     */
    public void processUserSkill(ArrayList<ReqUserSkillVO> holidayList) {

        UserInfoVO userInfoVO = SessionUtils.getUserInfo();

        for (ReqUserSkillVO param : holidayList) {

            param.setData_chgr_id(userInfoVO.getEmp_no());
            param.setData_regr_id(userInfoVO.getEmp_no());

            if (param.getDel_flag().equals("1")) {
                mapper.deleteUserSkill(param);
            } else {
                switch (param.getDat_flag()) {
                    case "I":
                        mapper.insertUserSkill(param);
                        break;
                    case "U":
                        mapper.updateUserSkill(param);
                        break;
                }
            }
        }
    }

}
