package emnet.chat.admin.service.admin.user;

import emnet.chat.admin.common.utils.SessionUtils;
import emnet.chat.admin.domain.admin.user.userCategory.ReqUserCategoryVO;
import emnet.chat.admin.domain.common.UserInfoVO;
import emnet.chat.admin.mapper.mst.admin.user.UserCategoryMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;

@Service
public class UserCategoryService {

    @Autowired
    UserCategoryMapper mapper;


    /**
     * 사용자 카테고리 (대분류 )리스트 리턴
     *
     * @param userCategoryVO
     * @return
     */
    public ArrayList<ReqUserCategoryVO> selectUserCategoryList(ReqUserCategoryVO userCategoryVO) {
        return (ArrayList<ReqUserCategoryVO>) mapper.selectUserCategoryList(userCategoryVO);
    }

    /**
     * 사용자 카테고리 (대분류 ) DB 처리
     *
     * @param categoryList
     * @return
     */
    public void processUserCategory(ArrayList<ReqUserCategoryVO> categoryList) {

        UserInfoVO userInfoVO = SessionUtils.getUserInfo();


        for (ReqUserCategoryVO param : categoryList) {
            param.setData_chgr_id(userInfoVO.getEmp_no());
            param.setData_regr_id(userInfoVO.getEmp_no());

            if (param.getDel_flag().equals("1")) {
                mapper.deleteUserCategory(param);
            } else {
                switch (param.getDat_flag()) {
                    case "I":
                        mapper.insertUserCategory(param);
                        break;
                    case "U":
                        mapper.updateUserCategory(param);
                        break;
                }
            }
        }
    }

}
