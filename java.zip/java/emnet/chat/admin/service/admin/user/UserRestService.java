package emnet.chat.admin.service.admin.user;

import emnet.chat.admin.common.utils.SessionUtils;
import emnet.chat.admin.domain.admin.user.userRest.ReqUserRestVO;
import emnet.chat.admin.domain.common.ComCodeDtlVO;
import emnet.chat.admin.domain.common.UserInfoVO;
import emnet.chat.admin.mapper.mst.admin.user.UserRestMapper;
import emnet.chat.admin.mapper.mst.system.ComCodeMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.HashMap;

@Service
public class UserRestService {

    @Autowired
    UserRestMapper mapper;

    @Autowired
    ComCodeMapper comCodeMapper;

    /**
     * 사용자 휴일(휴무) 리스트 리턴
     *
     * @param userRestVO
     * @return
     */
    public ArrayList<ReqUserRestVO> getUserRestList(ReqUserRestVO userRestVO) {
        return (ArrayList<ReqUserRestVO>) mapper.selectUserRestList(userRestVO);
    }

    /**
     * 사용자 휴일(휴무) DB 처리
     *
     * @param holidayList
     * @return
     */
    public void processUserRest(ArrayList<ReqUserRestVO> holidayList) {


        ComCodeDtlVO codeDtlVO = new ComCodeDtlVO();
        codeDtlVO.setCom_group_cd("REST_TYPE");

        UserInfoVO userInfoVO = SessionUtils.getUserInfo();

        ArrayList<ComCodeDtlVO> codeList = comCodeMapper.selectComCodeList(codeDtlVO);
        HashMap<String, ComCodeDtlVO> codeMap = new HashMap<>();
        for (ComCodeDtlVO code : codeList) {
            codeMap.put(code.getCom_cd(), code);
        }


        for (ReqUserRestVO param : holidayList) {

            param.setData_chgr_id(userInfoVO.getEmp_no());
            param.setData_regr_id(userInfoVO.getEmp_no());

            if (param.getDel_flag().equals("1")) {
                mapper.deleteUserRest(param);
            } else {
                switch (param.getDat_flag()) {
                    case "I":
                        mapper.insertUserRest(param);
                        break;
                    case "U":
                        mapper.updateUserRest(param);
                        break;
                }
            }
        }
    }

}
