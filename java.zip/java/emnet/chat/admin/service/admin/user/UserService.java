package emnet.chat.admin.service.admin.user;

import emnet.chat.admin.common.utils.SessionUtils;
import emnet.chat.admin.domain.admin.system.RspMenuVO;
import emnet.chat.admin.domain.admin.user.ReqUserVO;
import emnet.chat.admin.domain.common.UserInfoVO;
import emnet.chat.admin.mapper.mst.admin.user.UserMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;

@Service
public class UserService {


    @Autowired
    private UserMapper mapper;


    /**
     * 사용자(상담원 )  리스트 리턴
     * @param reqUserVO
     * @return
     */
    public ArrayList<ReqUserVO> getUserList(ReqUserVO reqUserVO){
        return (ArrayList<ReqUserVO>) mapper.selectUserList(reqUserVO);
    }

    /**
     * 사용자(상담원 )  DB 처리
     *
     * @param userList
     * @return
     */
    public void processUser(ArrayList<ReqUserVO> userList) {
        UserInfoVO userInfoVO = SessionUtils.getUserInfo();

        for (ReqUserVO param : userList) {

            param.setData_chgr_id(userInfoVO.getEmp_no());
            param.setData_regr_id(userInfoVO.getEmp_no());

            if (param.getDel_flag().equals("1")) {
                mapper.deleteUser(param);
            } else {
                switch (param.getDat_flag()) {
                    case "I":
                        mapper.insertUser(param);
                        break;
                    case "U":
                        mapper.updateUser(param);
                        break;
                }
            }
        }
    }

    //사용자 권한 타입 리턴
    //ADMIN: 관리자, COUNSELOR: 상담사, ALL:관리자,상담사,NONE: 무권한
    public String getUserAuthType (RspMenuVO params){
        params.setParent_menu_no(1);
        String adminYn = mapper.selectCheckMenuChildYn(params);
        params.setParent_menu_no(2);
        String counselorYn = mapper.selectCheckMenuChildYn(params);

        String returnValue = null;
        if("Y".equals(adminYn) && "Y".equals(counselorYn)){
            returnValue = "ALL";
        }else if("Y".equals(adminYn)){
            returnValue = "ADMIN";
        }else if("Y".equals(counselorYn)){
            returnValue = "COUNSELOR";
        }else{
            returnValue = "NONE";
        }

        return returnValue;
    }
}
