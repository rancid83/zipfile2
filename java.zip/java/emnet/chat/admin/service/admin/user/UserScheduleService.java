package emnet.chat.admin.service.admin.user;

import emnet.chat.admin.common.utils.DateUtils;
import emnet.chat.admin.common.utils.SessionUtils;
import emnet.chat.admin.common.utils.StringUtils;
import emnet.chat.admin.domain.admin.service.ReqServiceScheduleBatchVO;
import emnet.chat.admin.domain.admin.service.ResServiceScheduleVO;
import emnet.chat.admin.domain.admin.user.ReqUserVO;
import emnet.chat.admin.domain.admin.user.userSchedule.ReqUserScheduleEtcVO;
import emnet.chat.admin.domain.admin.user.userSchedule.ReqUserScheduleVO;
import emnet.chat.admin.domain.admin.user.userSchedule.ResUserScheduleEtcVO;
import emnet.chat.admin.domain.admin.user.userSchedule.ResUserScheduleVO;
import emnet.chat.admin.domain.common.UserInfoVO;
import emnet.chat.admin.mapper.mst.admin.user.UserScheduleMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;

@Service
public class UserScheduleService {

    @Autowired
    private UserScheduleMapper mapper;


    /**
     * 상담사 스케줄 리스트 리턴
     *
     * @param scheduleVO 스케줄 조회조건
     * @return ArrayList<ResUserScheduleVO>
     */
    public ArrayList<ResUserScheduleVO> getUserScheduleList(ReqUserScheduleVO scheduleVO) {
        return (ArrayList<ResUserScheduleVO>) mapper.selectUserScheduleList(scheduleVO);
    }


    public void processUserScheduleBatch(ReqServiceScheduleBatchVO batchVO) {

        String startDate = StringUtils.replace(batchVO.getStart_date(), "-", "") + "000000";
        String endDate = StringUtils.replace(batchVO.getEnd_date(), "-", "") + "000000";

        HashMap<String, ResServiceScheduleVO> weekMap = new HashMap<>();

        for (ResServiceScheduleVO scheduleVO : batchVO.getDateList()) {
            weekMap.put(scheduleVO.getWeek_cd(), scheduleVO);
        }
        Date currDate = DateUtils.convertDate(startDate, DateUtils.FULL_DATE_FORMAT);

        UserInfoVO userInfoVO = SessionUtils.getUserInfo();

        while (startDate.compareTo(endDate) <= 0) {

            currDate = DateUtils.convertDate(startDate, DateUtils.FULL_DATE_FORMAT);


            Calendar currDateCal = Calendar.getInstance();
            currDateCal.setTime(currDate);
            String currWeekStr = String.valueOf(currDateCal.get(Calendar.DAY_OF_WEEK));
            ResServiceScheduleVO currentWeekScheduleVO = weekMap.get(currWeekStr);

            ReqUserScheduleVO userScheduleVO = new ReqUserScheduleVO();

            // 기존 데이터 저장내역 조회
            ReqUserScheduleVO param = new ReqUserScheduleVO();
            param.setSchedule_date(DateUtils.convertDateFormat(currDate, DateUtils.BASE_DAY_FORMAT));
            ArrayList<ResUserScheduleVO> registList = (ArrayList<ResUserScheduleVO>) mapper.selectUserScheduleList(param);

            HashMap<String, ResUserScheduleVO> userMap = new HashMap<>();

            for (ResUserScheduleVO scheduleVO : registList) {
                userMap.put(scheduleVO.getUser_no(), scheduleVO);
            }

            for (ReqUserVO userVO : batchVO.getUserList()) {
                // 사용자 기초 데이터 생성
                userScheduleVO = new ReqUserScheduleVO();
                userScheduleVO.setService_no(userVO.getService_no());
                userScheduleVO.setUser_no(userVO.getUser_no());
                userScheduleVO.setSchedule_date(DateUtils.convertDateFormat(currDate, DateUtils.BASE_DAY_FORMAT));
                userScheduleVO.setLunch_start_time(currentWeekScheduleVO.getLunch_start_time());
                userScheduleVO.setLunch_end_time(currentWeekScheduleVO.getLunch_end_time());
                userScheduleVO.setRest_start_time(currentWeekScheduleVO.getRest_start_time());
                userScheduleVO.setRest_end_time(currentWeekScheduleVO.getRest_end_time());
                userScheduleVO.setData_chgr_id(userInfoVO.getEmp_no());
                userScheduleVO.setData_regr_id(userInfoVO.getEmp_no());

                //기존에 생성된 근무내역이 없는 경우 신규생성 , 있는 경우 업데이트처리
                if (!userMap.containsKey(userVO.getUser_no())) {
                    mapper.insertUserSchedule(userScheduleVO);
                } else {
                    userScheduleVO.setUser_schedule_no(userMap.get(userVO.getUser_no()).getUser_schedule_no());
                    mapper.updateUserSchedule(userScheduleVO);
                }

            }

            currDate = DateUtils.addDays(currDate, 1);
            startDate = DateUtils.convertDateFormat(currDate, DateUtils.FULL_DATE_FORMAT);
        }


    }

    /**
     * 상담사 스케줄 DB 처리
     *
     * @param scheduleList 스케줄 처리 List
     */
    public void processUserSchedule(ArrayList<ReqUserScheduleVO> scheduleList) {

        for (ReqUserScheduleVO scheduleVO : scheduleList) {

            if (scheduleVO.getDel_flag().equals("1")) {
                mapper.deleteUserSchedule(scheduleVO);
            } else {
                switch (scheduleVO.getDat_flag()) {
                    case "I":
                        mapper.insertUserSchedule(scheduleVO);
                        break;
                    case "U":
                        mapper.updateUserSchedule(scheduleVO);
                        break;
                }
            }
        }
    }


    /**
     * 상담사 스케줄 Etc 리스트 리턴
     *
     * @param scheduleVO 스케줄 조회조건
     * @return ArrayList<ResUserScheduleVO>
     */
    public ArrayList<ResUserScheduleEtcVO> getUserScheduleEtcList(ReqUserScheduleEtcVO scheduleVO) {
        return (ArrayList<ResUserScheduleEtcVO>) mapper.selectUserScheduleEtcList(scheduleVO);
    }


    /**
     * 상담사 스케줄 Etc DB 처리
     *
     * @param scheduleList 스케줄 처리 List
     */
    public void processUserScheduleEtc(ArrayList<ReqUserScheduleEtcVO> scheduleList) {

        for (ReqUserScheduleEtcVO scheduleVO : scheduleList) {

            if (scheduleVO.getDel_flag().equals("1")) {
                mapper.deleteUserScheduleEtc(scheduleVO);
            } else {
                switch (scheduleVO.getDat_flag()) {
                    case "I":
                        mapper.insertUserScheduleEtc(scheduleVO);
                        break;
                    case "U":
                        mapper.updateUserScheduleEtc(scheduleVO);
                        break;
                }
            }
        }
    }

}
