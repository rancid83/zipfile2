package emnet.chat.admin.service.admin.ars;

import emnet.chat.admin.common.utils.SessionUtils;
import emnet.chat.admin.domain.admin.ars.ReqArsVO;
import emnet.chat.admin.domain.common.UserInfoVO;
import emnet.chat.admin.mapper.mst.admin.ars.ArsMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;

@Service
public class ArsService {

    @Autowired
    ArsMapper mapper;

    public ArrayList<ReqArsVO> getArsList(ReqArsVO reqConsultVipVO) {
        return (ArrayList<ReqArsVO>) mapper.selectArsList(reqConsultVipVO);
    }
    
    public void processArs(ArrayList<ReqArsVO> ArsList) {

        UserInfoVO userInfoVO = SessionUtils.getUserInfo();

        for (ReqArsVO param : ArsList) {

            param.setData_chgr_id(userInfoVO.getEmp_no());
            param.setData_regr_id(userInfoVO.getEmp_no());

            if (param.getDel_flag().equals("1")) {
                mapper.deleteArs(param);
            } else {
                switch (param.getDat_flag()) {
                    case "I":
                        mapper.insertArs(param);
                        break;
                    case "U":
                        mapper.updateArs(param);
                        break;
                }
            }
        }
    }

}
