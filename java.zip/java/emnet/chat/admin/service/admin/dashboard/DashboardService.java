package emnet.chat.admin.service.admin.dashboard;

import emnet.chat.admin.domain.admin.dashboard.*;
import emnet.chat.admin.mapper.mst.admin.dashboard.DashboardMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;

@Service
public class DashboardService {

    @Autowired
    DashboardMapper dashboardMapper;

    /**
     * 대시보드 - 일별 대기수 , 상담사 수 , 상담건수 평균 대기시간 조회
     *
     * @return
     */
    public ArrayList<ResDashboardSummaryVO> getDailySummary(ReqDashboardVO reqDashboardVO) {

        return dashboardMapper.selectDailySummary(reqDashboardVO);
    }

    /**
     * 대시보드 - 상담사현황
     *
     * @return
     */
    public ArrayList<ResDashboardUserVO> getDailyUser(ReqDashboardVO reqDashboardVO) {

        return dashboardMapper.selectDailyUser(reqDashboardVO);
    }
    /**
     * 대시보드 - 시간대 현황
     *
     * @return
     */
    public ArrayList<ResDashboardHourVO> getHour(ReqDashboardVO reqDashboardVO) {

        return dashboardMapper.selectHour(reqDashboardVO);
    }

    /**
     * 대시보드 - 일별 현황
     *
     * @return
     */
    public ArrayList<ResDashboardDailyVO> getDaily(ReqDashboardVO reqDashboardVO) {

        return dashboardMapper.selectDaily(reqDashboardVO);
    }


    /**
     * 대시보드 - 상담사별 시간대 현황
     *
     * @return
     */
    public ArrayList<ResDashboardHourVO> getHourUser(ReqDashboardVO reqDashboardVO) {

        return dashboardMapper.selectHourUser(reqDashboardVO);
    }


}
