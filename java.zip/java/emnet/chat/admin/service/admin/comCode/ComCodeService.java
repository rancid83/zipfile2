package emnet.chat.admin.service.admin.comCode;

import emnet.chat.admin.common.utils.JsonUtils;
import emnet.chat.admin.common.utils.SessionUtils;
import emnet.chat.admin.domain.common.ComCodeDtlVO;
import emnet.chat.admin.domain.common.ComCodeMstVO;
import emnet.chat.admin.domain.common.UserInfoVO;
import emnet.chat.admin.domain.common.cache.ComCodeCacheVO;
import emnet.chat.admin.mapper.mst.system.ComCodeMapper;
import lombok.extern.slf4j.Slf4j;
import net.sf.ehcache.Cache;
import net.sf.ehcache.CacheManager;
import net.sf.ehcache.Element;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.annotation.PostConstruct;
import java.util.ArrayList;
import java.util.HashMap;

@Service
@Slf4j
public class ComCodeService {

    public static final String CACHE_CODE = "comCdCache";

    @Autowired
    private ComCodeMapper comCodeMapper;

    @Autowired
    CacheManager cacheManager;

    @PostConstruct
    public void initComCode() {
        ArrayList<ComCodeDtlVO> codeList = comCodeMapper.selectComCodeList(new ComCodeDtlVO());

        Cache cache = cacheManager.getCache(CACHE_CODE);
        cache.removeAll();
        ArrayList<ComCodeDtlVO> groupCodeList = new ArrayList<>();
        HashMap<String, ArrayList<ComCodeDtlVO>> codeMap = new HashMap<>();
        for (ComCodeDtlVO codeDtlVO : codeList) {
            if (codeMap.containsKey(codeDtlVO.getCom_group_cd())) {
                groupCodeList = codeMap.get(codeDtlVO.getCom_group_cd());
            } else {
                groupCodeList = new ArrayList<>();
            }
            groupCodeList.add(codeDtlVO);
            codeMap.put(codeDtlVO.getCom_group_cd(), groupCodeList);
        }

        for (String codeName : codeMap.keySet()) {
            cache.put(new Element(codeName, codeMap.get(codeName)));
        }
    }


    /**
     * 공통코드 그룹 리스트 리턴
     *
     * @param comCodeMstVO
     * @return
     */
    public ArrayList<ComCodeMstVO> getComCodeGroupList(ComCodeMstVO comCodeMstVO) {
        return (ArrayList<ComCodeMstVO>) comCodeMapper.selectComCodeGroupList(comCodeMstVO);
    }

    public void processComGroupCode(ArrayList<ComCodeMstVO> codeGroupList) {

        UserInfoVO userInfoVO = SessionUtils.getUserInfo();


        for (ComCodeMstVO groupCode : codeGroupList) {
            groupCode.setData_chgr_id(userInfoVO.getEmp_no());
            groupCode.setData_regr_id(userInfoVO.getEmp_no());
            if (groupCode.getDel_flag().equals("1")) {
                comCodeMapper.deleteComCodeMst(groupCode);
            } else {
                switch (groupCode.getDat_flag()) {
                    case "I":
                        comCodeMapper.insertComCodeMst(groupCode);
                        break;
                    case "U":
                        comCodeMapper.updateComCodeMst(groupCode);
                        break;
                }
            }
        }

        initComCode();
    }

    public ArrayList<ComCodeDtlVO> getComCodeList(ComCodeDtlVO codeVO) {
        return comCodeMapper.selectComCodeList(codeVO);
    }

    public void processComCode(ArrayList<ComCodeDtlVO> codeList) {

        UserInfoVO userInfoVO = SessionUtils.getUserInfo();


        for (ComCodeDtlVO code : codeList) {
            code.setData_chgr_id(userInfoVO.getEmp_no());
            code.setData_regr_id(userInfoVO.getEmp_no());
            if (code.getDel_flag().equals("1")) {
                comCodeMapper.deleteComCode(code);
            } else {
                switch (code.getDat_flag()) {
                    case "I":
                        comCodeMapper.insertComCode(code);
                        break;
                    case "U":
                        comCodeMapper.updateComCode(code);
                        break;
                }
            }
        }

        initComCode();
    }

    public ArrayList<ComCodeCacheVO> getComComboCache(ArrayList<ComCodeCacheVO> cacheCodeList) {

        Cache cache = cacheManager.getCache(CACHE_CODE);

        /*log.info(JsonUtils.serialize(cache.getKeys()));*/
        for (ComCodeCacheVO codeCacheVO : cacheCodeList) {
            if (cache.isKeyInCache(codeCacheVO.getCom_group_cd())) {
                /*
                ArrayList<ComCodeDtlVO> resultCodeArray = new ArrayList<>();
                boolean appendFlag = false;
               for(ComCodeDtlVO codeDtlVO : (ArrayList<ComCodeDtlVO>) cache.get(codeCacheVO.getCom_group_cd()).getObjectValue()){
                    if(!appendFlag && StringUtils.isEmpty(codeCacheVO.getRef_01())){
                        if(!codeDtlVO.getRef_01().equals(codeCacheVO.getRef_01())){
                            appendFlag = false;
                        }
                    }

                    if(appendFlag && StringUtils.isEmpty(codeCacheVO.getRef_02())){
                        if(!codeDtlVO.getRef_02().equals(codeCacheVO.getRef_02())){
                            appendFlag = false;
                        }
                    }
                }*/
                codeCacheVO.setCodeList((ArrayList<ComCodeDtlVO>) cache.get(codeCacheVO.getCom_group_cd()).getObjectValue());
            }
        }
        return cacheCodeList;
    }
}
