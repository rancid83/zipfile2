package emnet.chat.admin.service.admin.dept;

import emnet.chat.admin.common.utils.SessionUtils;
import emnet.chat.admin.domain.admin.dept.ReqDepartmentVO;
import emnet.chat.admin.domain.common.UserInfoVO;
import emnet.chat.admin.mapper.mst.admin.department.DepartmentMapper;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;

@Service
@Slf4j
public class DepartmentService {

    public static final String CACHE_CODE = "comCdCache";

    @Autowired
    private DepartmentMapper departmentMapper;


    /**
     * 조직리스트 리턴
     *
     * @param departmentVO
     * @return
     */
    public ArrayList<ReqDepartmentVO> getDepartmentList(ReqDepartmentVO departmentVO) {
        return (ArrayList<ReqDepartmentVO>) departmentMapper.selectDepartmentList(departmentVO);
    }


    public void processDepartment(ArrayList<ReqDepartmentVO> departmentList) {

        UserInfoVO userInfoVO = SessionUtils.getUserInfo();

        for (ReqDepartmentVO departmentVO : departmentList) {

            departmentVO.setData_chgr_id(userInfoVO.getEmp_no());
            departmentVO.setData_regr_id(userInfoVO.getEmp_no());

            if (departmentVO.getDel_flag().equals("1")) {
                departmentMapper.deleteDepartment(departmentVO);
            } else {
                switch (departmentVO.getDat_flag()) {
                    case "I":
                        departmentMapper.insertDepartment(departmentVO);
                        break;
                    case "U":
                        departmentMapper.updateDepartment(departmentVO);
                        break;
                }
            }
        }
    }

}
