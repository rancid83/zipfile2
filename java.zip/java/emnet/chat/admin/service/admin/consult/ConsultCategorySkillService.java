package emnet.chat.admin.service.admin.consult;

import emnet.chat.admin.common.utils.SessionUtils;
import emnet.chat.admin.domain.admin.consult.ReqConsultCategorySkillVO;
import emnet.chat.admin.domain.admin.consult.ReqConsultCategoryVO;
import emnet.chat.admin.domain.common.UserInfoVO;
import emnet.chat.admin.mapper.mst.admin.consult.ConsultCategoryMapper;
import emnet.chat.admin.mapper.mst.admin.consult.ConsultCategorySkillMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;

@Service
public class ConsultCategorySkillService {

    @Autowired
    ConsultCategorySkillMapper consultCategorySkillMapper;


    /**
     * 카테고리 그룹 리스트 리턴
     *
     * @param reqConsultCategorySkillVO
     * @return
     */
    public ArrayList<ReqConsultCategorySkillVO> getConsultCategorySkillList(ReqConsultCategorySkillVO reqConsultCategorySkillVO) {
        return (ArrayList<ReqConsultCategorySkillVO>) consultCategorySkillMapper.selectConsultCategorySkillList(reqConsultCategorySkillVO);
    }

    public void processConsultCategorySkill(ArrayList<ReqConsultCategorySkillVO> categorySkillList) {

        UserInfoVO userInfoVO = SessionUtils.getUserInfo();
        for (ReqConsultCategorySkillVO skillVO : categorySkillList) {

            skillVO.setData_chgr_id(userInfoVO.getEmp_no());
            skillVO.setData_regr_id(userInfoVO.getEmp_no());

            if (skillVO.getDel_flag().equals("1")) {
                consultCategorySkillMapper.deleteConsultCategorySkill(skillVO);
            } else {
                switch (skillVO.getDat_flag()) {
                    case "I":
                        consultCategorySkillMapper.insertConsultCategorySkill(skillVO);
                        break;
                    case "U":
                        consultCategorySkillMapper.updateConsultCategorySkill(skillVO);
                        break;
                }
            }
        }
    }
}
