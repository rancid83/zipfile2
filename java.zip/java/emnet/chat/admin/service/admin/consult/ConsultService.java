package emnet.chat.admin.service.admin.consult;

import emnet.chat.admin.common.utils.JsonUtils;
import emnet.chat.admin.domain.admin.consult.*;
import emnet.chat.admin.mapper.mst.admin.consult.ConsultMapper;
import emnet.chat.admin.mapper.mst.admin.consult.ConsultVipMapper;

import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import java.util.ArrayList;

@Service
@Slf4j
public class ConsultService {

    @Autowired
    ConsultMapper mapper;

    @Value("${websocket.ip}")
    private String nodeServerAddress;

    /**
     * 상담 카테고리 그룹  리스트 리턴
     *
     * @param reqConsultVO
     * @return
     */
    public ArrayList<ResConsultVO> getConsultList(ReqConsultVO reqConsultVO) {
        return (ArrayList<ResConsultVO>) mapper.selectConsultList(reqConsultVO);
    }

    /**
     * 상담 카테고리 그룹  리스트 리턴
     *
     * @param consultList
     * @return
     */
    public void processConsult(ArrayList<ReqConsultVO> consultList) {

        for (ReqConsultVO param : consultList) {

            if (param.getDel_flag().equals("1")) {
                mapper.deleteConsult(param);
            } else {
                switch (param.getDat_flag()) {
                    case "I":
                        mapper.insertConsult(param);
                        break;
                    case "U":
                        mapper.updateConsult(param);
                        break;
                }
            }
        }
    }


    /**
     * 상담사 변경 요청 내역 리스트 리턴
     *
     * @param reqConsultChangeVO
     * @return
     */
    public ArrayList<ReqConsultChangeVO> getChangeUserConsult(ReqConsultChangeVO reqConsultChangeVO) {
        return mapper.selectChangeUserConsult(reqConsultChangeVO);
    }


    public void processConsultReview(ReqConsultReviewAPIVO reqVO) {
        try {
            reqVO.setType("REVIEW");
            reqVO.setTarget_user_no(reqVO.getUser_no());
            RestTemplate restTemplate = new RestTemplate();
            HttpHeaders headers = new HttpHeaders();
            headers.setContentType(MediaType.APPLICATION_JSON_UTF8);

            log.debug("reqBody : {}", JsonUtils.serialize(reqVO));

            HttpEntity<Object> request = new HttpEntity<Object>(JsonUtils.serialize(reqVO).getBytes("UTF8"), headers);
            ResConsultChangeAPIVO rtnVO = restTemplate.exchange(nodeServerAddress + "/chats/req/review/v1", HttpMethod.POST, request, ResConsultChangeAPIVO.class).getBody();
            log.debug("Rtn  : {}", JsonUtils.serialize(rtnVO));
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void processConsultChange(ReqConsultChangeAPIVO reqVO) {
        try {
            RestTemplate restTemplate = new RestTemplate();
            HttpHeaders headers = new HttpHeaders();
            headers.setContentType(MediaType.APPLICATION_JSON_UTF8);
            log.debug("reqBody : {}", JsonUtils.serialize(reqVO));
            HttpEntity<Object> request = new HttpEntity<Object>(JsonUtils.serialize(reqVO).getBytes("UTF8"), headers);
            ResConsultChangeAPIVO rtnVO = restTemplate.exchange(nodeServerAddress + "/chats/req/change/v1", HttpMethod.POST, request, ResConsultChangeAPIVO.class).getBody();
            log.debug("Rtn  : {}", JsonUtils.serialize(rtnVO));
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

}
