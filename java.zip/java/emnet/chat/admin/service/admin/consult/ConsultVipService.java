package emnet.chat.admin.service.admin.consult;

import emnet.chat.admin.common.utils.SessionUtils;
import emnet.chat.admin.domain.admin.consult.ReqConsultVipVO;
import emnet.chat.admin.domain.common.UserInfoVO;
import emnet.chat.admin.mapper.mst.admin.consult.ConsultVipMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;

@Service
public class ConsultVipService {

    @Autowired
    ConsultVipMapper consultVipMapper;


    /**
     * 상담 카테고리 그룹  리스트 리턴
     *
     * @param reqConsultVipVO
     * @return
     */
    public ArrayList<ReqConsultVipVO> getConsultVipList(ReqConsultVipVO reqConsultVipVO) {
        return (ArrayList<ReqConsultVipVO>) consultVipMapper.selectConsultVipList(reqConsultVipVO);
    }
    /**
     * 상담 카테고리 그룹  리스트 리턴
     *
     * @param categoryList
     * @return
     */
    public void processCategoryVip(ArrayList<ReqConsultVipVO> categoryList) {


        UserInfoVO userInfoVO = SessionUtils.getUserInfo();

        for (ReqConsultVipVO vipVO : categoryList) {

            vipVO.setData_chgr_id(userInfoVO.getEmp_no());
            vipVO.setData_regr_id(userInfoVO.getEmp_no());

            if (vipVO.getDel_flag().equals("1")) {
                consultVipMapper.deleteVip(vipVO);
            } else {
                switch (vipVO.getDat_flag()) {
                    case "I":
                        consultVipMapper.insertVip(vipVO);
                        break;
                    case "U":
                        consultVipMapper.updateVip(vipVO);
                        break;
                }
            }
        }
    }

}
