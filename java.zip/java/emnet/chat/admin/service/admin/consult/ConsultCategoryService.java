package emnet.chat.admin.service.admin.consult;

import emnet.chat.admin.common.utils.SessionUtils;
import emnet.chat.admin.domain.admin.consult.ReqConsultCategoryVO;
import emnet.chat.admin.domain.common.UserInfoVO;
import emnet.chat.admin.mapper.mst.admin.consult.ConsultCategoryMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;

@Service
public class ConsultCategoryService {

    @Autowired
    ConsultCategoryMapper consultCategoryMapper;


    /**
     * 상담 카테고리 그룹  리스트 리턴
     *
     * @param reqConsultCategoryVO
     * @return
     */
    public ArrayList<ReqConsultCategoryVO> getCategoryList(ReqConsultCategoryVO reqConsultCategoryVO) {
        return (ArrayList<ReqConsultCategoryVO>) consultCategoryMapper.selectConsultCategoryList(reqConsultCategoryVO);
    }
    /**
     * 상담 카테고리 그룹  리스트 리턴
     *
     * @param categoryList
     * @return
     */
    public void processCategory(ArrayList<ReqConsultCategoryVO> categoryList) {

        UserInfoVO userInfoVO = SessionUtils.getUserInfo();

        for (ReqConsultCategoryVO categoryVO : categoryList) {

            categoryVO.setData_chgr_id(userInfoVO.getEmp_no());
            categoryVO.setData_regr_id(userInfoVO.getEmp_no());

            if (categoryVO.getDel_flag().equals("1")) {
                consultCategoryMapper.deleteConsultCategory(categoryVO);
            } else {
                switch (categoryVO.getDat_flag()) {
                    case "I":
                        consultCategoryMapper.insertConsultCategory(categoryVO);
                        break;
                    case "U":
                        consultCategoryMapper.updateConsultCategory(categoryVO);
                        break;
                }
            }
        }
    }
}
