package emnet.chat.admin.service.admin.consult;

import emnet.chat.admin.common.utils.SessionUtils;
import emnet.chat.admin.domain.admin.consult.ReqConsultConfAnswerVO;
import emnet.chat.admin.domain.admin.consult.ReqConsultConfQuestionVO;
import emnet.chat.admin.domain.admin.consult.ReqConsultVipVO;
import emnet.chat.admin.domain.common.UserInfoVO;
import emnet.chat.admin.mapper.mst.admin.consult.ConsultConfAnswerMapper;
import emnet.chat.admin.mapper.mst.admin.consult.ConsultConfQuestionMapper;
import emnet.chat.admin.mapper.mst.admin.consult.ConsultVipMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;

@Service
public class ConsultConfQuestionService {

    @Autowired
    ConsultConfQuestionMapper mapper;


    @Autowired
    ConsultConfAnswerMapper answerMapper;


    /**
     * 상담 만족도 질문 리스트 리턴
     *
     * @param questionVO
     * @return
     */
    public ArrayList<ReqConsultConfQuestionVO> getConfQuestionList(ReqConsultConfQuestionVO questionVO) {
        return (ArrayList<ReqConsultConfQuestionVO>) mapper.selectConsultConfQuestionList(questionVO);
    }

    /**
     * 상담 만족도 질문 DB 처리
     *
     * @param questionList
     * @return
     */
    public void processConfQuestion(ArrayList<ReqConsultConfQuestionVO> questionList) {
        UserInfoVO userInfoVO = SessionUtils.getUserInfo();
        for (ReqConsultConfQuestionVO param : questionList) {

            param.setData_chgr_id(userInfoVO.getEmp_no());
            param.setData_regr_id(userInfoVO.getEmp_no());

            if (param.getDel_flag().equals("1")) {
                mapper.deleteConsultConfQuestion(param);
            } else {
                switch (param.getDat_flag()) {
                    case "I":
                        mapper.insertConsultConfQuestion(param);
                        break;
                    case "U":
                        mapper.updateConsultConfQuestion(param);
                        break;
                }
            }
        }
    }


    /**
     * 상담 만족도 답변 리스트 리턴
     *
     * @param answerVO
     * @return
     */
    public ArrayList<ReqConsultConfAnswerVO> getConsultConfAnswerList(ReqConsultConfAnswerVO answerVO) {
        return (ArrayList<ReqConsultConfAnswerVO>) answerMapper.selectConsultConfAnswerList(answerVO);
    }

    /**
     * 상담 만족도 답변 DB 처리
     *
     * @param answerList
     * @return
     */
    public void processConsultConfAnswer(ArrayList<ReqConsultConfAnswerVO> answerList) {
        UserInfoVO userInfoVO = SessionUtils.getUserInfo();

        for (ReqConsultConfAnswerVO param : answerList) {

            param.setData_chgr_id(userInfoVO.getEmp_no());
            param.setData_regr_id(userInfoVO.getEmp_no());

            if (param.getDel_flag().equals("1")) {
                answerMapper.deleteConsultConfAnswer(param);
            } else {
                switch (param.getDat_flag()) {
                    case "I":
                        answerMapper.insertConsultConfAnswer(param);
                        break;
                    case "U":
                        answerMapper.updateConsultConfAnswer(param);
                        break;
                }
            }
        }
    }

}
