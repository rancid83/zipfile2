package emnet.chat.admin.service.admin.slang;

import emnet.chat.admin.common.utils.SessionUtils;
import emnet.chat.admin.domain.admin.slang.ReqSlangVO;
import emnet.chat.admin.domain.common.UserInfoVO;
import emnet.chat.admin.mapper.mst.admin.slang.SlangMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;

@Service
public class SlangService {

    @Autowired
    SlangMapper mapper;

    /**
     * 상담 카테고리 그룹  리스트 리턴
     *
     * @param reqConsultVipVO
     * @return
     */
    public ArrayList<ReqSlangVO> getSlangList(ReqSlangVO reqConsultVipVO) {
        return (ArrayList<ReqSlangVO>) mapper.selectSlangList(reqConsultVipVO);
    }
    /**
     * 상담 카테고리 그룹  리스트 리턴
     *
     * @param SlangList
     * @return
     */
    public void processSlang(ArrayList<ReqSlangVO> SlangList) {

        UserInfoVO userInfoVO = SessionUtils.getUserInfo();

        for (ReqSlangVO param : SlangList) {

            param.setData_chgr_id(userInfoVO.getEmp_no());
            param.setData_regr_id(userInfoVO.getEmp_no());

            if (param.getDel_flag().equals("1")) {
                mapper.deleteSlang(param);
            } else {
                switch (param.getDat_flag()) {
                    case "I":
                        mapper.insertSlang(param);
                        break;
                    case "U":
                        mapper.updateSlang(param);
                        break;
                }
            }
        }
    }

}
