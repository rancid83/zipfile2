package emnet.chat.admin.service.admin.keyword;

import emnet.chat.admin.common.utils.SessionUtils;
import emnet.chat.admin.domain.admin.keyword.ReqKeywordCategoryVO;
import emnet.chat.admin.domain.admin.keyword.ReqKeywordTagVO;
import emnet.chat.admin.domain.admin.keyword.ReqKeywordVO;
import emnet.chat.admin.domain.admin.keyword.ResKeywordVO;
import emnet.chat.admin.domain.common.UserInfoVO;
import emnet.chat.admin.mapper.mst.admin.keyword.KeywordCategoryMapper;
import emnet.chat.admin.mapper.mst.admin.keyword.KeywordMapper;
import emnet.chat.admin.mapper.mst.admin.keyword.KeywordTagMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.StringTokenizer;

@Service
public class KeywordService {


    @Autowired
    KeywordMapper keywordMapper;

    @Autowired
    KeywordTagMapper keywordTagMapper;

    @Autowired
    KeywordCategoryMapper keywordCategoryMapper;


    /**
     * 상담 키워드  조회
     *
     * @param keywordVO
     * @return
     */
    public ArrayList<ResKeywordVO> getKeywordList(ReqKeywordVO keywordVO) {
        return (ArrayList<ResKeywordVO>) keywordMapper.selectKeywordList(keywordVO);
    }

    /**
     * 상담 키워드  DB 처리
     *
     * @param keywordList
     * @return
     */
    public void processKeyword(ArrayList<ReqKeywordVO> keywordList) {

        for (ReqKeywordVO param : keywordList) {

            if (param.getDel_flag().equals("1")) {

                keywordMapper.deleteKeyword(param);

                //키워드 삭제시 첨부된 태그도 삭제처리

                    ReqKeywordTagVO tagVO = new ReqKeywordTagVO();
                    tagVO.setService_no(param.getService_no());
                    tagVO.setKeyword_no(param.getKeyword_no());
                    keywordTagMapper.deleteAll(tagVO);


            } else {

                //키워드 태그 변경 여부 체크
                // insert || update시 태그도 변경 처리
                boolean tagFlag = false;

                switch (param.getDat_flag()) {

                    case "I":
                        keywordMapper.insertKeyword(param);
                        tagFlag = true;
                        break;
                    case "U":
                        keywordMapper.updateKeyword(param);
                        tagFlag = true;
                        break;
                }

                if (tagFlag) {


                    UserInfoVO userInfoVO = SessionUtils.getUserInfo();

                    //키워드 변경시 태그 전체 삭제이후 재처리
                    ReqKeywordTagVO paramTagVO = new ReqKeywordTagVO();
                    paramTagVO.setService_no(param.getService_no());
                    paramTagVO.setKeyword_no(param.getKeyword_no());
                    keywordTagMapper.deleteAll(paramTagVO);

                    StringTokenizer tokenizer = new StringTokenizer(param.getKeyword_tag_list(), ",");
                    while (tokenizer.hasMoreTokens()) {
                        ReqKeywordTagVO tagVO = new ReqKeywordTagVO();


                        tagVO.setService_no(param.getService_no());
                        tagVO.setKeyword_no(param.getKeyword_no());
                        tagVO.setContent(tokenizer.nextToken().trim());
                        tagVO.setData_chgr_id(userInfoVO.getEmp_no());
                        tagVO.setData_regr_id(userInfoVO.getEmp_no());

                        keywordTagMapper.insertKeywordTag(tagVO);
                    }
                }
            }
        }
    }


    /**
     * 상담 키워드 해시태크 조회
     *
     * @param keywordTagVO
     * @return
     */
    public ArrayList<ReqKeywordTagVO> getKeywordTagList(ReqKeywordTagVO keywordTagVO) {
        return (ArrayList<ReqKeywordTagVO>) keywordTagMapper.selectKeywordTagList(keywordTagVO);
    }


    /**
     * 상담 키워드 해시태크 DB 처리
     *
     * @param keywordTagList
     * @return
     */
    public void processKeywordTag(ArrayList<ReqKeywordTagVO> keywordTagList) {

        UserInfoVO userInfoVO = SessionUtils.getUserInfo();

        for (ReqKeywordTagVO param : keywordTagList) {

            param.setData_chgr_id(userInfoVO.getEmp_no());
            param.setData_regr_id(userInfoVO.getEmp_no());

            if (param.getDel_flag().equals("1")) {
                keywordTagMapper.deleteKeywordTag(param);
            } else {
                switch (param.getDat_flag()) {
                    case "I":
                        keywordTagMapper.insertKeywordTag(param);
                        break;
                    case "U":
                        keywordTagMapper.updateKeywordTag(param);
                        break;
                }
            }
        }
    }


    /**
     * 상담 키워드  카테고리 조회
     *
     * @param keywordCategoryVO
     * @return
     */
    public ArrayList<ReqKeywordCategoryVO> getKeywordCategoryList(ReqKeywordCategoryVO keywordCategoryVO) {
        return (ArrayList<ReqKeywordCategoryVO>) keywordCategoryMapper.selectKeywordCategoryList(keywordCategoryVO);
    }

    /**
     * 상담 키워드 카테고리 DB 처리
     *
     * @param questionList
     * @return
     */
    public void processKeywordCategory(ArrayList<ReqKeywordCategoryVO> questionList) {

        for (ReqKeywordCategoryVO param : questionList) {

            if (param.getDel_flag().equals("1")) {
                keywordCategoryMapper.deleteKeywordCategory(param);
            } else {
                switch (param.getDat_flag()) {
                    case "I":
                        keywordCategoryMapper.insertKeywordCategory(param);
                        break;
                    case "U":
                        keywordCategoryMapper.updateKeywordCategory(param);
                        break;
                }
            }
        }
    }


}
