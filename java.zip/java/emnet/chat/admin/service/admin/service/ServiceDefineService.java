package emnet.chat.admin.service.admin.service;

import emnet.chat.admin.common.utils.SessionUtils;
import emnet.chat.admin.domain.admin.service.ReqServiceVO;
import emnet.chat.admin.domain.admin.service.ResServiceScheduleVO;
import emnet.chat.admin.domain.common.UserInfoVO;
import emnet.chat.admin.mapper.mst.admin.service.ServiceMapper;
import emnet.chat.admin.mapper.mst.admin.service.ServiceScheduleMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;

@Service
public class ServiceDefineService {

    @Autowired
    ServiceMapper mapper;


    /**
     * 시스템 서비스 리스트 리턴
     *
     * @param serviceVO
     * @return
     */
    public ArrayList<ReqServiceVO> getServiceList(ReqServiceVO serviceVO) {
        return (ArrayList<ReqServiceVO>) mapper.selectServiceList(serviceVO);
    }


    /**
     * 시스템 스케줄 DB 처리
     *
     * @param serviceList
     * @return
     */
    public void processSchedule(ArrayList<ReqServiceVO> serviceList) {

        UserInfoVO userInfoVO = SessionUtils.getUserInfo();

        for (ReqServiceVO scheduleVO : serviceList) {

            scheduleVO.setData_chgr_id(userInfoVO.getEmp_no());
            scheduleVO.setData_regr_id(userInfoVO.getEmp_no());

            if (scheduleVO.getDel_flag().equals("1")) {
                mapper.deleteService(scheduleVO);
            } else {
                switch (scheduleVO.getDat_flag()) {
                    case "I":
                        mapper.insertService(scheduleVO);
                        break;
                    case "U":
                        mapper.updateService(scheduleVO);
                        break;
                }
            }
        }
    }

    public void processServiceDefine(ReqServiceVO reqServiceVO) {

        UserInfoVO userInfoVO = SessionUtils.getUserInfo();

        reqServiceVO.setData_chgr_id(userInfoVO.getEmp_no());
        reqServiceVO.setData_regr_id(userInfoVO.getEmp_no());

        if (reqServiceVO.getDel_flag().equals("1")) {
            mapper.deleteService(reqServiceVO);
        } else {
            switch (reqServiceVO.getDat_flag()) {
                case "I":
                    mapper.insertService(reqServiceVO);
                    break;
                case "U":
                    mapper.updateService(reqServiceVO);
                    break;
            }
        }
    }
}
