package emnet.chat.admin.service.admin.service;

import emnet.chat.admin.common.utils.SessionUtils;
import emnet.chat.admin.domain.admin.consult.ReqConsultVipVO;
import emnet.chat.admin.domain.admin.service.ResServiceScheduleVO;
import emnet.chat.admin.domain.common.UserInfoVO;
import emnet.chat.admin.mapper.mst.admin.consult.ConsultVipMapper;
import emnet.chat.admin.mapper.mst.admin.service.ServiceScheduleMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;

@Service
public class ServiceScheduleService {

    @Autowired
    ServiceScheduleMapper mapper;


    /**
     * 시스템 스케줄   리스트 리턴
     *
     * @param serviceScheduleVO
     * @return
     */
    public ArrayList<ResServiceScheduleVO> getServiceScheduleList(ResServiceScheduleVO serviceScheduleVO) {
        return (ArrayList<ResServiceScheduleVO>) mapper.selectServiceScheduleList(serviceScheduleVO);
    }

    public void processBatchSchedule(ArrayList<ResServiceScheduleVO> serviceList) {
        for (ResServiceScheduleVO scheduleVO:serviceList){
            scheduleVO.setDat_flag("U");
            scheduleVO.setDel_flag("0");
            //시간포맷 변경
            scheduleVO.setStart_time(scheduleVO.getStart_time().replaceAll(":",""));
            scheduleVO.setEnd_time(scheduleVO.getEnd_time().replaceAll(":",""));
            scheduleVO.setLunch_start_time(scheduleVO.getLunch_start_time().replaceAll(":",""));
            scheduleVO.setLunch_end_time(scheduleVO.getLunch_end_time().replaceAll(":",""));
            scheduleVO.setRest_start_time(scheduleVO.getRest_start_time().replaceAll(":",""));
            scheduleVO.setRest_end_time(scheduleVO.getRest_end_time().replaceAll(":",""));
        }
        processSchedule(serviceList);
    }

    /**
     * 시스템 스케줄 DB 처리
     *
     * @param serviceList
     * @return
     */
    public void processSchedule(ArrayList<ResServiceScheduleVO> serviceList) {

        UserInfoVO userInfoVO = SessionUtils.getUserInfo();


        for (ResServiceScheduleVO scheduleVO : serviceList) {

            scheduleVO.setData_chgr_id(userInfoVO.getEmp_no());
            scheduleVO.setData_regr_id(userInfoVO.getEmp_no());

            if (scheduleVO.getDel_flag().equals("1")) {
                mapper.deleteServiceSchedule(scheduleVO);
            } else {
                switch (scheduleVO.getDat_flag()) {
                    case "I":
                        mapper.insertServiceSchedule(scheduleVO);
                        break;
                    case "U":
                        mapper.updateServiceSchedule(scheduleVO);
                        break;
                }
            }
        }
    }

}
