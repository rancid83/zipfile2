package emnet.chat.admin.service.admin.system;

import java.util.List;

import emnet.chat.admin.common.utils.SessionUtils;
import emnet.chat.admin.domain.common.UserInfoVO;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import emnet.chat.admin.domain.admin.system.RspMenuVO;
import emnet.chat.admin.mapper.mst.admin.system.MenuMapper;

@Service
@Slf4j
public class MenuService {
	
	@Autowired
	private MenuMapper menuMapper;

	
	/**
	 * parent_menu_no로 해당 자식 메뉴 리스트 가져옴
	 * @param parentMenuNo
	 * @return
	 */
	public List<RspMenuVO> getChildMenuList(int parentMenuNo) {
		log.debug("'asdasd");
		return menuMapper.selectChildMenuList(parentMenuNo);
	}
	
	
	/**
	 * 메뉴 디비에 인서트
	 * @param param
	 */
	public void addMenu(RspMenuVO param) {

		menuMapper.insertMenu(param);
	}

}
