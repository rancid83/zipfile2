package emnet.chat.admin.service.admin.system;

import com.sun.org.apache.xml.internal.utils.StringComparable;
import emnet.chat.admin.common.utils.SessionUtils;
import emnet.chat.admin.domain.admin.menu.ReqMenuLevelVO;
import emnet.chat.admin.domain.admin.menu.ReqMenuPermissionMappingVO;
import emnet.chat.admin.domain.admin.menu.ReqPermissionMenuVO;
import emnet.chat.admin.domain.admin.menu.ResPermissionMenuVO;
import emnet.chat.admin.domain.admin.system.ReqPermissionVO;
import emnet.chat.admin.domain.common.UserInfoVO;
import emnet.chat.admin.mapper.mst.admin.system.MenuMapper;
import emnet.chat.admin.mapper.mst.admin.system.PermissionMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.stream.Collectors;

@Service
public class PermissionService {

    @Autowired
    private PermissionMapper mapper;

    @Autowired
    private MenuMapper menuMapper;


    /**
     * 시스템에 등록된 메뉴리스트 리턴 ( 메뉴 전체 목록 )
     *
     * @param param
     * @return
     */
    public ArrayList<ReqMenuLevelVO> getMenuList(ReqMenuLevelVO param) {
        return menuMapper.selectMenuList(param);
    }

    /**
     * 권한 목록 리턴
     *
     * @param reqPermissionVO
     * @return
     */
    public ArrayList<ReqPermissionVO> getPermissionList(ReqPermissionVO reqPermissionVO) {

        return (ArrayList<ReqPermissionVO>) mapper.selectPermissionList(reqPermissionVO);
    }


    /**
     * 권한 처리
     *
     * @param permissionList
     * @return
     */
    public void processPermission(ArrayList<ReqPermissionVO> permissionList) {

        UserInfoVO userInfoVO = SessionUtils.getUserInfo();

        for (ReqPermissionVO param : permissionList) {

            param.setData_chgr_id(userInfoVO.getEmp_no());
            param.setData_regr_id(userInfoVO.getEmp_no());

            if (param.getDel_flag().equals("1")) {
                mapper.deletePermission(param);
            } else {
                switch (param.getDat_flag()) {
                    case "I":
                        mapper.insertPermission(param);
                        break;
                    case "U":
                        mapper.updatePermission(param);
                        break;
                }
            }
        }
    }

    /**
     * 권한에 부여된 메뉴 리스트 리턴
     *
     * @param reqPermissionVO
     * @return
     */
    public ArrayList<ResPermissionMenuVO> getPermissionMappingMenuList(ReqPermissionMenuVO reqPermissionVO) {

        return (ArrayList<ResPermissionMenuVO>) menuMapper.selectPermissionMappingMenuList(reqPermissionVO);
    }

    /**
     * 권한 별 메뉴 등록 처리
     *
     * @param permissionList
     * @return
     */
    public void processPermissionMapping(ArrayList<ReqMenuPermissionMappingVO> permissionList) {


        if (!permissionList.isEmpty()) {

            UserInfoVO userInfo = SessionUtils.getUserInfo();

            menuMapper.deleteAllPermissionMenu(permissionList.get(0));

            HashMap<String, ReqMenuPermissionMappingVO> parentMenuMap = new HashMap<>();
            for (ReqMenuPermissionMappingVO param : permissionList) {

                ReqPermissionMenuVO paramMenuVO = new ReqPermissionMenuVO();
                paramMenuVO.setService_no(param.getService_no());
                paramMenuVO.setMenu_no(param.getMenu_no());
                ArrayList<ReqPermissionMenuVO> rtnList = menuMapper.selectMenuByNo(paramMenuVO);

                if (!rtnList.isEmpty()) {

                    ReqPermissionMenuVO targetMenuVO = rtnList.get(0);
                    if (targetMenuVO.getMenu_level().equals("2") && !parentMenuMap.containsKey(targetMenuVO.getParent_menu_no())) {

                        ReqMenuPermissionMappingVO reqMenuPermissionMappingVO = new ReqMenuPermissionMappingVO();
                        reqMenuPermissionMappingVO.setService_no(targetMenuVO.getService_no());
                        reqMenuPermissionMappingVO.setMenu_no(targetMenuVO.getParent_menu_no());
                        reqMenuPermissionMappingVO.setPermission_no(permissionList.get(0).getPermission_no());
                        reqMenuPermissionMappingVO.setDat_flag("I");
                        parentMenuMap.put(targetMenuVO.getParent_menu_no(), reqMenuPermissionMappingVO);
                    }

                }

            }

            // MAP TO LIST (Stream) AND ADD permission List
            permissionList.addAll(parentMenuMap.values().stream().collect(Collectors.toList()));

            permissionList.stream().sorted( Comparator.comparing(ReqMenuPermissionMappingVO::getMenu_no)).toArray();

            for (ReqMenuPermissionMappingVO param : permissionList) {

                param.setData_chgr_id(userInfo.getUser_id());
                param.setData_regr_id(userInfo.getUser_id());

                if (param.getDel_flag().equals("1")) {

                    menuMapper.deletePermissionMapping(param);
                } else {
                    switch (param.getDat_flag()) {
                        case "I":

                            menuMapper.insertPermissionMapping(param);
                            break;
                    }
                }
            }
        }


    }


}
