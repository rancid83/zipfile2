package emnet.chat.admin.service;

import emnet.chat.admin.mapper.mst.admin.statistics.StatUserWorkLogMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class HomeService {

    @Autowired
    StatUserWorkLogMapper workLogMapper;



}
