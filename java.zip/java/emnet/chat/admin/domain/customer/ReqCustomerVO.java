package emnet.chat.admin.domain.customer;

public class ReqCustomerVO {

}
