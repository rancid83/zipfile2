package emnet.chat.admin.domain.admin.keyword;

import emnet.chat.admin.domain.common.CommonReqVO;
import lombok.Data;

import java.util.ArrayList;

@Data
public class ResKeywordCategoryVO extends CommonReqVO {
    private String service_no;
    private String keyword_category_no;
    private String name;
    private ArrayList<ReqKeywordTagVO> tagList = new ArrayList<>();

}
