package emnet.chat.admin.domain.admin.keyword;

import emnet.chat.admin.domain.common.CommonReqVO;
import lombok.Data;

@Data
public class ReqKeywordCategoryVO extends CommonReqVO {
    private String service_no;
    private String keyword_category_no;
    private String name;
}
