package emnet.chat.admin.domain.admin.keyword;

import emnet.chat.admin.domain.common.CommonReqVO;
import lombok.Data;

@Data
public class ReqKeywordTagVO extends CommonReqVO {
    private String keyword_tag_no;
    private String keyword_no;
    private String service_no;
    private String content;
}
