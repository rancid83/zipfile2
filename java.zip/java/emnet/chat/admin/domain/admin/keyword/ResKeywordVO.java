package emnet.chat.admin.domain.admin.keyword;

import emnet.chat.admin.domain.common.CommonReqVO;
import lombok.Data;

@Data
public class ResKeywordVO extends CommonReqVO {
    private String keyword_no;
    private String service_no;
    private String keyword_category_no;
    private String category_name;
    private String keyword_tag_list;
    private String user_no;
    private String user_name;
    private String keyword_type;
    private String question;
    private String answer;
    private String use_count= "0";
    private String list_order= "0";
    private String confirm= "0";
    private String show_top= "N";
    private String btn_name;
    private String btn_url;
    private String reg_date;
}
