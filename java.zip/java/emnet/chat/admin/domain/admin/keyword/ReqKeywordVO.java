package emnet.chat.admin.domain.admin.keyword;

import emnet.chat.admin.domain.common.CommonReqVO;
import lombok.Data;

@Data
public class ReqKeywordVO extends CommonReqVO {
    private String insertRowId;
    private String keyword_no;
    private String service_no;
    private String keyword_category_no;
    private String keyword_tag_list;
    private String keyword_tag_name;
    private String user_no;
    private String keyword_type;
    private String question="";
    private String answer="";
    private String list_order= "0";
    private String btn_name;
    private String btn_url;
}
