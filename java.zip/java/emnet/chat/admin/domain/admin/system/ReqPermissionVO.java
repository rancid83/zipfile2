package emnet.chat.admin.domain.admin.system;

import emnet.chat.admin.domain.common.CommonReqVO;
import lombok.Data;

@Data
public class ReqPermissionVO extends CommonReqVO {
    private String permission_no;
    private String service_no;
    private String permission_name;
}
