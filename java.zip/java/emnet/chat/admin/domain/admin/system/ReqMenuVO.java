package emnet.chat.admin.domain.admin.system;

public class ReqMenuVO {

}
