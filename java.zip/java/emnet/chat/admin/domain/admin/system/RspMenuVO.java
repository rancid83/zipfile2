package emnet.chat.admin.domain.admin.system;

import emnet.chat.admin.domain.common.CommonRspVO;
import lombok.Data;

@Data
public class RspMenuVO extends CommonRspVO {
	private int service_no;
	private int menu_no;	
	private int parent_menu_no;
	private int user_no;
	private String menu_url;
	private String menu_name;
	private String use_cd;
	

}
