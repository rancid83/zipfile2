package emnet.chat.admin.domain.admin.statistics;

import emnet.chat.admin.domain.common.CommonResVO;
import lombok.Data;

@Data
public class ResStatNotAccessVO extends CommonResVO {
    private String consult_date;
    private String consult_hour;
    private int chat_req_cnt;
    private int end_cnt;
    private int not_distribute_customer_cnt;
    private int not_distribute_delay_cnt;

}
