package emnet.chat.admin.domain.admin.statistics;

import emnet.chat.admin.domain.common.CommonResVO;
import lombok.Data;

@Data
public class ResStatAnswerVO extends CommonResVO {
    private String consult_no;
    private String consult_date_str;
    private String user_no;
    private String chat_start_time;
    private String end_time;
    private String chat_time_diff;
    private String customer_name;
    private String customer_id;
    private String user_name;
    private String emp_no;
    private String answer_yn;
    private String precision_result;
    private String immediacy_result;
    private String positivity_result;
    private String overall_result;
    private String extra_message_01;
    private String extra_message_02;
    private String extra_message_03;
    private String extra_message_04;
    private String extra_message_05;
}
