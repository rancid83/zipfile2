package emnet.chat.admin.domain.admin.statistics;

import emnet.chat.admin.domain.common.CommonResVO;
import lombok.Data;

@Data
public class ResStatProductTermVO extends CommonResVO {
    private String data_reg_dtm;
    private String team_name;
    private String emp_no;
    private String user_name;
    private String exec_rate;
    private int work_time_point;
    private int time_per_cht_count;
    private int consult_count;
    private String consult_time;
}
