package emnet.chat.admin.domain.admin.statistics;

import emnet.chat.admin.domain.common.CommonReqVO;
import emnet.chat.admin.domain.common.CommonResVO;
import lombok.Data;

@Data
public class ResStatDailyVO extends CommonResVO {
    private String consult_date;
    private String level3_name;
    private int chat_req_cnt;
    private int end_cnt;
    private int waiting_cnt;
    private int busy_cnt;
    private String avg_wait_diff;
    private String avg_consult_diff;
}
