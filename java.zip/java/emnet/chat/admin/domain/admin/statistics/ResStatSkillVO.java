package emnet.chat.admin.domain.admin.statistics;

import emnet.chat.admin.domain.common.CommonResVO;
import lombok.Data;

@Data
public class ResStatSkillVO extends CommonResVO {
    private String consult_date;
    private String consult_hour;
    private String skill_name;
    private int req_all;
    private int chat_req_cnt;
    private int end_cnt;
    private String success_rate;
    private int waiting_cnt;
    private int busy_cnt;
    private String avg_wait_diff;
    private String avg_consult_diff;
}
