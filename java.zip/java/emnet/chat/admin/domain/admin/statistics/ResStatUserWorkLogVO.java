package emnet.chat.admin.domain.admin.statistics;

import emnet.chat.admin.domain.common.CommonReqVO;
import lombok.Data;

@Data
public class ResStatUserWorkLogVO extends CommonReqVO {
    private String emp_no;
    private String user_name;
    private String connect_ip;
    private String log_type_nm;
    private String event_date;
}
