package emnet.chat.admin.domain.admin.statistics;

import emnet.chat.admin.domain.common.CommonResVO;
import lombok.Data;

@Data
public class ResStatProductTeamVO extends CommonResVO {
    private String data_reg_dtm;
    private String team_name;
    private String consult_count;
    private String consult_time;
    private String avg_consult_time;
    private String etc_time;
}
