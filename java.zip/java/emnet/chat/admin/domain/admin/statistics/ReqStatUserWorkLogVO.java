package emnet.chat.admin.domain.admin.statistics;

import emnet.chat.admin.domain.common.CommonReqVO;
import lombok.Data;

@Data
public class ReqStatUserWorkLogVO extends CommonReqVO {

    private String service_no;
    private String user_no;
    private String logging_no;
    private String log_type;
    private String ip;
    private String content;
    private String event_date;
    private String sch_start_time;
    private String sch_end_time;




}
