package emnet.chat.admin.domain.admin.statistics;

import emnet.chat.admin.domain.common.CommonReqVO;
import lombok.Data;

/**
 * 근무일수 평가 통계
 */
@Data
public class ReqStatWorkUserVO extends CommonReqVO {

    private String schedule_date;
    private String schedule_date_nm;
    private String week_nm;
    private String holiday;
    private String department_no;
    private String service_no;
    private String level1_name;
    private String level2_name;
    private String level3_name;
    private String user_no;
    private String emp_no;
    private String name;
    private String work_min;
    private String lunch_min;
    private String rest_min;
    private String work_val;
    private String work_real_min;
    //근무일수 = 근무시간/(업무시간-중식시간)
    private String work_day_cnt;
    private String rest_full_cnt;
    private String rest_half_cnt;
    private String rest_etc_cnt;
    private String week_cd;
    private String in_min_diff;
    private String out_min_diff;
    private String etc_min_diff;
    private String in_edu_min;
    private String in_rep_min;
    private String in_hospital_min;
    private String in_talk_min;
    private String in_err_min;
    private String in_short_min;
    private String in_mile_min;
    private String in_etc_min;
    private String holiday_min;

}
