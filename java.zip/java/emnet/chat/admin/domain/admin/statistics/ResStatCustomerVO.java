package emnet.chat.admin.domain.admin.statistics;

import emnet.chat.admin.domain.common.CommonReqVO;
import lombok.Data;

@Data
public class ResStatCustomerVO extends CommonReqVO {
    private String service_no;
    private String consult_date;

    private String chat_start_time_str;
    private String chat_end_time_str;
    private String level3_name;
    private String user_name;
    private String emp_no;
    private String customer_id;
    private String income_nm;
    private String auth_nm;
    private String category_name;
    private String consult_memo;
    private String chat_time_diff;
}
