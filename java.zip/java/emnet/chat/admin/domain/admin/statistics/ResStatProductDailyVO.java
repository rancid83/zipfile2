package emnet.chat.admin.domain.admin.statistics;

import emnet.chat.admin.domain.common.CommonResVO;
import lombok.Data;

@Data
public class ResStatProductDailyVO extends CommonResVO {
    private String data_reg_dtm;
    private String team_name;
    private String user_no;
    private String user_name;
    private String emp_no;
    private String total_chat_cnt;
    private String work_time;
    private String ct_count_wt;
    private String consult_time;
    private String avg_consult_time;
    private String exec_rate;
    private String away_time;
    private String lunch_time;
    private String rest_time;
    private String etc_time;
}
