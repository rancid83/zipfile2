package emnet.chat.admin.domain.admin.statistics;

import emnet.chat.admin.domain.common.CommonReqVO;
import lombok.Data;

@Data
public class ReqStatDailyVO extends CommonReqVO {
    private String service_no;
    private String department_no;
    private String consult_category_no;
    private String user_no;
}
