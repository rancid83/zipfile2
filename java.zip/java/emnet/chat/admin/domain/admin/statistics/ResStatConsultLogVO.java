package emnet.chat.admin.domain.admin.statistics;

import emnet.chat.admin.domain.common.CommonReqVO;
import lombok.Data;

@Data
public class ResStatConsultLogVO extends CommonReqVO {
    private String service_no;
    private String user_name;
    private String emp_no;
    private String read_dtm;
    private String consult_date_str;
    private String chat_term;
    private String customer_id;
    private String customer_name;
}
