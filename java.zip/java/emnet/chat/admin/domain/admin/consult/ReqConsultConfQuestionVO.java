package emnet.chat.admin.domain.admin.consult;

import emnet.chat.admin.domain.common.CommonReqVO;
import lombok.Data;

/**
 * 만족도 조사 질문
 */
@Data
public class ReqConsultConfQuestionVO extends CommonReqVO {
    private String question_no;
    private String service_no;
    private String question_body;
    private String question_type;
    private String sort_num;
    private String use_yn;
    private String answer_cnt;

}
