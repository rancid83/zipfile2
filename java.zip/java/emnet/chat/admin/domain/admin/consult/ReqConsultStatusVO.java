package emnet.chat.admin.domain.admin.consult;

import emnet.chat.admin.domain.common.CommonReqVO;
import lombok.Data;

/**
 * VIP 고객관리
 */
@Data
public class ReqConsultStatusVO extends CommonReqVO {

    private String service_no;
    private int waiting_cnt = 0;
    private int busy_cnt = 0;
    private int end_cnt = 0;

}
