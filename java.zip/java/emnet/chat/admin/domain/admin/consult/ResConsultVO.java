package emnet.chat.admin.domain.admin.consult;

import emnet.chat.admin.domain.common.CommonReqVO;
import lombok.Data;

/**
 * VIP 고객관리
 */
@Data
public class ResConsultVO extends CommonReqVO {

    private String service_no;
    private String consult_no;
    private String consult_date;
    private String customer_no;
    private String customer_name;
    private String customer_id;
    private String skill_no;
    private String consult_category_no;
    //상담상태 READY:대기,  REVIEW:검토요청,  CHANGE:변경요청
    private String consult_status;
    private String consult_status_nm;
    private String req_type;
    private String req_type_nm;
    private String user_no;
    private String consultant_name;
    //상담사 조직번호
    private String department_no;
    //대기시간
    private String start_time;
    // 상담시작시간
    private String chat_start_time;
    // 배정시간
    private String distribute_time;
    // 상담종료시간
    private String end_time;
    // 대기시간
    private String wait_time_diff;
    private String end_type;
    //상담 인입경로
    private String income_type;
    private String consult_income_type_nm;
    // 고객 인증 수단
    private String auth_cd;
    private String consult_auth_cd_nm;
    // 만족도 조사여부
    private String result_yn;
    //문의 내용
    private String consult_memo;

}
