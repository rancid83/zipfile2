package emnet.chat.admin.domain.admin.consult;

import emnet.chat.admin.domain.common.CommonReqVO;
import lombok.Data;

/**
 * VIP 고객관리
 */
@Data
public class ReqConsultReviewAPIVO {
    private String service_no;
    private String room_no;
    private String user_no;
    private String type = "REVIEW";
    private String target_user_no;
    private String comment;
}
