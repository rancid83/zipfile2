package emnet.chat.admin.domain.admin.consult;

import emnet.chat.admin.domain.common.CommonReqVO;
import lombok.Data;

/**
 * 만족도 조사 질문
 */
@Data
public class ReqConsultConfAnswerVO extends CommonReqVO {
    private String service_no;
    private String question_no;
    private String answer_no;
    private String answer_body;
    private String answer_score;
    private String sort_num;
    private String use_yn;
}
