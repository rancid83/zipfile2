package emnet.chat.admin.domain.admin.consult;

import emnet.chat.admin.domain.common.CommonReqVO;
import lombok.Data;
@Data
public class ReqConsultCategorySkillVO extends CommonReqVO {
	private String service_no;
	private String consult_category_no;
	private String skill_no;
	private String skill_name;
	private String use_yn;
	private String order_no="0";
}
