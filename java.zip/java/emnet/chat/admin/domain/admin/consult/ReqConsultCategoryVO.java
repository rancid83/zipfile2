package emnet.chat.admin.domain.admin.consult;

import emnet.chat.admin.domain.common.CommonReqVO;
import lombok.Data;

@Data
public class ReqConsultCategoryVO extends CommonReqVO {

    private String service_no;
    private String consult_category_no;
    private String title = "";
    private String content = "";
    private String use_yn;
    private String use_yn_nm;
    private String content_yn;
    private String content_yn_nm;
    private String order_no = "0";

}

