package emnet.chat.admin.domain.admin.consult;

import emnet.chat.admin.domain.common.CommonReqVO;
import lombok.Data;

/**
 * VIP 고객관리
 */
@Data
public class ReqConsultChangeVO extends CommonReqVO {

    private String service_no;
    private String consult_no;
    private String consult_category_no;
    private String level1_name;
    private String level2_name;
    private String level3_name;
    private String req_type;
    private String req_reason;
    private String req_user_no;
    private String change_user_name;

}
