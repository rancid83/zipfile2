package emnet.chat.admin.domain.admin.consult;

import emnet.chat.admin.domain.common.CommonReqVO;
import lombok.Data;

/**
 * VIP 고객관리
 */
@Data
public class ResConsultVipVO extends CommonReqVO {

    private String vip_no = "";
    private String service_no = "";
    private String user_no = "";
    private String user_id = "";
    private String user_name = "";
    private String customer_no = "";
    private String customer_name = "";
    private String vip_level = "";
    private String reason = "";
}
