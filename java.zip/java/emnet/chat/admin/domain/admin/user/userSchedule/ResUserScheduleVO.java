package emnet.chat.admin.domain.admin.user.userSchedule;

import emnet.chat.admin.domain.common.CommonResVO;
import lombok.Data;

@Data
public class ResUserScheduleVO extends CommonResVO {
    private String user_schedule_no;
    private String user_no;
    private String emp_no;
    private String user_name;
    private String service_no;
    private String schedule_date;
    private String schedule_date_nm;
    private String start_time;
    private String end_time;
    private String lunch_start_time;
    private String lunch_end_time;
    private String rest_end_time;
    private String rest_start_time;
    private String in_work_time;
    private String in_work_cnt;
    private String out_work_time;
    private String out_work_cnt;
}
