package emnet.chat.admin.domain.admin.user.userSchedule;

import emnet.chat.admin.domain.common.CommonReqVO;
import lombok.Data;

@Data
public class ReqUserScheduleEtcVO  extends CommonReqVO {
    private String schedule_etc_no;
    private String user_schedule_no;
    private String user_no;
    private String service_no;
    private String work_type;
    private String work_cd;
    private String start_time;
    private String end_time;
    private String etc_comment="";
}
