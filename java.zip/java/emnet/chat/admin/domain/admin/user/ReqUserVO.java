package emnet.chat.admin.domain.admin.user;


import emnet.chat.admin.domain.common.CommonReqVO;
import lombok.Data;

/**
 * 상담원 VO
 * @author HonG
 *
 */
@Data
public class ReqUserVO extends CommonReqVO {
	private String service_no;
	private String user_no;
	private String permission_no;
	private String department_no;
	private String group_no;
	private String emp_no;
	private String passwd;
	private String category_name;
	private String name;
	private String phone;
	private String email;
	private String room_limit;
	private String consult_enable;
	private String work_status_type;
	private String work_yn;
	private String avatar_type;
	private String alarm_type;
	private String alarm_popup_type;
	private String excess_email_date;
	private String start_time;
	private String end_time;


}
