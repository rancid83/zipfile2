package emnet.chat.admin.domain.admin.user.userSchedule;

import emnet.chat.admin.domain.common.CommonReqVO;
import lombok.Data;

@Data
public class ReqUserScheduleVO extends CommonReqVO {
    private String user_schedule_no;
    private String user_no;
    private String user_name;
    private String service_no;
    private String schedule_date;
    private String lunch_start_time;
    private String lunch_end_time;
    private String rest_end_time;
    private String rest_start_time;
}
