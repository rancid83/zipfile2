package emnet.chat.admin.domain.admin.user.userCategory;

import emnet.chat.admin.domain.common.CommonReqVO;
import lombok.Data;

@Data
public class ReqUserCategoryVO extends CommonReqVO {
	private String service_no;
	private String consult_category_no;
	private String user_no;
	private String user_name;
	private String category_name;
}
