package emnet.chat.admin.domain.admin.user.userRest;

import emnet.chat.admin.domain.common.CommonReqVO;
import lombok.Data;

@Data
public class ReqUserRestVO extends CommonReqVO {
	private String user_schedule_no;
	private String service_no;
	private String rest_type;
	private String user_no;
	private String emp_no;
	private String name;
	private String start_time;
	private String end_time;
	private String reason;
}
