package emnet.chat.admin.domain.admin.user.userSkill;

import emnet.chat.admin.domain.common.CommonReqVO;
import lombok.Data;
@Data
public class ReqUserSkillVO extends CommonReqVO {
	private String service_no;
	private String skill_no;
	private String user_no;
	private String skill_name;
}
