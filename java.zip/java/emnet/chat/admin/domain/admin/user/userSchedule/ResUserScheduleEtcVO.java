package emnet.chat.admin.domain.admin.user.userSchedule;

import lombok.Data;

@Data
public class ResUserScheduleEtcVO {
    private String schedule_etc_no;
    private String user_schedule_no;
    private String user_no;
    private String service_no;
    private String work_type;
    private String work_cd;
    private String start_time;
    private String end_time;
    private String etc_comment;
}
