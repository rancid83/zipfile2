package emnet.chat.admin.domain.admin.dashboard;

import emnet.chat.admin.domain.common.CommonReqVO;
import lombok.Data;

@Data
public class ResDashboardSummaryVO extends CommonReqVO {
    private String waiting_cnt;
    private String work_cnt;
    private String total_consult_cnt;
    private String avg_waiting_time;
}
