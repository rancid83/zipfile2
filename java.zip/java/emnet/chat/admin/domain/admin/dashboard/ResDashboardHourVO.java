package emnet.chat.admin.domain.admin.dashboard;

import emnet.chat.admin.domain.common.CommonReqVO;
import lombok.Data;

@Data
public class ResDashboardHourVO extends CommonReqVO {
    private String hour;
    private String consult_cnt;
    private String consult_req_cnt;
}
