package emnet.chat.admin.domain.admin.dept;

import emnet.chat.admin.domain.common.CommonReqVO;
import lombok.Data;
@Data
public class ReqDepartmentVO extends CommonReqVO {
	private String department_no = "";
	private String department_no_ref = "0";
	private String department_level  = "";
	private String department_name = "";
	private String use_yn= "";
}
