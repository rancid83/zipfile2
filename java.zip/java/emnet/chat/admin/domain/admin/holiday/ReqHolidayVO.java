package emnet.chat.admin.domain.admin.holiday;

import emnet.chat.admin.domain.common.CommonReqVO;
import lombok.Data;

/**
 * VIP 고객관리
 */
@Data
public class ReqHolidayVO extends CommonReqVO {

    private String holiday_no;
    private String service_no;
    private String start_date;
    private String end_date;
    private String holiday_name;
    private String use_yn;

}
