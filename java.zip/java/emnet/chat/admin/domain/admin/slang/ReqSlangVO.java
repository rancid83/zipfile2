package emnet.chat.admin.domain.admin.slang;

import emnet.chat.admin.domain.common.CommonReqVO;
import lombok.Data;

@Data
public class ReqSlangVO extends CommonReqVO {
    private String slang_no;
    private String service_no;
    private String content;
}
