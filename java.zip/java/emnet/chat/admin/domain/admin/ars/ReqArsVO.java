package emnet.chat.admin.domain.admin.ars;

import emnet.chat.admin.domain.common.CommonReqVO;
import lombok.Data;

@Data
public class ReqArsVO extends CommonReqVO {
    private String service_no;
    private String ars_no;
    private String ars_type=" ";
    private String title=" ";
    private String use_yn=" ";
    private String content=" ";
    private Integer no_reply_time = 0;
    private Integer end_time = 0;
    private String end_content="";
}
