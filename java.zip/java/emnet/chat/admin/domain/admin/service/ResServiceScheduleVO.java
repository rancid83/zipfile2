package emnet.chat.admin.domain.admin.service;

import emnet.chat.admin.domain.common.CommonResVO;
import lombok.Data;

@Data
public class ResServiceScheduleVO extends CommonResVO {
    private String week_cd;
    private String service_no;
    private String start_time;
    private String end_time;
    private String rest_start_time;
    private String rest_end_time;
    private String lunch_start_time;
    private String lunch_end_time;


}
