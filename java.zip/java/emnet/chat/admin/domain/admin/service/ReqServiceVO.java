package emnet.chat.admin.domain.admin.service;

import emnet.chat.admin.domain.common.CommonReqVO;
import emnet.chat.admin.domain.common.CommonResVO;
import lombok.Data;

@Data
public class ReqServiceVO extends CommonReqVO {
    private String service_no= "";
    private String service_name= "";
    private String account_max= "";
    private String auto_change= "";
    private String alarm_default_time= "";
    private String consult_status= "";
    private String consult_excess_count= "0";
    private String consult_excess_email= "";
    private String consult_evaluate= "";
    private String consult_evaluate_comment= "";
    private String consult_offtime= "";
    private String target_time= "";
    private String wait_time= "";
    private String distribute_type= "";
}
