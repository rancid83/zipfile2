package emnet.chat.admin.domain.admin.service;

import emnet.chat.admin.domain.admin.user.ReqUserVO;
import emnet.chat.admin.domain.common.CommonResVO;
import lombok.Data;

import java.util.ArrayList;

@Data
public class ReqServiceScheduleBatchVO {

    private String start_date;
    private String end_date;
    private ArrayList<ReqUserVO> userList = new ArrayList<>();
    private ArrayList<ResServiceScheduleVO> dateList = new ArrayList<>();

}
