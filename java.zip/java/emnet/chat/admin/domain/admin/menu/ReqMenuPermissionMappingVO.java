package emnet.chat.admin.domain.admin.menu;

import emnet.chat.admin.domain.common.CommonReqVO;
import lombok.Data;

@Data
public class ReqMenuPermissionMappingVO extends CommonReqVO {
    private String menu_no;
    private String service_no;
    private String permission_no;

}
