package emnet.chat.admin.domain.admin.menu;

import emnet.chat.admin.domain.common.CommonResVO;
import lombok.Data;

@Data
public class ResPermissionMenuVO extends CommonResVO {
    private String menu_no;
    private String service_no;
    private String parent_menu_no;
    private String menu_url;
    private String icon;
    private String menu_name;
    private String root_sub_menu_cnt;
    private String sub_menu_cnt;
    private String use_yn;
    private String menu_level;
    private String depth_fullname;
    private String sort_no;
    private String view_id;
    private String activate = "N";
}
