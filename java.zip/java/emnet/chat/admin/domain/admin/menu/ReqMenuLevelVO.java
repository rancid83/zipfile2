package emnet.chat.admin.domain.admin.menu;

import emnet.chat.admin.domain.common.CommonResVO;
import lombok.Data;

@Data
public class ReqMenuLevelVO extends CommonResVO {
    private String menu_no;
    private String service_no;
    private String menu_0_no;
    private String menu_0_name;
    private String level0_row_span;
    private String level0_rank;
    private String menu_1_no;
    private String menu_1_name;
    private String level1_row_span;
    private String level1_rank;
    private String level3_no;
    private String level3_name;
}