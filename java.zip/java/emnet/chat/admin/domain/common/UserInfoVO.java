package emnet.chat.admin.domain.common;

import lombok.Data;

@Data
public class UserInfoVO {
	private int service_no;
	private int user_no;
	private String emp_no;
	private String user_id;
	private String name;
	private int permission_no;
	private int department_no;

	// 접속 IP
	private String reqAddr;
	//ADMIN: 관리자, COUNSELOR: 상담사, ALL:관리자,상담사,NONE: 무권한
	private String auth_type;
}
