package emnet.chat.admin.domain.common;

import emnet.chat.admin.common.utils.SessionUtils;

import java.util.Date;

public class CommonRspVO {
	private int service_no;
	private String data_regr_id;
	private Date data_reg_dtm;
	private String data_chgr_id;
	private Date data_chg_dtm;
	
	public String getData_regr_id() {
		UserInfoVO userInfoVO = SessionUtils.getUserInfo();
		return userInfoVO.getUser_id();
	}
	
	public Date getData_reg_dtm() {
		return data_reg_dtm;
	}
	public void setData_reg_dtm(Date data_reg_dtm) {
		this.data_reg_dtm = data_reg_dtm;
	}
	public String getData_chgr_id() {
		UserInfoVO userInfoVO = SessionUtils.getUserInfo();
		return userInfoVO.getUser_id();
	}
	
	public Date getData_chg_dtm() {
		return data_chg_dtm;
	}
	public void setData_chg_dtm(Date data_chg_dtm) {
		this.data_chg_dtm = data_chg_dtm;
	}

	public int getService_no() {
		UserInfoVO userInfoVO = SessionUtils.getUserInfo();
		return userInfoVO.getService_no();
	}
	
}
