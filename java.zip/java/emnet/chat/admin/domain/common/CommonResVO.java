package emnet.chat.admin.domain.common;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Data;

import java.io.Serializable;

@Data
@JsonInclude(value = JsonInclude.Include.ALWAYS)
public class CommonResVO implements Serializable {
	protected String id;
	protected String dat_flag= "";
	protected String del_flag= "0";
	protected String data_regr_id= "system";
	protected String data_reg_dtm;
	protected String data_chgr_id= "system";
	protected String data_chg_dtm;
	protected String level1_no;
	protected String level1_name;
	protected String level2_no;
	protected String level2_name;
	protected String level3_no;
	protected String level3_name;
}
