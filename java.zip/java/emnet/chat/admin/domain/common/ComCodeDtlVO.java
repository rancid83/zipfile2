package emnet.chat.admin.domain.common;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Data;

import java.io.Serializable;

@Data

public class ComCodeDtlVO extends CommonReqVO {

    /**
     *
     */
    private static final long serialVersionUID = 1L;
    private String com_group_cd;
    private String com_cd;
    private String com_cd_nm;
    private String ref_01="";
    private String ref_02="";
    private String ref_03="";
    private String ref_04="";
    private String ref_05="";
    private String sort_no="";
    private String use_yn="";


}
