package emnet.chat.admin.domain.common.cache;

import emnet.chat.admin.domain.common.ComCodeDtlVO;
import lombok.Data;

import java.util.ArrayList;

@Data
public class ComCodeCacheVO {
    private String com_group_cd;
    private String objId;
    private String grid_yn;
    private String ref_01;
    private String ref_02;
    private String show_all;
    private String defaultVal;
    private String grid_idx;
    private String callback;
    ArrayList<ComCodeDtlVO> codeList;
}
