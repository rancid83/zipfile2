package emnet.chat.admin.domain.common;

import lombok.Data;

import java.io.Serializable;

@Data
public class ComCodeMstVO extends CommonReqVO {


    private static final long serialVersionUID = -4578955123620206317L;
    private String com_group_cd;
    private String com_group_cd_nm;
    private String com_group_comment;
    private String use_yn;
}

