package emnet.chat.admin.domain.common;

public class SessionDef {

}
