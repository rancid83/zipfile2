package emnet.chat.admin.domain.common;

import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.List;

public class ComReqPagingVo {
	private String dat_flag;
	
	//화면에서 올라옴.
	private List<String> sortBy; //sort 대상 컬럼명
	private List<Boolean> sortDesc; //해당 컬럼의 정렬방법 true시 내림차순(큰수부터)
	private int page; //페이지 번호 1부터 시작
	private int itemsPerPage; //화면의 표현 page갯수	
	
	private String create_id = "system";
	private String create_dt;
	//private ArrayList<String> sortSqlList; //화면의 sort대상 컬럼과 dto컬럼 체크후 sql 생성
	
	public List<String> getSortBy() {
		return sortBy;
	}
	public void setSortBy(List<String> sortBy) {
		this.sortBy = sortBy;
	}
	public List<Boolean> getSortDesc() {
		return sortDesc;
	}
	public void setSortDesc(List<Boolean> sortDesc) {
		this.sortDesc = sortDesc;
	}
	public int getPage() {
		return page;
	}
	public void setPage(int page) {
		this.page = page;
	}
	public int getItemsPerPage() {
		return itemsPerPage;
	}
	public void setItemsPerPage(int itemsPerPage) {
		this.itemsPerPage = itemsPerPage;
	}
	public ArrayList<String> getSortSqlList() {
		if(sortBy == null) {
			return null;
		}
		Field fields[] = this.getClass().getDeclaredFields();
		
		ArrayList<String> sortSqlList = new ArrayList<String>();
		for(int i=0; i < sortBy.size(); i++) {
			String sortCol = sortBy.get(i);
			if(checkSortCol(fields, sortCol)){
				setSortedSql(sortSqlList, sortCol, sortDesc.get(i));				
			}			
		}
		return sortSqlList;
	}
	
	public int getStartedPage() {
		return ((page -1) * itemsPerPage);
	}
	
	private void setSortedSql(List<String> sortSqlList, String sortCol, Boolean isDesc) {
		if(isDesc) {
			sortSqlList.add(sortCol + " desc");
		}else {
			sortSqlList.add(sortCol + " asc");
		}
		
	}
	private boolean checkSortCol(Field[] fields, String sortCol) {
		for(Field field : fields) {
			if(sortCol.equals(field.getName())) {
				return true;
			}
		}
		return false;		
	}
	public void getAscList() {
		
	}
	public String getDat_flag() {
		return dat_flag;
	}
	public void setDat_flag(String dat_flag) {
		this.dat_flag = dat_flag;
	}
	public String getCreate_id() {
		return create_id;
	}
	public void setCreate_id(String create_id) {
		this.create_id = create_id;
	}
	public String getCreate_dt() {
		return create_dt;
	}
	public void setCreate_dt(String create_dt) {
		this.create_dt = create_dt;
	}
	
}
