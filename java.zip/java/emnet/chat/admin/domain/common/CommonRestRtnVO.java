package emnet.chat.admin.domain.common;

import emnet.chat.admin.common.exception.FaultCode;
import emnet.chat.admin.common.utils.DateUtils;

public class CommonRestRtnVO  {
	private String resultCode = "SUCCESS";
	private String resultMessage = "SUCCESS";
	private String resposeDate;
	
	public String getResposeDate() {
		return resposeDate;
	}

	public void setResposeDate(String resposeDate) {
		this.resposeDate = resposeDate;
	}

	public CommonRestRtnVO() {		
		super();
		setSuccsess();
	}
	
	public void setSuccsess() {
		this.resultCode = FaultCode.SUCCESS.getCode();
		this.resultMessage = FaultCode.SUCCESS.getDescription();
		this.resposeDate = DateUtils.getDate(DateUtils.BASE_FULL_FORMAT);
	}

	public CommonRestRtnVO(String resultCode, String resultMessage) {
		super();
		this.resultCode = resultCode;
		this.resultMessage = resultMessage;
	}

	public String getResultCode() {
		return resultCode;
	}

	public void setResultCode(String resultCode) {
		this.resultCode = resultCode;
	}

	public String getResultMessage() {
		return resultMessage;
	}

	public void setResultMessage(String resultMessage) {
		this.resultMessage = resultMessage;
	}
}