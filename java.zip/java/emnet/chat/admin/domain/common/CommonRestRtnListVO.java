package emnet.chat.admin.domain.common;

import java.util.ArrayList;

public class CommonRestRtnListVO<T> extends CommonRestRtnVO {

	private ArrayList<T> resultList = new ArrayList<>();

	public ArrayList<T> getResultList() {
		return resultList;
	}

	public void setResultList(ArrayList<T> resultList) {
		this.resultList = resultList;
	}

}