package emnet.chat.admin.domain.common;

import lombok.Data;

import java.io.Serializable;
import java.util.ArrayList;

@Data
public class ComCodeGridVO implements Serializable {
	private String grid_yn;
	private String obj_id;
	private String obj_idx;
	private String site_cd;
	private String grp_cd;
	private String callback;
	private String ref_01;
	private String ref_02;
	private String value;
	private String all_yn;
	private String all_text;
	private ArrayList<ComCodeDtlVO> grpCodeList;
}
