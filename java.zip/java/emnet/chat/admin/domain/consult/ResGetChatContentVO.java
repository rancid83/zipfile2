package emnet.chat.admin.domain.consult;

import lombok.Data;

@Data
public class ResGetChatContentVO {
    private String type;
    private String name;
    private String content;
    private String user_type;
    private String consult_no;
    private String create_time;
}
