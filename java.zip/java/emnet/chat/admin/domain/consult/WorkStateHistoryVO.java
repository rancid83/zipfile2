package emnet.chat.admin.domain.consult;

import lombok.Data;

@Data
public class WorkStateHistoryVO {
    private int work_status_history_no;
    private int service_no;
    private int user_no;
    private String user_id;
    private String work_status_type;
    private String start_date;
    private String end_date;
    private String data_regr_id;
    private String data_reg_dtm;
    private String data_chgr_id;
    private String data_chg_dtml;
}
