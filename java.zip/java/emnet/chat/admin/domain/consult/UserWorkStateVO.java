package emnet.chat.admin.domain.consult;

import lombok.Data;

@Data
public class UserWorkStateVO {
    private String work_yn;
    private String new_work_status_type;
    private String old_work_status_type;
    private String work_status_type;
    private int service_no;
    private int work_status_history_no;
    private int user_no;
    private String user_id;
}
