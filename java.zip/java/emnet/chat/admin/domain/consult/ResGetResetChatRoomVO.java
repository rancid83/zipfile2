package emnet.chat.admin.domain.consult;

import lombok.Data;

@Data
public class ResGetResetChatRoomVO {
    private String auth_nm;
    private String customer_name;
    private String customer_id;
    private String income_type_nm;
    private String room_no;
    private int customer_no;
    private String consult_start_yn;
}
