package emnet.chat.admin.domain.consult;

import lombok.Data;

@Data
public class ComCodeVO {
    private String com_group_cd;
    private String com_cd;
    private String com_cd_nm;
    private String ref_01;
    private String ref_02;
    private String ref_03;
    private String ref_04;
    private String ref_05;
    private String use_yn;
    private String data_regr_id;
    private String data_reg_dtm;
    private String data_chgr_id;
    private String data_chg_dtm;
    private int sort_no;
}
