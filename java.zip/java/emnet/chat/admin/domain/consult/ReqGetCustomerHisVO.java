package emnet.chat.admin.domain.consult;

import lombok.Data;

@Data
public class ReqGetCustomerHisVO {
    private int service_no;
    private int customer_no;
}
