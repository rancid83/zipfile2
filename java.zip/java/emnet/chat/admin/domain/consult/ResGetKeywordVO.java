package emnet.chat.admin.domain.consult;

import lombok.Data;

@Data
public class ResGetKeywordVO {
    private int rnum;
    private int service_no;
    private int keyword_no;
    private String category_name;
    private String answer;
    private String question;
    private String keyword;
}
