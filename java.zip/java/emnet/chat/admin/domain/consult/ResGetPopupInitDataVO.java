package emnet.chat.admin.domain.consult;

import lombok.Data;

import java.util.List;

@Data
public class ResGetPopupInitDataVO {
    private String department_name;
    private int department_cd;
    private String center_name;
    private int center_cd;
    private String team_name;
    private int team_cd;
    private String counselor_name;
    private List<ComComboVO> categorySkillComboList;
    private List<ComComboVO> departmentComboList;
}
