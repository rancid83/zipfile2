package emnet.chat.admin.domain.consult;

import lombok.Data;

@Data
public class ConsultMenuVO {
    private String menu_no;
    private String service_no;
    private String parent_menu_no;
    private String menu_url;
    private String menu_name;
    private String sort_no;
}
