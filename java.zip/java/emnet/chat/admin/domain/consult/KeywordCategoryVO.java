package emnet.chat.admin.domain.consult;

import lombok.Data;

@Data
public class KeywordCategoryVO {
    private String service_no;
    private String keyword_category_no;
    private String name;
    private String data_regr_id;
    private String data_reg_dtm;
    private String data_chgr_id;
    private String data_chg_dtm;
}
