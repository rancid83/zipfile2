package emnet.chat.admin.domain.consult;

import lombok.Data;

@Data
public class ResGetConsultStateCountVO {
    private int wait_cnt;
    private int busy_cnt;
    private int end_cnt;
}
