package emnet.chat.admin.domain.consult;

import lombok.Data;

@Data
public class ResGetUserChatStateVO {
    private String distribute_yn;
    private String work_status_type;
    private String work_yn;
}
