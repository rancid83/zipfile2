package emnet.chat.admin.domain.consult;

import lombok.Data;

@Data
public class ReqModifyUserDistributeVO {
    private String distribute_yn;
    private int service_no;
    private int user_no;
    private String user_id;
}
