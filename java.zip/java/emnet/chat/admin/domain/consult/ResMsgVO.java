package emnet.chat.admin.domain.consult;

import lombok.Data;

@Data
public class ResMsgVO {
    public ResMsgVO(String msg){
        this.msg = msg;
    }
    private String msg;
}
