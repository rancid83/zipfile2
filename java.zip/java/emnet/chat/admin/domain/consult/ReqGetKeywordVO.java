package emnet.chat.admin.domain.consult;

import lombok.Data;

@Data
public class ReqGetKeywordVO {
    private int service_no;
    private int user_no;
    private String  keyword;
    private int keyword_category_no;
}
