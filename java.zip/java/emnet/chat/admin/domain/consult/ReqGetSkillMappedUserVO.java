package emnet.chat.admin.domain.consult;

import lombok.Data;

@Data
public class ReqGetSkillMappedUserVO {
    private int service_no;
    private int department_no;
    private int consult_category_no;
}
