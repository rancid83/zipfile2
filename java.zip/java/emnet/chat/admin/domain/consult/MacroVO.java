package emnet.chat.admin.domain.consult;

import lombok.Data;

@Data
public class MacroVO {
    private int macro_no;
    private int service_no;
    private int user_no;
    private String macro_key;
    private String macro_content;
    private String data_regr_id;
    private String data_reg_dtm;
    private String data_chgr_id;
    private String data_chg_dtm;
}
