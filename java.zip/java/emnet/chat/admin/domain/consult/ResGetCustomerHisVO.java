package emnet.chat.admin.domain.consult;

import lombok.Data;

@Data
public class ResGetCustomerHisVO {
    private int rnum;
    private int service_no;
    private String consult_no;
    private String consult_dt;
    private String start_dt;
    private String end_dt;
    private String income;
    private String auth;
    private String skill_name;
    private String user_name;
    private String emp_no;
    private String user_no;
}
