package emnet.chat.admin.domain.consult;

import lombok.Data;

@Data
public class ReqGetUserComboVO {
    private int service_no;
    private int department_no;
}