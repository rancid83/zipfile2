package emnet.chat.admin.domain.consult;

import lombok.Data;

@Data
public class ComComboVO {
    private String value;
    private String text;
}
