package emnet.chat.admin.domain.consult;

import lombok.Data;

@Data
public class ResGetConsultVO {
    private int rnum;
    private String state_cd;
    private String state;
    private String customer_name;
    private String customer_id;
    private String income;
    private String wait_time;
    private String consult_no;
    private String skill_name;
    private String chat_start_time;


}
