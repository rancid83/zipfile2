package emnet.chat.admin.domain.consult;

import lombok.Data;

@Data
public class ReqGetChatContentVO {
    private int service_no;
    private int logging_no;
    private int user_no;
    private String emp_no;
    private String info;
    private String user_id;
    private String consult_no;
    private String data_regr_id;
    private String data_chgr_id;
}
