package emnet.chat.admin.domain.consult;

import lombok.Data;

@Data
public class ReqGetDepartmentComboVO {
    private int department_no;
}
