package emnet.chat.admin.domain.consult;

import lombok.Data;

@Data
public class ReqModifyChangeReqVO {
    private String req_type;
    private String req_reason;
    private int req_user_no;
    private int service_no;
    private String consult_no;
    private int req_consult_category_no;
    private String user_id;
}
