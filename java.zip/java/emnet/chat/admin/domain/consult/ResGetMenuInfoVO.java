package emnet.chat.admin.domain.consult;

import lombok.Data;

import java.util.List;

@Data
public class ResGetMenuInfoVO {
    private String authType;
    private List<ConsultMenuVO> myMenuList;
    private List<ConsultMenuVO> statisticsMenuList;
}
