package emnet.chat.admin.domain.consult;

import lombok.Data;

@Data
public class ReqGetMenuInfoVO {
    private int service_no;
    private int user_no;
    private int parent_menu_no;
}
