package emnet.chat.admin.domain.consult;

import lombok.Data;

@Data
public class ReqGetConsultStateCountVO {
    private int service_no;
    private int user_no;

}
