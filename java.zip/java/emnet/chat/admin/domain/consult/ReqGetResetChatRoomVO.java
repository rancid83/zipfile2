package emnet.chat.admin.domain.consult;

import lombok.Data;

@Data
public class ReqGetResetChatRoomVO {
    private int service_no;
    private int user_no;
}
