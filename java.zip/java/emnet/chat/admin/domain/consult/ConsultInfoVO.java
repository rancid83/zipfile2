package emnet.chat.admin.domain.consult;

import lombok.Data;

@Data
public class ConsultInfoVO {
    private int service_no;
    private String consult_no;
    private int customer_no;
    private String customer_name;
    private String customer_id;
    private String income;
    private String auth;
}
