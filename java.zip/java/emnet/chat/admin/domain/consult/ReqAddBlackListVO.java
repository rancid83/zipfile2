package emnet.chat.admin.domain.consult;

import lombok.Data;

@Data
public class ReqAddBlackListVO {
    private int service_no;
    private int user_no;
    private int vip_no;
    private int customer_no;
    private String reason;
    private String data_regr_id;
    private String data_reg_dtm;
    private String data_chgr_id;
    private String data_chg_dtm;
}
