package emnet.chat.admin.domain.consult;

import lombok.Data;

@Data
public class ReqGetConsultVO {
    private int service_no;
    private int user_no;
    private String consult_status;
    private String user_id;
    private String user_name;
    private String consult_no;
}
