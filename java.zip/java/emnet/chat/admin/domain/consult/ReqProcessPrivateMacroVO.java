package emnet.chat.admin.domain.consult;

import lombok.Data;

@Data
public class ReqProcessPrivateMacroVO {
    private int macro_no;
    private int service_no;
    private int user_no;
    private String macro_key;
    private String macro_content;
    private String dt_state_flag;

}
