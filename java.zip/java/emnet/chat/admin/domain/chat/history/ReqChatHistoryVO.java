package emnet.chat.admin.domain.chat.history;

public class ReqChatHistoryVO {

}
