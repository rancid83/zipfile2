package emnet.chat.admin.domain.chat;

public class ReqChatRoomVO {

}
