package emnet.chat.admin.config;

import java.util.Properties;

import com.zaxxer.hikari.HikariDataSource;
import org.apache.ibatis.session.SqlSessionFactory;
import org.mybatis.spring.SqlSessionFactoryBean;
import org.mybatis.spring.SqlSessionTemplate;
import org.mybatis.spring.annotation.MapperScan;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.autoconfigure.jdbc.DataSourceProperties;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.*;
import org.springframework.jdbc.datasource.lookup.JndiDataSourceLookup;
import org.springframework.transaction.annotation.EnableTransactionManagement;

import javax.naming.Context;
import javax.naming.InitialContext;
//import javax.sql.DataSource;
import com.zaxxer.hikari.HikariDataSource;

import javax.naming.NamingException;

/**
 * <pre>
 * DB CRUD용 MS Sql DB 연결 관련 설정.  
 * </pre>
 *
 * Created on 2019. 01. 20.
 * 
 * @author 강민재
 */
@Configuration
//@PropertySource(value = { "file:/file/prop/${server.mode:emnet}/emnet-repository.properties" })
@PropertySource(value = { "file:/ERP/Apps/ChatCounselApp/app_config/emnet-repository.properties" })
@MapperScan(value={"emnet.chat.admin.mapper.mst"}, sqlSessionFactoryRef = "mstSqlSessionFactory")
@EnableTransactionManagement
public class RepositoryMstConfig {

	Logger logger = LoggerFactory.getLogger(RepositoryMstConfig.class);

	@Value("${db.owner:CHATDEV}")
	private String DB_OWNER;

	@Bean(name = "DataSourceProperties")
	@ConfigurationProperties(prefix = "jdbc.main.datasource")
	@Primary
	public DataSourceProperties dataSourceProperties() {
		return new DataSourceProperties();
	}

	/*@Primary
	@Bean(name = "mstDataSourceAdmin")
	public DataSource jndiDatasource() throws IllegalArgumentException, NamingException {
		String jndiName = dataSourceProperties().getJndiName();
		System.out.println("[JM]jndiName : "+jndiName);
		return (DataSource) new JndiDataSourceLookup().getDataSource(jndiName);
	}*/


	@Primary
	@Bean(name = "mstDataSourceAdmin")
	public HikariDataSource dataSource(@Qualifier("DataSourceProperties") DataSourceProperties properties) {
		return properties.initializeDataSourceBuilder().type(HikariDataSource.class).build();
	}

	@Bean(name = "mstSqlSessionFactory")
	@Primary
	public SqlSessionFactory mstSqlSessionFactory(
			@Qualifier("mstDataSourceAdmin") HikariDataSource mstDataSource,
			//@Qualifier("mstDataSourceAdmin") DataSource mstDataSource,
			ApplicationContext context) throws Exception {

		SqlSessionFactoryBean sessionFactoryBean = new SqlSessionFactoryBean();
		try {
			logger.info("START Setting sqlSessionFactotry");

			sessionFactoryBean.setDataSource(mstDataSource);
			//sessionFactoryBean.setConfigLocation(context.getResource("classpath:mybatis-config.xml"));
			sessionFactoryBean.setMapperLocations(context.getResources("classpath:mapper/mst/**/*.xml"));
			Properties prop = new Properties();
			prop.setProperty("DB_OWNER", DB_OWNER);
			sessionFactoryBean.setConfigurationProperties(prop);

		//	sessionFactoryBean.setConfiguration();
			sessionFactoryBean.setTypeAliasesPackage("emnet.chat.admin.domain");
			                                          
													  

			logger.info("End Setting sqlSessionFactotry");
		} catch (Exception e) {
			e.printStackTrace();
		}
		return sessionFactoryBean.getObject();
	}

	@Bean(name = "mstSqlSessionTemplate")
	@Primary
	public SqlSessionTemplate mstSqlSessionTemplate(SqlSessionFactory mstSqlSessionFactory) throws Exception {
		
		return new SqlSessionTemplate(mstSqlSessionFactory);
	}

}
