package emnet.chat.admin.config;

import java.nio.charset.Charset;
import java.util.List;

import javax.servlet.Filter;

import com.fasterxml.jackson.databind.ObjectMapper;
import emnet.chat.admin.common.interceptor.AuthCheckInterceptor;
import emnet.chat.admin.common.utils.HTMLCharacterEscapes;
import lombok.extern.slf4j.Slf4j;
import org.springframework.boot.web.servlet.FilterRegistrationBean;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;
import org.springframework.http.converter.HttpMessageConverter;
import org.springframework.http.converter.StringHttpMessageConverter;
import org.springframework.http.converter.json.MappingJackson2HttpMessageConverter;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.web.filter.CharacterEncodingFilter;
import org.springframework.web.servlet.config.annotation.InterceptorRegistry;
import org.springframework.web.servlet.config.annotation.ResourceHandlerRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurerAdapter;
import org.springframework.web.servlet.view.UrlBasedViewResolver;
import org.springframework.web.servlet.view.tiles3.TilesConfigurer;
import org.springframework.web.servlet.view.tiles3.TilesView;

import emnet.chat.admin.common.Filter.AccessLogFilter;
import emnet.chat.admin.common.interceptor.LoginCheckInterceptor;
import emnet.chat.admin.common.interceptor.RequestParamInterceptor;
import sun.rmi.runtime.Log;

/**
 * <pre>
 * jsp연결 및 인터셉터 등 기타 설정 정보.
 * </pre>
 * <p>
 * Created on 2019. 01. 20.
 *
 * @author 강민재
 */
@EnableScheduling
@Configuration
@PropertySource(value = {"file:/ERP/Apps/ChatCounselApp/app_config/application.properties"})
@Slf4j
public class WebMvcConfig implements WebMvcConfigurer {


    @Bean
    public RequestParamInterceptor requestParamInterceptor() {
        return new RequestParamInterceptor();
    }

    @Bean
    public LoginCheckInterceptor loginCheckInterceptor() {
        return new LoginCheckInterceptor();
    }


    @Bean
    AuthCheckInterceptor authCheckInterceptor() {
        return new AuthCheckInterceptor();
    }

    @Override
    public void addInterceptors(InterceptorRegistry registry) {
        // TODO Auto-generated method stub
        registry.addInterceptor(requestParamInterceptor()).addPathPatterns("/**").excludePathPatterns("/resources/**");


        registry.addInterceptor(authCheckInterceptor())
                .addPathPatterns("/admin/**")
                .addPathPatterns("/chatConsult/**")
                .excludePathPatterns("/admin/comCode/getComComboCache.do")
                .excludePathPatterns("/admin/department/get**List.do")
                .excludePathPatterns("/admin/consultCategory/**")
                .excludePathPatterns("/resources/**")
                .excludePathPatterns("/admin/userCategory/**")
                .excludePathPatterns("/login.do")
                .excludePathPatterns("/logout.do");


        registry.addInterceptor(loginCheckInterceptor()).addPathPatterns("/admin/**")
                .addPathPatterns("/chatConsult/**").
                excludePathPatterns("/")
                .excludePathPatterns("/login.do").excludePathPatterns(
                "/logout.do");


        WebMvcConfigurer.super.addInterceptors(registry);
    }


    @Bean
    public WebMvcConfigurerAdapter webMvcConfigurerAdapter(){

        log.debug("call webmvcConfigAdapter!!!!!!!!!!!!!!!!!!!");
        return new WebMvcConfigurerAdapter() {
            @Override
            public void configureMessageConverters(List<HttpMessageConverter<?>> converters) {
                super.configureMessageConverters(converters);
                converters.add(htmlEscapingConverter());
            }

            private HttpMessageConverter<?> htmlEscapingConverter(){
                ObjectMapper objectMapper = new ObjectMapper();
                objectMapper.getFactory().setCharacterEscapes(new HTMLCharacterEscapes());
                MappingJackson2HttpMessageConverter htmlEscapingConverter = new MappingJackson2HttpMessageConverter();
                htmlEscapingConverter.setObjectMapper(objectMapper);
                return htmlEscapingConverter;
            }
        };
    }


    @Override
    public void addResourceHandlers(ResourceHandlerRegistry registry) {

        registry.addResourceHandler("/resources/**").addResourceLocations("classpath:static/");

        // TODO Auto-generated method stub
        WebMvcConfigurer.super.addResourceHandlers(registry);
    }


    @Bean
    public TilesConfigurer tilesConfigurer() {
        TilesConfigurer tilesConfigurer = new TilesConfigurer();
        String[] defs = {"WEB-INF/tiles/tiles.xml"};

        tilesConfigurer.setDefinitions(defs);

        return tilesConfigurer;
    }

    @Bean
    public UrlBasedViewResolver tilesViewResolver() {
        UrlBasedViewResolver tilesViewResolver = new UrlBasedViewResolver();

        tilesViewResolver.setViewClass(TilesView.class);
        tilesViewResolver.setOrder(1);
        return tilesViewResolver;
    }

    @Bean
    public HttpMessageConverter<String> responseBodyConverter() {
        return new StringHttpMessageConverter(Charset.forName("UTF-8"));
    }

    @Bean
    public Filter characterEncodingFilter() {
        CharacterEncodingFilter characterEncodingFilter = new CharacterEncodingFilter();
        characterEncodingFilter.setEncoding("UTF-8");
        characterEncodingFilter.setForceEncoding(true);
        return characterEncodingFilter;
    }

    @Bean
    public AccessLogFilter accessLogFilter() {
        return new AccessLogFilter();
    }

    @Bean
    public FilterRegistrationBean<AccessLogFilter> getFilterRegistrationBean() {
        FilterRegistrationBean<AccessLogFilter> registrationBean = new FilterRegistrationBean<AccessLogFilter>(accessLogFilter());

        return registrationBean;
    }
}
