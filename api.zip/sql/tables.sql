create table musicow_point.tb_comn_code
(
    comm_grp_cd    varchar(32)   not null comment '공통그룹코드'
        primary key,
    comm_grp_cd_nm varchar(512)  not null comment '공통그룹코드명',
    rmk_ctnts      varchar(1024) null comment '비고내용',
    use_yn         varchar(32)   null comment '사용여부',
    rec_date       datetime      null comment '등록일자',
    rec_user_id    varchar(32)   null comment '등록자아이디',
    mod_date       datetime      null comment '수정일자',
    mod_user_id    varchar(32)   null comment '수정자아이디'
)
    comment '공통코드그룹';

create table musicow_point.tb_comn_code_dtls
(
    comm_cd      varchar(32)  not null comment '공통코드',
    comm_grp_cd  varchar(32)  not null comment '공통그룹코드',
    comm_cd_nm   varchar(512) null comment '공통코드명',
    ref_1_val    varchar(32)  null comment '참조1값',
    ref_2_val    varchar(32)  null comment '참조1값',
    ref_3_val    varchar(32)  null comment '참조1값',
    ref_4_val    varchar(32)  null comment '참조1값',
    ref_5_val    varchar(32)  null comment '참조1값',
    sort_ordr_no int          null comment '정렬순서번호',
    use_yn       varchar(32)  null comment '사용여부',
    rec_date     datetime     null comment '등록일자',
    rec_user_id  varchar(32)  null comment '등록자아이디',
    mod_date     datetime     null comment '수정일자',
    mod_user_id  varchar(32)  null comment '수정자아이디',
    primary key (comm_cd, comm_grp_cd),
    constraint FK_33f54187cd91d95d0c62d6e996b
        foreign key (comm_grp_cd) references musicow_point.tb_comn_code (comm_grp_cd)
)
    comment '공통코드상세';

create index tb_comn_code_detail_tb_comn_code_comm_grp_cd_fk
    on musicow_point.tb_comn_code_dtls (comm_grp_cd);

create table musicow_point.tb_point_check
(
    event_type_cd varchar(32) not null comment '이벤트타입코드',
    user_no       int         not null comment '사용자번호',
    regdate       varchar(32) not null comment '출석일자(YYYYMMDD)',
    primary key (event_type_cd, user_no, regdate)
)
    comment '지급내역체크';

create table musicow_point.tb_point_exp_lst
(
    point_event_dtls_seq int         not null comment '포인트이벤트상세일련번호',
    point_event_seq      int         not null comment '포인트이벤트일련번호',
    amt_point            int         not null comment '포인트금액',
    point_state_cd       varchar(32) null comment '포인트상태',
    user_no              int         null comment '사용자번호',
    exp_date             datetime    null comment '만료일',
    send_state_cd        varchar(32) null,
    rec_date             datetime    null,
    rec_user_id          int         null,
    mod_date             datetime    null,
    mod_user_id          int         null,
    primary key (point_event_dtls_seq, point_event_seq)
)
    comment '포인트만료목록';

create table musicow_point.tb_point_pool_schedule
(
    event_schedule_id int auto_increment comment '이벤트스케줄아이디'
        primary key,
    point_pool_id     int                                      null comment '포인트풀아이디',
    schedule_name     varchar(255)                             null comment '스케줄명',
    schedule_date     varchar(32)                              null comment '스케줄일자',
    action_type_cd    varchar(32)                              null comment '액션타입코드',
    use_yn            varchar(32)                              null comment '사용여부',
    rec_date          datetime(6) default CURRENT_TIMESTAMP(6) null comment '등록일자',
    rec_user_id       varchar(32)                              null comment '등록자아이디',
    mod_date          datetime(6) default CURRENT_TIMESTAMP(6) null comment '수정일자',
    mod_user_id       varchar(32)                              null comment '수정일자',
    amt_save_option   int                                      null comment '포인트지급액'
)
    comment '이벤트스케줄';

create table musicow_point.tb_point_schedule
(
    schedule_id   int auto_increment comment '스케줄일련번호'
        primary key,
    point_pool_id int           null comment '포인트풀아아디',
    save_type     varchar(32)   null comment '포인트지급방식',
    starttime     varchar(32)   null comment '예약시작시간',
    endtime       varchar(32)   null comment '예약종료시간',
    event_type    varchar(32)   null comment '포인트이벤트유형',
    event_ctnts   varchar(1024) null comment '사유',
    sms_yn        varchar(2)    null comment '문자발송여부',
    save_state    varchar(32)   null comment '지급상태',
    rec_date      datetime      null comment '등록일',
    rec_user_id   varchar(32)   null comment '등록자아아디',
    mod_date      datetime      null comment '수정일자',
    mod_user_id   varchar(32)   null comment '수정자아이디',
    cnt_uploaded  int default 0 null comment '업로드건수'
)
    comment '포인트지급스케줄';

create table musicow_point.tb_point_schedule_dtls
(
    schedule_dtls_seq int auto_increment comment '포인트풀 상세지급 일련번호'
        primary key,
    schedule_id       int           not null comment '포인트스케줄 아이디',
    user_no           int           not null comment '사용자번호',
    amt_save_point    int           not null comment '지급포인트',
    save_state        varchar(32)   not null comment '지급상태',
    state_err_ctnts   varchar(1024) null comment '에러 메세지',
    constraint tb_point_schedule_dtls_tb_point_schedule_schedule_id_fk
        foreign key (schedule_id) references musicow_point.tb_point_schedule (schedule_id)
);

create table musicow_point.tb_service_oper_info
(
    service_id            bigint auto_increment comment '서비스아이디'
        primary key,
    point_pool_colct_type int           not null comment '배치 수집주기(초)',
    account_inquire_type  int           not null comment '법인계좌 조회주기(초)',
    account_limit_amount  varchar(32)   null comment '법인계좌 설정금액',
    jira_api_key          varchar(32)   null comment 'JIRA API KEY',
    jira_api_url          varchar(1024) null comment '지라 endpoint url',
    jira_api_jql          varchar(1024) null comment '지라 포인트풀 수집 jql ',
    oper_state_cd         varchar(32)   not null comment '운영상태 코드',
    rec_date              datetime      not null comment '등록일자',
    rec_user_id           varchar(32)   not null comment '등록자 아이디',
    mod_date              datetime      not null comment '수정일자',
    mod_user_id           varchar(32)   not null comment '수정자 아이디'
)
    comment '포인트서비스 운영정보 테이블';

create table musicow_point.tb_mngr_mastr
(
    service_id     bigint        not null comment '서비스아이디',
    mngr_id        varchar(32)   not null comment '관리자 아이디',
    password       varchar(512)  null comment '비밀번호',
    mngr_nm        varchar(32)   null comment '관리자이름',
    user_type      varchar(32)   null comment '사용자타입 공통[user_type]',
    refresh_token  varchar(1024) null comment '리프레시토큰',
    rec_date       datetime      null comment '등록일자',
    rec_user_id    varchar(32)   null comment '등록자아이디',
    mod_date       datetime      null comment '수정일자',
    mod_user_id    varchar(32)   null comment '수정자아이디',
    access_ip      varchar(1024) null comment '접근아이피',
    cnt_login_fail int           null comment '로그인실패건수',
    primary key (service_id, mngr_id),
    constraint tb_mngr_mastr_tb_service_oper_info_service_id_fk
        foreign key (service_id) references musicow_point.tb_service_oper_info (service_id)
)
    comment '관리자마스터';

create table musicow_point.tb_point_pool
(
    point_pool_id      bigint auto_increment comment '포인트풀 아이디'
        primary key,
    service_id         bigint                                   null comment '서비스 아이디',
    point_pool_type_cd varchar(32)                              null comment '포인트풀타입',
    event_type_cd      varchar(32)                              null comment '이벤트 타입',
    event_ctnts        varchar(1024)                            null comment '이벤트 내용',
    startdate          datetime                                 not null comment '이벤트 시작일',
    enddate            datetime                                 null comment '이벤트 종료일',
    amt_total          int         default 0                    not null comment '예산 총액',
    amt_remain         int         default 0                    not null comment '잔여 금액',
    amt_save           int         default 0                    not null comment '적립 금액',
    amt_save_min       int                                      null comment '최소 지급포인트(랜덤)',
    amt_save_max       int                                      null comment '최대 지급포인트(랜덤)',
    validity_days      int                                      null comment '유효기간일수',
    jira_ticket_id     varchar(255)                             null comment 'JIRA TICKET ID',
    approver           varchar(32)                              null comment '승인자',
    final_approver     varchar(32)                              null comment '최종승인자',
    use_yn             varchar(2)                               null comment '사용여부',
    rec_date           datetime(6) default CURRENT_TIMESTAMP(6) not null,
    rec_user_id        varchar(32)                              null comment '등록자 아이디',
    mod_user_id        varchar(32)                              null comment '수정자 아이디',
    mod_date           datetime(6) default CURRENT_TIMESTAMP(6) not null on update CURRENT_TIMESTAMP(6),
    constraint tb_point_pool_tb_service_oper_info_service_id_fk
        foreign key (service_id) references musicow_point.tb_service_oper_info (service_id)
)
    comment '포인트 예산 테이블';

create table musicow_point.tb_point_pool_dtls
(
    point_pool_log_seq bigint auto_increment comment '포인트풀내역 일련번호'
        primary key,
    point_pool_id      bigint                                   not null comment '포인트풀 아이디',
    pool_status_cd     varchar(32)                              not null comment '포인트풀 상태코드',
    pool_change_total  int                                      null comment '포인트풀 변경금액',
    rec_date           datetime(6) default CURRENT_TIMESTAMP(6) not null comment '등록일자',
    rec_user_id        int                                      null comment '등록자 아이디',
    mod_date           datetime(6) default CURRENT_TIMESTAMP(6) not null on update CURRENT_TIMESTAMP(6) comment '수정일자',
    mod_user_id        int                                      null comment '수정자 아이디',
    constraint tb_point_pool_dtls_tb_point_pool_point_pool_id_fk
        foreign key (point_pool_id) references musicow_point.tb_point_pool (point_pool_id)
)
    comment '포인트예산  변경 로그 테이블';

create table musicow_point.tb_service_oper_log
(
    sys_log_seq bigint auto_increment comment '로그일련번호'
        primary key,
    service_id  bigint        not null comment '서비스아이디',
    mngr_id     varchar(32)   null comment '관리자 아이디',
    log_type_cd varchar(32)   null comment '시스템 로그타입',
    log_ctnts   varchar(1024) null comment '로그내용',
    rec_date    datetime      null comment '등록일자',
    rec_user_id varchar(32)   null comment '등록자아이디',
    mod_date    datetime      null comment '수정일자',
    mod_user_id varchar(32)   null comment '수정자아이디',
    access_ip   varchar(32)   null comment '접속아이피',
    constraint tb_service_oper_log_tb_service_oper_info_service_id_fk
        foreign key (service_id) references musicow_point.tb_service_oper_info (service_id)
)
    comment '시스템운영로그 테이블';

create table musicow_point.tb_stats_daily
(
    service_id      int   null,
    month           int   null,
    day             int   null comment '일자',
    cnt_save        int   null,
    amt_save        float null,
    cnt_use         int   null,
    amt_use         float null,
    cnt_cancel      int   null,
    amt_cancel      float null,
    cnt_recall      int   null,
    amt_recall      float null,
    cnt_transaction float null,
    amt_transaction float null
)
    comment '일별포인트집계';

create table musicow_point.tb_stats_monthly
(
    service_id      int   not null comment '서비스아이디',
    month           int   not null comment '월',
    cnt_save        int   null comment '지급건수',
    amt_save        float null comment '지급액',
    cnt_use         int   null comment '사용건수',
    amt_use         float null comment '사용액',
    cnt_cancel      int   null comment '취소건수',
    amt_cancel      float null comment '취소금액',
    cnt_recall      int   null comment '회수건수',
    amt_recall      float null comment '회수금액',
    cnt_transaction float null comment '정산건수',
    amt_transaction float null comment '정산금액'
)
    comment '월별집계현황';

create table musicow_point.tb_user_point
(
    user_no         bigint                                   not null comment '사용자 번호'
        primary key,
    amt_total_point float       default 0                    not null comment '포인트잔액',
    rec_user_id     varchar(32)                              null,
    mod_user_id     varchar(32)                              null,
    recDate         datetime(6) default CURRENT_TIMESTAMP(6) not null,
    modDate         datetime(6) default CURRENT_TIMESTAMP(6) not null on update CURRENT_TIMESTAMP(6)
)
    comment '사용자포인트테이블';

create table musicow_point.tb_point_event
(
    point_event_seq  bigint auto_increment comment '적립내역 일련번호'
        primary key,
    point_pool_id    bigint                                   not null comment '포인트풀 아이디',
    user_no          bigint                                   not null comment '사용자 번호',
    serial_number    varchar(32)                              not null comment '요청일련번호',
    point_state_cd   varchar(32)                              not null comment '포인트상태코드',
    event_type_cd    varchar(32)                              not null comment '적립타입코드',
    action_type_cd   varchar(32)                              null comment '액션타입코드',
    event_ctnts      varchar(1024)                            not null comment '적립내용',
    amt_event_point  float       default 0                    not null comment '적립 포인트',
    amt_use_point    float       default 0                    null comment '사용포인트',
    amt_remain_point float       default 0                    null comment '잔액포인트',
    exp_date         datetime                                 null comment '포인트 만료일자',
    rec_user_id      varchar(32)                              null comment '등록자 아이디',
    mod_user_id      varchar(32)                              null comment '수정자 아이디',
    rec_date         datetime(6) default CURRENT_TIMESTAMP(6) not null comment '등록일자',
    mod_date         datetime(6) default CURRENT_TIMESTAMP(6) not null on update CURRENT_TIMESTAMP(6) comment '수정일자',
    order_type_cd    varchar(32)                              null comment '주문타입코드',
    order_no         varchar(32)                              null comment '주문번호',
    constraint tb_point_event_pk
        unique (serial_number),
    constraint FK_ae628d9b69f078bcc7169be3a4b
        foreign key (point_pool_id) references musicow_point.tb_point_pool (point_pool_id),
    constraint tb_point_event_tb_user_point_user_no_fk
        foreign key (user_no) references musicow_point.tb_user_point (user_no)
)
    comment '포인트 적립 내역 테이블';

create index tb_point_event_serial_number_index
    on musicow_point.tb_point_event (serial_number);

create index tb_point_event_tb_point_pool_point_pool_id_fk
    on musicow_point.tb_point_event (point_pool_id);

create table musicow_point.tb_point_event_dtls
(
    point_event_dtls_seq      bigint auto_increment
        primary key,
    point_event_seq           bigint                                   not null comment '포인트적립 일련번호',
    save_point_event_dtls_seq bigint      default 0                    not null comment '적립포인트 일련번호',
    serial_number             varchar(32)                              not null comment '요청일련번호',
    user_no                   bigint                                   not null comment '사용자 번호',
    point_state_cd            varchar(32)                              null comment '포인트상태코드 ',
    amt_use_point             float                                    null comment '사용포인트',
    remain_exp_date           datetime                                 null comment '포인트잔액 만료일자',
    rec_date                  datetime(6) default CURRENT_TIMESTAMP(6) not null comment '등록일자',
    mod_date                  datetime(6) default CURRENT_TIMESTAMP(6) not null on update CURRENT_TIMESTAMP(6) comment '수정일자',
    rec_user_id               varchar(32)                              null comment '등록자아이디',
    mod_user_id               varchar(32)                              null comment '수정자아이디',
    constraint tb_point_event_dtls_tb_point_event_point_event_seq_fk
        foreign key (point_event_seq) references musicow_point.tb_point_event (point_event_seq)
)
    comment '포인트 이용내역';

