import { IsArray, IsNotEmpty } from 'class-validator';
import { ApiProperty } from '@nestjs/swagger';
import { ApiModelProperty } from '@nestjs/swagger/dist/decorators/api-model-property.decorator';

export class CancelBatchResponseDto<T> {
  @IsNotEmpty()
  @ApiProperty({
    example: 'true',
    description: '성공여부',
  })
  public success: boolean;

  @IsNotEmpty()
  @ApiProperty({
    example: '0',
    description: '에러코드 ( 0:정상 )',
  })
  public code: number;
  @IsNotEmpty()
  @ApiProperty({
    example: '정상',
    description: '내용',
  })
  public message: string;
  @IsNotEmpty()
  @ApiProperty({
    example: '10',
    description: '총건수',
  })
  public totalCnt: number;
  @IsNotEmpty()
  @ApiProperty({
    example: '10',
    description: '성공건수',
  })
  public sucessCnt: number;
  @IsNotEmpty()
  @ApiProperty({
    example: '0',
    description: '실패건수',
  })
  public failCnt: number;

  @IsArray()
  @ApiProperty({
    isArray: true,
    type: 'array',
    items: { type: 'string', format: 'binary' },
  })
  @ApiModelProperty({
    example: [
      {
        pointEventSeq: '12121',
        userNo: '1',
        eventCtnts: '주문취소사유',
      },
      {
        pointEventSeq: 'REQ2023010130000001',
        userNo: '1',
        eventCtnts: '주문취소사유',
      },
    ],
    description: 'data f.',
    format: 'string',
    required: false,
  })
  failData: any;
}
