import { IsNotEmpty } from 'class-validator';
import { ApiProperty } from '@nestjs/swagger';

export class TransactionReponseDto {
  @IsNotEmpty()
  @ApiProperty({
    example: 'true',
    description: '성공여부',
  })
  public success: boolean;

  @IsNotEmpty()
  @ApiProperty({
    example: '0',
    description: '에러코드 ( 0:정상 )',
  })
  public code: number;
  @IsNotEmpty()
  @ApiProperty({
    example: '정상',
    description: '내용',
  })
  public message: string;

  @IsNotEmpty()
  @ApiProperty({
    example: 'REQ20230130000001',
    description: '요청일련번호 ( 중복허용안함 )',
  })
  public serialNumber: string;

  @IsNotEmpty()
  @ApiProperty({
    example: '1323',
    description: '포인트거래번호',
  })
  public pointEventSeq: string;

  @IsNotEmpty()
  @ApiProperty({
    example: '10000',
    description: '사용취소포인트',
  })
  public amtEventPoint: string;
}
