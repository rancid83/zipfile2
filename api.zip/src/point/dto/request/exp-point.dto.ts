import { IsNotEmpty, IsNumber } from 'class-validator';
import { ApiProperty } from '@nestjs/swagger';

export class ExpPointDto {
  public pointPoolId: number;
  public pointEventSeq: number;
  @IsNotEmpty()
  @ApiProperty({
    example: 'REQ220109000001',
    description: '요청일련번호',
  })
  public serialNumber: string;

  @IsNumber()
  @IsNotEmpty()
  @ApiProperty({
    example: '1',
    description: '사용자 번호',
  })
  public userNo: number;

  @ApiProperty({
    example: 'REWARDS_DRAW,REWARDS_BUY',
    description: '이벤트 타입',
  })
  public eventTypeCd: string;

  @ApiProperty({
    example: 'PLU_CODE',
    description: '주문코드 (상품코드)',
  })
  public orderTypeCd: string;

  public eventCtnts: string;
  @IsNumber()
  @IsNotEmpty()
  @ApiProperty({
    example: '10000',
    description: '사용금액',
  })
  public amtUsePoint: number;
  public pointStateCd: string;
  public orderNo: string;
  public amtRemainPoint: number;
  public expDate: Date;
  public recUserId: string;
  public modUserId: string;
}
