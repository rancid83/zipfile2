import { IsNotEmpty, IsNumber } from 'class-validator';
import { ApiProperty } from '@nestjs/swagger';

export class UserPointSummaryDto {
  @IsNotEmpty()
  @ApiProperty({
    example: '100000',
    description: '포인트',
  })
  public amtTotalPoint: number;

  @IsNumber()
  @IsNotEmpty()
  @ApiProperty({
    example: '1',
    description: '사용자 번호',
  })
  public userNo: number;
}
