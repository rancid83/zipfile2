import { ApiProperty } from '@nestjs/swagger';
import { IsNotEmpty, IsNumber } from 'class-validator';

export class EventDetailPointDto {
  @IsNumber()
  @IsNotEmpty()
  @ApiProperty({
    example: '1',
    description: '포인트풀 아이디',
  })
  public pointPoolId: number;

  @IsNumber()
  @IsNotEmpty()
  @ApiProperty({
    example: '1',
    description: '포인트이벤트 아이디',
  })
  public pointEventSeq: number;

  public usePointEventDtlsSeq: number;

  public savePointEventDtlsSeq: number;

  @IsNotEmpty()
  @ApiProperty({
    example: 'REQ220109000001',
    description: '요청일련번호',
  })
  public serialNumber: string;

  @IsNumber()
  @IsNotEmpty()
  @ApiProperty({
    example: '1',
    description: '사용자 번호',
  })
  public userNo: number;

  @IsNotEmpty()
  @ApiProperty({
    example: '1',
    description: '사용타입타입',
  })
  public pointStateCd: string;

  @IsNumber()
  @IsNotEmpty()
  @ApiProperty({
    example: '10000',
    description: '적립금액',
  })
  public amtUsePoint: number;
  public remainExpDate: string;
  public recUserId: string;
  public modUserId: string;
}
