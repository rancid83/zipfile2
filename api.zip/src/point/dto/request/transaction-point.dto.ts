import { IsNotEmpty, IsNumber } from 'class-validator';
import { ApiProperty } from '@nestjs/swagger';

export class TransactionPointDto {
  @IsNotEmpty()
  @ApiProperty({
    example: 'REQ220109000001',
    description: '포인트사용 요청일련번호',
  })
  public serialNumber: string;
  @IsNotEmpty()
  @ApiProperty({
    example: '123212',
    description: '포인트사용 요청일련번호',
  })
  public pointEventSeq: number;
  @IsNotEmpty()
  @ApiProperty({
    example: '12121',
    description: '거래번호 ( 뮤직카우 거래번호 )',
  })
  public settleId: string;
  @IsNumber()
  @IsNotEmpty()
  @ApiProperty({
    example: '1',
    description: '사용자 번호',
  })
  public userNo: number;
  public amtUsePoint: number;
  public oderTypeCd: string;

  public eventTypeCd: string;

  public recUserId: string;
  public modUserId: string;
}
