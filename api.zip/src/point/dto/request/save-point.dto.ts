import { ApiProperty } from '@nestjs/swagger';
import { IsNotEmpty, IsNumber } from 'class-validator';

export class SavePointDto {
  public pointPoolId: number;

  @IsNotEmpty()
  @ApiProperty({
    example: 'REQ220109000001',
    description: '요청일련번호',
  })
  public serialNumber: string;

  @IsNumber()
  @IsNotEmpty()
  @ApiProperty({
    example: '1',
    description: '사용자 번호',
  })
  public userNo: number;

  @IsNotEmpty()
  @ApiProperty({
    example: 'DAILY',
    description: '이벤트코드(공통코드정의)',
  })
  public eventTypeCd: string;
  @IsNotEmpty()
  @ApiProperty({
    example: 'NORMAL',
    description: '액션타입(공통코드정의 ex>signup/signin, attendance...)',
  })
  public actionTypeCd: string;

  public orderTypeCd: string;
  public pointStateCd: string;
  public pointEventSeq: number;
  public orderNo: string;
  public eventCtnts: string;
  public amtEventPoint: number;
  public amtEventBasicPoint: number;
  public amtUsePoint: number;
  public amtRemainPoint: number;
  public expDate: string;
  public recUserId: string;
  public modUserId: string;
  public regdate: string;
  public skip: number;
  public take: number;
}
