export class CreateUserDto {
  public userNo: number;
  public amtTotalPoint: number;
  public recUserId: string;
  public modUserId: string;
}
