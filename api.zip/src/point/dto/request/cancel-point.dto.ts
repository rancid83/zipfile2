import { IsNotEmpty, IsNumber } from 'class-validator';
import { ApiProperty } from '@nestjs/swagger';

export class CancelPointDto {
  @IsNumber()
  @IsNotEmpty()
  @ApiProperty({
    example: '1',
    description: '사용자 번호',
  })
  public userNo: number;
  @IsNotEmpty()
  @ApiProperty({
    example: 'REQ220109000001',
    description: '포인트사용 요청일련번호',
  })
  public serialNumber: string;
  @IsNotEmpty()
  @ApiProperty({
    example: '12334',
    description: '포인트이벤트 일련번호',
  })
  public pointEventSeq: number;

  public amtCancelPoint: number;
  public eventCtnts: string;

  public eventTypeCd: string;

  public recUserId: string;
  public modUserId: string;
  public isBatch: boolean;
}
