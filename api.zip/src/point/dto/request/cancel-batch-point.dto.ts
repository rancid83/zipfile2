import { IsArray } from 'class-validator';
import { ApiProperty } from '@nestjs/swagger';
import { ApiModelProperty } from '@nestjs/swagger/dist/decorators/api-model-property.decorator';

export class CancelBatchPointDto<T> {
  @IsArray()
  @ApiProperty({
    isArray: true,
    type: 'array',
    items: { type: 'string', format: 'binary' },
  })
  @ApiModelProperty({
    example: [
      {
        pointEventSeq: '1212',
        userNo: '1',
        eventCtnts: '주문취소사유',
      },
      {
        pointEventSeq: '1213',
        userNo: '1',
        eventCtnts: '주문취소사유',
      },
    ],
    description: 'data f.',
    format: 'string',
    required: false,
  })
  data: T[];
  failData: T[];
}
