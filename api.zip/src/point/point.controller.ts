import {
  Body,
  Controller,
  ForbiddenException,
  Get,
  Param,
  Post,
  UseGuards,
} from '@nestjs/common';
import { PointService } from './service/point.service';
import { PointUseService } from './service/point.use.service';
import { PointSaveService } from './service/point.save.service';
import { PointCancelService } from './service/point.cancel.service';
import { PointRecallService } from './service/point.recall.service';
import { PointSettleService } from './service/point.settle.service';
import { PointEventService } from './service/point.event.service';
import {
  ApiExtraModels,
  ApiOperation,
  ApiResponse,
  getSchemaPath,
} from '@nestjs/swagger';
import { JwtAuthGuard } from '../auth/jwt-auth.guard';
import { TbPointEvent } from '../entities/TbPointEvent';
import { UsePointDto } from './dto/request/use-point.dto';
import { CancelPointDto } from './dto/request/cancel-point.dto';
import { RecallPointDto } from './dto/request/recall-point.dto';
import { PageOptionsDto } from '../common/paging/dto/page-optons.dto';
import { TransactionPointDto } from './dto/request/transaction-point.dto';
import { CancelBatchPointDto } from './dto/request/cancel-batch-point.dto';
import { UserPointSummaryDto } from './dto/request/user-point-summary.dto';
import { SavePointDto } from './dto/request/save-point.dto';
import { PagingDto } from '../common/paging/dto/paging.dto';
import { CancelResponseDto } from './dto/response/cancel.response.dto';
import { TransactionReponseDto } from './dto/response/transaction.response.dto';
import { CancelBatchResponseDto } from './dto/response/cancel-batch.response.dto';
import { SaveResponseDto } from './dto/response/save.response.dto';
import { UseResponseDto } from './dto/response/use.response.dto';
import { RecallResponseDto } from './dto/response/recall.response.dto';
import { ExpPointDto } from './dto/request/exp-point.dto';

@Controller(['point','//point'])
export class PointController {
  constructor(
    private readonly pointService: PointService,
    private readonly pointUseService: PointUseService,
    private readonly pointSaveService: PointSaveService,
    private readonly pointCancelService: PointCancelService,
    private readonly pointRecallService: PointRecallService,
    private readonly pointSettleService: PointSettleService,
    private readonly pointEventService: PointEventService,
  ) {}

  /**
   * 사용자 포인트 잔액 조회 [ IF-POINT_04 ]
   * @param UsePointDto - 이벤트 포인트 잔액 조회를 위한 정보 DTO
   * @return boolean 취소 처리 여부
   * @see ""
   */
  @ApiExtraModels(UserPointSummaryDto)
  @ApiResponse({
    status: 200,
    description: '성공',
    schema: {
      $ref: getSchemaPath(UserPointSummaryDto),
    },
  })
  @ApiResponse({
    status: 500,
    description: '서버 에러',
  })
  @ApiResponse({
    status: 401,
    description: '인증실패',
  })
  @ApiOperation({ summary: '포인트 잔액 조회 [ IF-POINT_04 ]' })
  @UseGuards(JwtAuthGuard)
  @Get(['/user/:userNo'])
  async getUserPoint(@Param('userNo') userNo: number) {
    const userPoint = await this.pointService.getUserPoint(userNo);
    let amtTotalPoint = 0 ;
    if( userPoint && userPoint.amtTotalPoint > 0) {
      amtTotalPoint = userPoint.amtTotalPoint;
    }
    return {
      userNo: userNo,
      amtTotalPoint: userPoint ? amtTotalPoint : 0,
    };
  }

  /**
   * 사용자 포인트 내역 조회 [IF-POINT_05]
   * @param UsePointDto - 이벤트 포인트 조회를 위한 정보 DTO
   * @return boolean 취소 처리 여부
   * @see ""
   */
  @ApiExtraModels(PagingDto)
  @ApiResponse({
    status: 200,
    description: '성공',
    schema: {
      $ref: getSchemaPath(PagingDto),
    },
  })
  @ApiResponse({
    status: 500,
    description: '서버 에러',
  })
  @ApiOperation({ summary: '포인트 내역 조회 [ IF-POINT_05 ]' })
  @UseGuards(JwtAuthGuard)
  @Post('/user/detail/:userNo')
  async getUserPointList(
    @Param('userNo') userNo: number,
    @Body() pageOptionsDto: PageOptionsDto,
  ) {
    const userPointList = await this.pointService.getUserPointList(
      userNo,
      pageOptionsDto,
    );
    return userPointList;
  }

  /**
   * 사용자 포인트 이벤트 내역 조회 _ 출석체크 [IF-POINT_05_1]
   * @param UsePointDto - 이벤트 포인트 조회를 위한 정보 DTO
   * @return boolean 취소 처리 여부
   * @see ""
   */
  @ApiExtraModels(PagingDto)
  @ApiResponse({
    status: 200,
    description: '성공',
    schema: {
      $ref: getSchemaPath(PagingDto),
    },
  })
  @ApiResponse({
    status: 500,
    description: '서버 에러',
  })
  @ApiOperation({ summary: '포인트 내역 조회 _ 출석체크 [ IF-POINT_05_1 ]' })
  @UseGuards(JwtAuthGuard)
  @Post('/user/detail/daily/:userNo')
  async getUserPointDailyList(
    @Param('userNo') userNo: number,
    @Body() pageOptionsDto: PageOptionsDto,
  ) {
    const userPointEventList = await this.pointService.getUserPointDailyList(
      userNo,
      pageOptionsDto,
    );
    return userPointEventList;
  }

  /**
   * 사용자 포인트 적립 [ IF-POINT_06 ]
   * @param UsePointDto - 이벤트 포인트 적립을 위한 정보 DTO
   * @return boolean 적립 처리 여부
   * @see ""
   */
  @ApiExtraModels(SaveResponseDto)
  @ApiResponse({
    status: 200,
    description: '성공',
    schema: {
      $ref: getSchemaPath(SaveResponseDto),
    },
  })
  @ApiResponse({
    status: 500,
    description: '서버 에러',
  })
  @ApiOperation({ summary: '포인트 적립 [ IF-POINT_06 ]' })
  @UseGuards(JwtAuthGuard)
  @Post('/save')
  async savePoint(@Body() savePointDto: SavePointDto) {
    const result = await this.pointSaveService.savePoint(savePointDto);
    if (result) {
      return {
        success: true,
        code: '0',
        message: 'success',
        serialNumber: savePointDto.serialNumber,
        pointEventSeq: result.pointEventSeq,
        amtSavePoint: result.amtUsePoint,
        expDate: result.remainExpDate,
        eventTypeCd: savePointDto.eventTypeCd,
        actionTypeCd: savePointDto.actionTypeCd,
      };
    } else {
      throw new ForbiddenException();
    }
  }

  /**
   * 사용자 포인트 이벤트 적립 _ 출석체크 [ IF-POINT_06_1 ]
   * @param UsePointDto - 이벤트 포인트 적립을 위한 정보 DTO
   * @return boolean 적립 처리 여부
   * @see ""
   */
  @ApiExtraModels(SaveResponseDto)
  @ApiResponse({
    status: 200,
    description: '성공',
    schema: {
      $ref: getSchemaPath(SaveResponseDto),
    },
  })
  @ApiResponse({
    status: 500,
    description: '서버 에러',
  })
  @ApiOperation({ summary: '포인트 적립 _ 출석체크 [ IF-POINT_06_1 ]' })
  @UseGuards(JwtAuthGuard)
  @Post('/save/daily')
  async saveDailyPoint(@Body() savePointDto: SavePointDto) {
    const result = await this.pointSaveService.saveDailyPoint(savePointDto);
    if (result) {
      return {
        success: true,
        code: '0',
        message: 'success',
        serialNumber: savePointDto.serialNumber,
        pointEventSeq: result.pointEventSeq,
        amtSavePoint: result.amtUsePoint,
        expDate: result.remainExpDate,
        eventTypeCd: savePointDto.eventTypeCd,
        actionTypeCd: savePointDto.actionTypeCd,
      };
    } else {
      throw new ForbiddenException();
    }
  }

  /**
   * 사용자 포인트 사용 [ IF-POINT_07 ]
   * @param UsePointDto - 이벤트 포인트 사용을 위한 정보 DTO
   * @return boolean 사용 처리 여부
   * @see ""
   */
  @ApiExtraModels(UseResponseDto)
  @ApiResponse({
    status: 200,
    description: '성공',
    schema: {
      $ref: getSchemaPath(UseResponseDto),
    },
  })
  @ApiResponse({
    status: 500,
    description: '서버 에러',
  })
  @ApiOperation({ summary: '포인트 사용 [ IF-POINT_07 ]' })
  @UseGuards(JwtAuthGuard)
  @Post('/use')
  async usePoint(@Body() usePointDto: UsePointDto) {
    const result = await this.pointUseService.usePoint(usePointDto);
    if (result) {
      return {
        success: true,
        code: '0',
        message: 'success',
        serialNumber: usePointDto.serialNumber,
        pointEventSeq: result.pointEventSeq,
        amtUsePoint: result.amtUsePoint,
      };
    } else {
      throw new ForbiddenException();
    }
  }

  /**
   * 사용자 포인트 만료 [ IF-POINT_07_1 ]
   * @param UsePointDto - 이벤트 포인트 만료을 위한 정보 DTO
   * @return boolean 만료 처리 여부
   * @see ""
   */
  @ApiExtraModels(UseResponseDto)
  @ApiResponse({
    status: 200,
    description: '성공',
    schema: {
      $ref: getSchemaPath(UseResponseDto),
    },
  })
  @ApiResponse({
    status: 500,
    description: '서버 에러',
  })
  @ApiOperation({ summary: '포인트 만료 [ IF-POINT_07_1 ]' })
  @UseGuards(JwtAuthGuard)
  @Post('/exp')
  async expPoint(@Body() expPointDto: ExpPointDto) {
    const result = await this.pointUseService.expPoint(expPointDto);
    if (result) {
      return {
        success: true,
        code: '0',
        message: 'success',
        serialNumber: expPointDto.serialNumber,
        pointEventSeq: result.pointEventSeq,
        amtUsePoint: result.amtUsePoint,
      };
    } else {
      throw new ForbiddenException();
    }
  }

  /**
   * 사용자 포인트 취소 [ IF-POINT_08 ]
   * @param UsePointDto - 이벤트 포인트 취소를 위한 정보 DTO
   * @return boolean 취소 처리 여부
   * @see ""
   */
  @ApiExtraModels(CancelResponseDto)
  @ApiResponse({
    status: 200,
    description: '성공',
    schema: {
      $ref: getSchemaPath(CancelResponseDto),
    },
  })
  @ApiResponse({
    status: 500,
    description: '서버 에러',
  })
  @ApiOperation({ summary: '포인트 취소 [ IF-POINT_08 ]' })
  @UseGuards(JwtAuthGuard)
  @Post('/cancel')
  async cancelPoint(@Body() cancelPointDto: CancelPointDto) {
    const result = await this.pointCancelService.cancelPoint(cancelPointDto);
    if (result) {
      return {
        success: true,
        code: '0',
        message: 'success',
        serialNumber: cancelPointDto.serialNumber,
        pointEventSeq: result.pointEventSeq,
      };
    } else {
      throw new ForbiddenException();
    }
  }

  /**
   * 사용자 포인트 회수 [ IF-POINT_09 ]
   * @param UsePointDto - 이벤트 포인트 회수를 위한 정보 DTO
   * @return boolean 회수 처리 여부
   * @see ""
   */
  @ApiExtraModels(RecallResponseDto)
  @ApiResponse({
    status: 200,
    description: '성공',
    schema: {
      $ref: getSchemaPath(RecallResponseDto),
    },
  })
  @ApiResponse({
    status: 500,
    description: '서버 에러',
  })
  @ApiOperation({ summary: '포인트 회수 [ IF-POINT_09 ]' })
  @UseGuards(JwtAuthGuard)
  @Post('/recall')
  async recallPoint(@Body() recallPointDto: RecallPointDto) {
    const result = await this.pointRecallService.recallPoint(recallPointDto);
    if (result) {
      return {
        success: true,
        code: '0',
        message: 'success',
        serialNumber: recallPointDto.serialNumber,
        pointEventSeq: result.pointEventSeq,
        amtEventPoint: result.amtEventPoint,
      };
    } else {
      throw new ForbiddenException();
    }
  }

  /**
   * 사용자 포인트 정산 [ IF-POINT_10 ]
   * @param TransactionPointDto - 이벤트 포인트 정산을 위한 정보 DTO
   * @return boolean 정산 처리 여부
   * @see ""
   */
  @ApiExtraModels(TransactionReponseDto)
  @ApiResponse({
    status: 200,
    description: '성공',
    schema: {
      $ref: getSchemaPath(TransactionReponseDto),
    },
  })
  @ApiResponse({
    status: 500,
    description: '서버 에러',
  })
  @ApiOperation({ summary: '포인트 정산 [ IF-POINT_10 ]' })
  @UseGuards(JwtAuthGuard)
  @Post('/settle')
  async transactionPoint(@Body() transactionPointDto: TransactionPointDto) {
    const result = await this.pointSettleService.settlePoint(
      transactionPointDto,
    );
    if (result) {
      return {
        success: true,
        code: '0',
        message: 'success',
        serialNumber: transactionPointDto.serialNumber,
        pointEventSeq: result.pointEventSeq,
        amtUsePoint: transactionPointDto.amtUsePoint,
      };
    } else {
      throw new ForbiddenException();
    }
  }

  /**
   * 주문미결로 인한 사용자 포인트 일괄취소 ( 일별 ) [ IF-POINT_11 ]
   * @param UsePointDto - 이벤트 포인트 일괄취소 을 위한 정보 DTO
   * @return boolean 일괄취소 처리 여부
   * @see ""
   */
  @ApiExtraModels(CancelBatchResponseDto)
  @ApiResponse({
    status: 200,
    description: '성공',
    schema: {
      $ref: getSchemaPath(CancelBatchResponseDto),
    },
  })
  @ApiResponse({
    status: 500,
    description: '서버 에러',
  })
  @ApiOperation({ summary: '포인트 일괄취소 [ IF-POINT_11 ] ' })
  @UseGuards(JwtAuthGuard)
  @Post('/cancel/batch')
  async cancelBatchPoint(
    @Body() cancelBatchPointDto: CancelBatchPointDto<TbPointEvent>,
  ) {
    console.log(cancelBatchPointDto.data);
    const result = await this.pointCancelService.cancelBatchPoint(
      cancelBatchPointDto,
    );
    if (result) {
      return {
        success: true,
        code: '0',
        message: 'success',
        result,
      };
    } else {
      throw new ForbiddenException();
    }
  }
}
