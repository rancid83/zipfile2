import {
  ForbiddenException,
  Injectable,
  NotFoundException,
} from '@nestjs/common';
import { TbPointEvent } from '../../entities/TbPointEvent';
import { DataSource, Repository } from 'typeorm';
import { InjectRepository } from '@nestjs/typeorm';
import { TbPointPool } from '../../entities/TbPointPool';
import { TbServiceOperInfo } from '../../entities/TbServiceOperInfo';
import { TbServiceOperLog } from '../../entities/TbServiceOperLog';
import { TbPointEventDtls } from '../../entities/TbPointEventDtls';
import { TbUserPoint } from '../../entities/TbUserPoint';
import { TbPointCheck } from '../../entities/TbPointCheck';
import { CreateUserDto } from './../dto/request/create-user.dto';
import { EventDetailPointDto } from './../dto/request/event-detail-point.dto';
import { SavePointDto } from '../dto/request/save-point.dto';
import {
  LocalDate,
  LocalDateTime,
  TemporalAdjusters,
} from 'js-joda';
import { TbPointPoolSchedule } from "../../entities/TbPointPoolSchedule";

@Injectable()
export class PointSaveService {
  constructor(
    @InjectRepository(TbPointEvent)
    private pointEventRepository: Repository<TbPointEvent>,
    @InjectRepository(TbPointPool)
    private pointPoolRepository: Repository<TbPointPool>,
    @InjectRepository(TbServiceOperInfo)
    private serviceOperInfoRepository: Repository<TbServiceOperInfo>,
    @InjectRepository(TbServiceOperLog)
    private serviceOperLogRepository: Repository<TbServiceOperLog>,
    @InjectRepository(TbPointEventDtls)
    private pointEventDtlsRepository: Repository<TbPointEventDtls>,
    @InjectRepository(TbUserPoint)
    private userPointRepository: Repository<TbUserPoint>,
    @InjectRepository(TbPointCheck)
    private pointCheckRepository: Repository<TbPointCheck>,
    private dataSource: DataSource,
  ) {}

  /**
   * 사용자 포인트 적립
   * @param eventPointDto - 이벤트 포인트 지급 정보 DTO
   * @return boolean 지급처리 여부
   * @see ""
   */
  async savePoint(savePointDto: SavePointDto): Promise<EventDetailPointDto> {
    // 요청일련번호 포인트풀 사용 내역조회
    const event = await this.pointEventRepository.findOne({
      where: { serialNumber: savePointDto.serialNumber },
    });
    if (event) {
      throw new ForbiddenException({
        message: '요청일련번호 중복 에러',
      });
    }
    //포인트풀 조회
    const pool = await this.pointPoolRepository
      .createQueryBuilder('pool')
      .where(' now() BETWEEN startdate AND  enddate ')
      .andWhere(' pool.event_type_cd = :eventTypeCd ', {
        eventTypeCd: savePointDto.eventTypeCd,
      })
      .getOne();

    if (!pool) {
      throw new NotFoundException(`Can't find pointPoolId `);
    }
    // 풀잔여액 , 사용기간 체크
    console.log(pool);
    if (pool.useYn != 'Y') {
      throw new ForbiddenException(`포인트풀이 사용상태가 아닙니다.`);
    }
    if (pool.amtRemain < savePointDto.amtEventPoint) {
      throw new ForbiddenException(
        `포인트풀 잔여금액 부족으로 적립할 수 없습니다.`,
      );
    }
    savePointDto.pointPoolId = pool.pointPoolId;
    savePointDto.eventCtnts = `포인트 적립 `;

    const now = LocalDateTime.now();
    const expDate = now.plusDays(pool.validityDays || 180);
    savePointDto.expDate = expDate.toString();

    const queryRunner = this.dataSource.createQueryRunner();
    await queryRunner.connect();
    await queryRunner.startTransaction();
    // 트랜잭션 START
    try {
      const createUserDto = new CreateUserDto();
      // 사용자조회
      const user = await queryRunner.manager
        .getRepository(TbUserPoint)
        .findOne({ where: { userNo: savePointDto.userNo } });
      if (!user) {
        //신규유저 저장

        createUserDto.userNo = savePointDto.userNo;
        createUserDto.amtTotalPoint = 0;
        createUserDto.recUserId = process.env.SYSTEM_NAME || 'system';
        createUserDto.modUserId = process.env.SYSTEM_NAME || 'system';
        await queryRunner.manager
          .getRepository(TbUserPoint)
          .save(createUserDto);
      } else {
        createUserDto.amtTotalPoint = user.amtTotalPoint;
      }

      // ADMIN SAVE
      if (!savePointDto.amtEventPoint) {
        savePointDto.amtEventPoint = pool.amtSave;
      }

      savePointDto.pointStateCd = 'SAVE';
      savePointDto.recUserId = process.env.SYSTEM_NAME || 'system';
      savePointDto.modUserId = process.env.SYSTEM_NAME || 'system';
      // 적립 포인트 이벤트 인서트
      const returned = await queryRunner.manager
        .getRepository(TbPointEvent)
        .save(savePointDto);
      console.log(returned);

      // 적립 포인트 이벤트 상세 인서트
      const eventDetailPointDto = new EventDetailPointDto();
      eventDetailPointDto.pointStateCd = 'SAVE'; //적립
      eventDetailPointDto.pointEventSeq = returned.pointEventSeq;
      eventDetailPointDto.savePointEventDtlsSeq = 0;
      eventDetailPointDto.serialNumber = returned.serialNumber;
      eventDetailPointDto.userNo = returned.userNo;
      eventDetailPointDto.amtUsePoint = savePointDto.amtEventPoint;
      eventDetailPointDto.remainExpDate = returned.expDate;
      eventDetailPointDto.recUserId = process.env.SYSTEM_NAME || 'system';
      eventDetailPointDto.modUserId = process.env.SYSTEM_NAME || 'system';
      const eventDetail = await queryRunner.manager
        .getRepository(TbPointEventDtls)
        .save(eventDetailPointDto);

      eventDetail.savePointEventDtlsSeq = eventDetail.pointEventDtlsSeq;
      eventDetail.remainExpDate = returned.expDate;
      eventDetail.amtUsePoint = returned.amtEventPoint;
      await queryRunner.manager
        .getRepository(TbPointEventDtls)
        .update(eventDetail.pointEventDtlsSeq, eventDetail);

      // 정상처리
      await queryRunner.commitTransaction();
      return eventDetail;
    } catch (error) {
      console.error(error);
      await queryRunner.rollbackTransaction();
      throw error;
    } finally {
      // 사용자 포인트 업데이트
      const queryBuilder = this.dataSource
        .getRepository(TbPointEventDtls)
        .createQueryBuilder('eventDtls');

      const sum = await queryBuilder
        .where('eventDtls.user_no = :userNo', { userNo: savePointDto.userNo })
        .select('SUM(eventDtls.amt_use_point)', 'totalPoint')
        .getRawOne();

      console.log(sum);

      const updateUserDto = new CreateUserDto();
      updateUserDto.userNo = savePointDto.userNo;
      updateUserDto.modUserId = process.env.SYSTEM_NAME || 'system';
      updateUserDto.amtTotalPoint = sum.totalPoint;
      await queryRunner.manager
        .getRepository(TbUserPoint)
        .update(updateUserDto.userNo, updateUserDto);

      await queryRunner.release();
    }
  }

  /**
   * 사용자 출석체크 포인트 적립
   * @param eventPointDto - 이벤트 포인트 지급 정보 DTO
   * @return boolean 지급처리 여부
   * @see ""
   */
  async saveDailyPoint(
    savePointDto: SavePointDto,
  ): Promise<EventDetailPointDto> {
    // 요청일련번호 포인트풀 사용 내역조회
    const event = await this.pointEventRepository.findOne({
      where: { serialNumber: savePointDto.serialNumber },
    });
    if (event) {
      throw new ForbiddenException({
        message: '요청일련번호 중복 에러',
      });
    }

    const queryBuilderPool = this.dataSource
      .getRepository(TbPointPool)
      .createQueryBuilder('pool');
    var pool = await queryBuilderPool
      .where(' now() between pool.startdate and pool.enddate ')
      .andWhere(`pool.event_type_cd = :eventType `, { eventType:savePointDto.eventTypeCd })
      .andWhere(`pool.use_yn = 'Y' `)
      .getOne();

    if (!pool) {
      // 출석체크는 지급이 불가시 VOC 발생하기 때문에 예비풀을 활용
      const pool_ex = await this.pointPoolRepository.findOne({
        where: {
          eventType: savePointDto.eventTypeCd,
        },
      });
      pool = pool_ex;
    }
    if (pool.useYn != 'Y') {
      throw new ForbiddenException(`포인트풀이 사용상태가 아닙니다.`);
    }
    console.log(pool);

    const queryBuilder = this.dataSource
      .getRepository(TbPointEvent)
      .createQueryBuilder('event');
    await queryBuilder
      .where('event.user_no = :userNo', { userNo: savePointDto.userNo })
      .andWhere(
        'event.rec_date > DATE_SUB(CURDATE(), INTERVAL :interval DAY) ',
        {
          interval: 0,
        },
      )
      .andWhere(`event.point_state_cd = 'SAVE' `)
      .getMany();
    const itemCount = await queryBuilder.getCount();
    console.log('itemCount', itemCount);
    if (itemCount > 0) {
      throw new ForbiddenException(`이미 지급되었습니다.`);
    }

    savePointDto.pointPoolId = pool.pointPoolId;
    savePointDto.eventCtnts = `출석체크 적립`;
    savePointDto.amtEventBasicPoint = pool.amtSave;

    // 적립금액 amtSave => ( NORMAL, X2 , X3 , D+15, D+END ) 계산 - savePointDto.actionTypeCd 참조
    const min = pool.amtSaveMin;
    const max = pool.amtSaveMax;
    if (savePointDto.eventTypeCd == 'DAILY') {
      // event Date 현재달 출석체크 조회
      const queryBuilderSchedule = this.dataSource
        .getRepository(TbPointPoolSchedule)
        .createQueryBuilder('schedule');
      const d = LocalDate.parse(LocalDate.now().toString());
      const start = d.with(TemporalAdjusters.firstDayOfMonth()).toString();
      const end = d.with(TemporalAdjusters.lastDayOfMonth()).toString();
      const today = LocalDateTime.now().toString().substring(0,10);
      console.log(today);
      await queryBuilderSchedule
        .select('schedule.event_schedule_id', 'scheduleId')
        .addSelect('schedule.schedule_name', 'scheduleName')
        .addSelect('schedule.schedule_date', 'scheduleDate')
        .addSelect('schedule.action_type_cd', 'actionTypeCd')
        .addSelect('schedule.amt_save_option', 'amtSaveOption')
        .where('schedule.schedule_date = :today ', {
          today: today,
        })
        .andWhere(` schedule.use_yn = 'Y' `)
        .andWhere(` schedule.action_type_cd = :actionTypeCd `, {
          actionTypeCd: savePointDto.actionTypeCd
        })
        .getOne();

        const scheduleData = await queryBuilderSchedule.getRawOne();
        console.log("scheduleData");
        console.log(scheduleData);

        // 기본 : 랜덤포인트지급
        pool.amtSave = Math.floor(Math.random() * (max - min) + min);
        console.log('pool.amtSave RANDOM:', pool.amtSave);

        // 이벤트포인트
        let amtSaveOption = 0;
        if(scheduleData){
          // TODO 4/4 이벤트스케줄 포인트 옵션 체크
          // amtSaveOption = scheduleData.amtSaveOption || 1;
          // if (savePointDto.actionTypeCd.substring(0,1) == 'X') {
          //   pool.amtSave = pool.amtSave * amtSaveOption;
          // }
          if (savePointDto.actionTypeCd == 'X2') {
            pool.amtSave = pool.amtSave * 2;
          }
          if (savePointDto.actionTypeCd == 'X3') {
            pool.amtSave = pool.amtSave * 3;
          }
          if (
            savePointDto.actionTypeCd == 'D+15' ||
            savePointDto.actionTypeCd == 'D+END'
          ) {
            // TODO 15일 연속인지 여부 체크
            // event Date 현재달 출석체크 조회
            const queryBuilderEvent = this.dataSource
              .getRepository(TbPointCheck)
              .createQueryBuilder('events');
            const d = LocalDate.parse(LocalDate.now().toString());
            const startdate = d
              .with(TemporalAdjusters.firstDayOfMonth())
              .toString();
            const enddate = d.with(TemporalAdjusters.lastDayOfMonth()).toString();
            await queryBuilderEvent
              .select('events.user_no', 'userNo')
              .where('events.regdate between :startdate and :enddate', {
                startdate: startdate,
                enddate: enddate,
              })
              .andWhere(`events.event_type_cd = 'DAILY' `)
              .andWhere('events.user_no = :userNo', {
                userNo: savePointDto.userNo,
              })
              .getMany();

            const itemCount = await queryBuilderEvent.getCount();
            console.log('itemCount:', itemCount);
            //추가포인트 지급
            if (savePointDto.actionTypeCd == 'D+15' && itemCount == 14) {
              pool.amtSave = pool.amtSave + 300; //TODO 4/4이후적용 +amtSaveOption
            }
            // TODO 말일 -1
            const d2 = LocalDate.parse(LocalDate.now().toString());
            const lengOfMonth =
              d2.with(TemporalAdjusters.lastDayOfMonth()).lengthOfMonth() - 1;
            console.log('lengOfMonth', lengOfMonth);
            if (
              savePointDto.actionTypeCd == 'D+END' &&
              itemCount == lengOfMonth
            ) {
              pool.amtSave = pool.amtSave +500; //TODO 4/4이후적용 +amtSaveOption
            }
          }
        }

          console.log(
            `pool.amtSave action ${savePointDto.actionTypeCd} : `,
            pool.amtSave,
          );
    }
    savePointDto.amtEventPoint = pool.amtSave;

    const now = LocalDateTime.now().plusHours(9);
    console.log("now:",now.toString());
    const expDate = now.plusDays(pool.validityDays || 180);
    savePointDto.expDate = expDate.toString();
    console.log('expDate', expDate.toString());
    // 잔여금액 조회
    if (pool.amtRemain < savePointDto.amtEventPoint) {
      throw new ForbiddenException(
        `포인트풀 잔여금액 부족으로 적립할 수 없습니다.`,
      );
    }

    const queryRunner = this.dataSource.createQueryRunner();
    await queryRunner.connect();
    await queryRunner.startTransaction();
    // 트랜잭션 START
    try {
      // point 추가
      // pointCheckRepository
      const checkdate = LocalDateTime.now().toString();
      console.log("checkdate:",checkdate.toString());
      savePointDto.regdate = checkdate.toString().substring(0,10);
      const pointCheckRes = await queryRunner.manager
        .getRepository(TbPointCheck)
        .insert(savePointDto);
      console.log("pointCheckRes",pointCheckRes);

      const createUserDto = new CreateUserDto();
      // 사용자조회
      const user = await queryRunner.manager
        .getRepository(TbUserPoint)
        .findOne({ where: { userNo: savePointDto.userNo } });
      if (!user) {
        //신규유저 저장
        createUserDto.userNo = savePointDto.userNo;
        createUserDto.amtTotalPoint = 0;
        createUserDto.recUserId = process.env.SYSTEM_NAME || 'system';
        createUserDto.modUserId = process.env.SYSTEM_NAME || 'system';
        await queryRunner.manager
          .getRepository(TbUserPoint)
          .upsert(createUserDto, ['userNo']);
      } else {
        createUserDto.amtTotalPoint = user.amtTotalPoint;
      }

      savePointDto.pointStateCd = 'SAVE';
      savePointDto.recUserId = process.env.SYSTEM_NAME || 'system';
      savePointDto.modUserId = process.env.SYSTEM_NAME || 'system';
      // 적립 포인트 이벤트 인서트
      const returned = await queryRunner.manager
        .getRepository(TbPointEvent)
        .save(savePointDto);

      // 적립 포인트 이벤트 상세 인서트
      const eventDetailPointDto = new EventDetailPointDto();
      eventDetailPointDto.pointStateCd = 'SAVE'; //적립
      eventDetailPointDto.pointEventSeq = returned.pointEventSeq;
      eventDetailPointDto.savePointEventDtlsSeq = 0;
      eventDetailPointDto.serialNumber = returned.serialNumber;
      eventDetailPointDto.userNo = returned.userNo;
      eventDetailPointDto.amtUsePoint = returned.amtEventPoint;
      eventDetailPointDto.remainExpDate = savePointDto.expDate;
      eventDetailPointDto.recUserId = process.env.SYSTEM_NAME || 'system';
      eventDetailPointDto.modUserId = process.env.SYSTEM_NAME || 'system';
      const eventDetail = await queryRunner.manager
        .getRepository(TbPointEventDtls)
        .save(eventDetailPointDto);

      eventDetail.savePointEventDtlsSeq = eventDetail.pointEventDtlsSeq;
      eventDetail.remainExpDate = returned.expDate;
      eventDetail.amtUsePoint = returned.amtEventPoint;
      await queryRunner.manager
        .getRepository(TbPointEventDtls)
        .update(eventDetail.pointEventDtlsSeq, eventDetail);

      // 정상처리
      await queryRunner.commitTransaction();
      return eventDetail;
    } catch (error) {
      console.error(error);
      await queryRunner.rollbackTransaction();
      //throw error;
      throw new ForbiddenException(
        `이미 지급되었습니다`,
      );
    } finally {
      // 사용자 포인트 업데이트
      const queryBuilder = this.dataSource
        .getRepository(TbPointEventDtls)
        .createQueryBuilder('eventDtls');

      const sum = await queryBuilder
        .where('eventDtls.user_no = :userNo', { userNo: savePointDto.userNo })
        .select('SUM(eventDtls.amt_use_point)', 'totalPoint')
        .getRawOne();

      const updateUserDto = new CreateUserDto();
      updateUserDto.userNo = savePointDto.userNo;
      updateUserDto.modUserId = process.env.SYSTEM_NAME || 'system';
      updateUserDto.amtTotalPoint = sum.totalPoint;
      await queryRunner.manager
        .getRepository(TbUserPoint)
        .update(updateUserDto.userNo, updateUserDto);

      await queryRunner.release();
    }
  }
}
