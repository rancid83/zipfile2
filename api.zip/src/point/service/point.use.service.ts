import {
  ForbiddenException,
  Injectable,
  NotFoundException,
} from '@nestjs/common';
import { TbPointEvent } from '../../entities/TbPointEvent';
import { DataSource, Repository } from 'typeorm';
import { InjectRepository } from '@nestjs/typeorm';
import { TbPointPool } from '../../entities/TbPointPool';
import { TbServiceOperInfo } from '../../entities/TbServiceOperInfo';
import { TbServiceOperLog } from '../../entities/TbServiceOperLog';
import { TbPointEventDtls } from '../../entities/TbPointEventDtls';
import { TbUserPoint } from '../../entities/TbUserPoint';
import { CreateUserDto } from './../dto/request/create-user.dto';
import { UsePointDto } from './../dto/request/use-point.dto';
import { ExpPointDto } from '../dto/request/exp-point.dto';

@Injectable()
export class PointUseService {
  private isUser: boolean | true;
  constructor(
    @InjectRepository(TbPointEvent)
    private pointEventRepository: Repository<TbPointEvent>,
    @InjectRepository(TbPointPool)
    private pointPoolRepository: Repository<TbPointPool>,
    @InjectRepository(TbServiceOperInfo)
    private serviceOperInfoRepository: Repository<TbServiceOperInfo>,
    @InjectRepository(TbServiceOperLog)
    private serviceOperLogRepository: Repository<TbServiceOperLog>,
    @InjectRepository(TbPointEventDtls)
    private pointEventDtlsRepository: Repository<TbPointEventDtls>,
    @InjectRepository(TbUserPoint)
    private userPointRepository: Repository<TbUserPoint>,
    private dataSource: DataSource,
  ) {}

  /**
   * 사용자 포인트 사용
   * @param UsePointDto - 이벤트 포인트 사용 정보 DTO
   * @return boolean 사용처리 여부
   * @see ""
   */
  async usePoint(usePointDto: UsePointDto): Promise<UsePointDto> {
    // 요청일련번호 포인트풀 사용 내역조회
    const event = await this.pointEventRepository.findOne({
      where: { serialNumber: usePointDto.serialNumber },
    });
    if (event) {
      throw new ForbiddenException({
        message: '요청일련번호 중복 에러',
      });
    }

    //포인트풀 조회
    const pool = await this.pointPoolRepository.findOne({
      where: {
        eventType: usePointDto.eventTypeCd,
      },
    });
    if (!pool) {
      throw new NotFoundException(`Can't find pointPoolId `);
    }

    const queryRunner = this.dataSource.createQueryRunner();
    await queryRunner.connect();
    await queryRunner.startTransaction();

    // 트랜잭션 START
    try {
      const createUserDto = new CreateUserDto();
      // 사용자조회
      const user = await queryRunner.manager
        .getRepository(TbUserPoint)
        .findOne({ where: { userNo: usePointDto.userNo } });
      if (!user) {
        //신규유저 저장
        createUserDto.userNo = usePointDto.userNo;
        createUserDto.amtTotalPoint = 0;
        createUserDto.recUserId = process.env.SYSTEM_NAME || 'system';
        await queryRunner.manager
          .getRepository(TbUserPoint)
          .save(createUserDto);
        throw new NotFoundException(`Can't find userNo ${usePointDto.userNo}`);
      }

      // 보유포인트 체크
      if (user.amtTotalPoint < usePointDto.amtUsePoint) {
        throw new NotFoundException(
          `Can't use point ${usePointDto.amtUsePoint} `,
        );
      }

      // 적립 포인트 이벤트 인서트
      usePointDto.recUserId = process.env.SYSTEM_NAME || 'system';
      usePointDto.modUserId = process.env.SYSTEM_NAME || 'system';
      usePointDto.amtUsePoint = usePointDto.amtUsePoint * -1;
      usePointDto.pointPoolId = pool.pointPoolId;
      usePointDto.pointStateCd = 'USE';
      usePointDto.eventCtnts = `포인트 사용 `;
      const returned = await queryRunner.manager
        .getRepository(TbPointEvent)
        .save(usePointDto);
      console.log(returned);
      usePointDto.pointEventSeq = returned.pointEventSeq;

      // 사용할 포인트 조회
      // const usePointList = await queryRunner.manager
      //   .getRepository(TbPointEventDtls)
      //   .findBy({ userNo: returned.userNo });
      //console.log(usePointList);

      const result = await queryRunner.manager.query(
        `select save_point_event_dtls_seq as pointEventDtlsSeq
               ,sum(amt_use_point) as savePoint from tb_point_event_dtls
               where user_no = ${returned.userNo}
                group by save_point_event_dtls_seq
                having savePoint > 0`,
      );
      const rows = result;
      const amtUsePoint = {
        point: usePointDto.amtUsePoint, //사용요청-총포인트
        remain: usePointDto.amtUsePoint, //해당 사용요청-남은포인트
        totalRemain: usePointDto.amtUsePoint, //사용요청-총남은포인트
        use: 0, //사용요청-사용포인트
        totalUse: 0, //사용요청-누적사용포인트
      };
      // 사용포인트 : 10000을 보냈어두 9000포인트 밖에 없으면 사용 포인트는 9000으로 리턴
      if (rows.length == 0) {
        throw new NotFoundException(
          `Can't use point ${usePointDto.userNo} - point is empty `,
        );
      }

      for (const element of rows) {

        amtUsePoint.remain = element.savePoint + amtUsePoint.totalRemain;
        // 1. 사용시 -남은포인트 0이상일경우
        if (amtUsePoint.remain >= 0) {
          // 현재 적립금으로 사용완료 (완료)
          amtUsePoint.use = amtUsePoint.totalRemain;
        } else {
          // 2. 현재 적립금이 모자라면 해당 적립금만 사용 후 다음적립금으로 넘어감
          amtUsePoint.use = element.savePoint * -1;
        }

        amtUsePoint.totalUse = amtUsePoint.totalUse + amtUsePoint.use;
        amtUsePoint.totalRemain = amtUsePoint.remain;

        console.log('amtUsePoint.use:' + amtUsePoint.use);
        console.log('amtUsePoint.totalUse:' + amtUsePoint.totalUse);
        console.log('amtUsePoint.remain:' + amtUsePoint.remain);
        console.log('amtUsePoint.totalRemain:' + amtUsePoint.totalRemain);

        const eventDtls = await this.pointEventDtlsRepository.findOne({
          where: {
            pointEventDtlsSeq: element.pointEventDtlsSeq,
          },
        });
        console.log(eventDtls);
        delete eventDtls.pointEventDtlsSeq;
        eventDtls.pointEventSeq = usePointDto.pointEventSeq;
        eventDtls.pointStateCd = 'USE';
        eventDtls.amtUsePoint = amtUsePoint.use;

        await queryRunner.manager
          .getRepository(TbPointEventDtls)
          .save(eventDtls);
        //
        if (amtUsePoint.remain >= 0) {
          break;
        }
      }

      // 잔액체크
      const userPoint = await queryRunner.manager
        .getRepository(TbUserPoint)
        .findOne({ where: { userNo: usePointDto.userNo } });
      console.log("userPoint.amtTotalPoint:", userPoint.amtTotalPoint);
      if (userPoint.amtTotalPoint < 0) {
        throw new NotFoundException(`포인트가 부족하여 사용이 불가능합니다. `);
      }

      // 사용자 포인트 업데이트
      const queryBuilder = this.dataSource
        .getRepository(TbPointEventDtls)
        .createQueryBuilder('eventDtls');

      var sum = await queryBuilder
        .where('eventDtls.user_no = :userNo', { userNo: usePointDto.userNo })
        .select('SUM(eventDtls.amt_use_point)', 'totalPoint')
        .getRawOne();

      console.log("sum:"+sum.totalPoint);
      if(sum.totalPoint < 10){
        throw new NotFoundException(`포인트가 부족하여 사용이 불가능합니다. `);
      }else {
        // 정상처리
        await queryRunner.commitTransaction();
      }
      returned.amtUsePoint = amtUsePoint.totalUse;
      return returned;
    } catch (error) {
      console.error(error);
      await queryRunner.rollbackTransaction();
      throw error;
    } finally {

      console.log("sum2:"+sum.totalPoint);

        const updateUserDto = new CreateUserDto();
        updateUserDto.userNo = usePointDto.userNo;
        updateUserDto.modUserId = process.env.SYSTEM_NAME || 'system';
        updateUserDto.amtTotalPoint = sum.totalPoint;
        await queryRunner.manager
          .getRepository(TbUserPoint)
          .update(updateUserDto.userNo, updateUserDto);

      await queryRunner.release();
    }
  }

  async expPoint(expPointDto: ExpPointDto): Promise<ExpPointDto> {
    // 요청일련번호 포인트풀 사용 내역조회
    const event = await this.pointEventRepository.findOne({
      where: { serialNumber: expPointDto.serialNumber },
    });
    if (event) {
      throw new ForbiddenException({
        message: '요청일련번호 중복 에러',
      });
    }

    //포인트풀 조회
    const pool = await this.pointPoolRepository.findOne({
      where: {
        pointPoolTypeCd: 'SAVE',
      },
    });
    if (!pool) {
      throw new NotFoundException(`Can't find pointPoolId `);
    }
    expPointDto.eventTypeCd = pool.eventType;

    const queryRunner = this.dataSource.createQueryRunner();
    await queryRunner.connect();
    await queryRunner.startTransaction();

    // 트랜잭션 START
    try {
      const createUserDto = new CreateUserDto();
      // 사용자조회
      const user = await queryRunner.manager
        .getRepository(TbUserPoint)
        .findOne({ where: { userNo: expPointDto.userNo } });
      if (!user) {
        //신규유저 저장
        createUserDto.userNo = expPointDto.userNo;
        createUserDto.amtTotalPoint = 0;
        createUserDto.recUserId = process.env.SYSTEM_NAME || 'system';
        await queryRunner.manager
          .getRepository(TbUserPoint)
          .save(createUserDto);
        throw new NotFoundException(`Can't find userNo ${expPointDto.userNo}`);
      }

      // 보유포인트 체크
      if (user.amtTotalPoint < expPointDto.amtUsePoint) {
        throw new NotFoundException(
          `Can't use point ${expPointDto.amtUsePoint} `,
        );
      }

      // 적립 포인트 이벤트 인서트
      expPointDto.recUserId = process.env.SYSTEM_NAME || 'system';
      expPointDto.modUserId = process.env.SYSTEM_NAME || 'system';
      expPointDto.amtUsePoint = expPointDto.amtUsePoint * -1;
      expPointDto.pointPoolId = pool.pointPoolId;
      expPointDto.pointStateCd = 'EXPIRED';
      expPointDto.eventCtnts = `유효기간 만료 `;
      const returned = await queryRunner.manager
        .getRepository(TbPointEvent)
        .save(expPointDto);
      console.log(returned);
      expPointDto.pointEventSeq = returned.pointEventSeq;

      const result = await queryRunner.manager.query(
        `select save_point_event_dtls_seq as pointEventDtlsSeq
               ,sum(amt_use_point) as savePoint from tb_point_event_dtls
               where user_no = ${returned.userNo}
                group by save_point_event_dtls_seq
                having savePoint > 0`,
      );
      const rows = result;
      const amtUsePoint = {
        point: expPointDto.amtUsePoint, //사용요청-총포인트
        remain: expPointDto.amtUsePoint, //해당 사용요청-남은포인트
        totalRemain: expPointDto.amtUsePoint, //사용요청-총남은포인트
        use: 0, //사용요청-사용포인트
        totalUse: 0, //사용요청-누적사용포인트
      };
      // 사용포인트 : 10000을 보냈어두 9000포인트 밖에 없으면 사용 포인트는 9000으로 리턴
      if (rows.length == 0) {
        throw new NotFoundException(
          `Can't use point ${expPointDto.userNo} - point is empty `,
        );
      }

      for (const element of rows) {

        amtUsePoint.remain = element.savePoint + amtUsePoint.totalRemain;
        // 1. 사용시 -남은포인트 0이상일경우
        if (amtUsePoint.remain >= 0) {
          // 현재 적립금으로 사용완료 (완료)
          amtUsePoint.use = amtUsePoint.totalRemain;
        } else {
          // 2. 현재 적립금이 모자라면 해당 적립금만 사용 후 다음적립금으로 넘어감
          amtUsePoint.use = element.savePoint * -1;
        }

        amtUsePoint.totalUse = amtUsePoint.totalUse + amtUsePoint.use;
        amtUsePoint.totalRemain = amtUsePoint.remain;

        console.log('amtUsePoint.use:' + amtUsePoint.use);
        console.log('amtUsePoint.totalUse:' + amtUsePoint.totalUse);
        console.log('amtUsePoint.remain:' + amtUsePoint.remain);
        console.log('amtUsePoint.totalRemain:' + amtUsePoint.totalRemain);

        const eventDtls = await this.pointEventDtlsRepository.findOne({
          where: {
            pointEventDtlsSeq: element.pointEventDtlsSeq,
          },
        });
        console.log(eventDtls);
        delete eventDtls.pointEventDtlsSeq;
        eventDtls.pointEventSeq = expPointDto.pointEventSeq;
        eventDtls.pointStateCd = 'EXPIRED';
        eventDtls.amtUsePoint = amtUsePoint.use;

        await queryRunner.manager
          .getRepository(TbPointEventDtls)
          .save(eventDtls);
        //
        if (amtUsePoint.remain >= 0) {
          break;
        }
      }

      // 정상처리
      await queryRunner.commitTransaction();
      returned.amtUsePoint = amtUsePoint.totalUse;
      return returned;
    } catch (error) {
      console.error(error);
      await queryRunner.rollbackTransaction();
      throw error;
    } finally {
      // 사용자 포인트 업데이트
      const queryBuilder = this.dataSource
        .getRepository(TbPointEventDtls)
        .createQueryBuilder('eventDtls');

      const sum = await queryBuilder
        .where('eventDtls.user_no = :userNo', { userNo: expPointDto.userNo })
        .select('SUM(eventDtls.amt_use_point)', 'totalPoint')
        .getRawOne();

      const updateUserDto = new CreateUserDto();
      updateUserDto.userNo = expPointDto.userNo;
      updateUserDto.modUserId = process.env.SYSTEM_NAME || 'system';
      updateUserDto.amtTotalPoint = sum.totalPoint;
      await queryRunner.manager
        .getRepository(TbUserPoint)
        .update(updateUserDto.userNo, updateUserDto);

      await queryRunner.release();
    }
  }
}
