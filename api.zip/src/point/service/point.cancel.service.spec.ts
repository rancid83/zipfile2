import { Test, TestingModule } from '@nestjs/testing';
import { PointCancelService } from './point.cancel.service';

describe('PointCancelService', () => {
  let service: PointCancelService;

  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
      providers: [PointCancelService],
    }).compile();

    service = module.get<PointCancelService>(PointCancelService);
  });

  it('should be defined', () => {
    expect(service).toBeDefined();
  });
});
