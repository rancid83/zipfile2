import { Test, TestingModule } from '@nestjs/testing';
import { PointUseService } from './point.use.service';

describe('PointService', () => {
  let service: PointUseService;

  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
      providers: [PointUseService],
    }).compile();

    service = module.get<PointUseService>(PointUseService);
  });

  it('should be defined', () => {
    expect(service).toBeDefined();
  });
});
