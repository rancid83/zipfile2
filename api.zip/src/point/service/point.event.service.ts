import {
  Injectable,
} from '@nestjs/common';
import { TbPointEvent } from '../../entities/TbPointEvent';
import { DataSource, Repository } from 'typeorm';
import { InjectRepository } from '@nestjs/typeorm';
import { TbPointPool } from '../../entities/TbPointPool';
import { TbServiceOperInfo } from '../../entities/TbServiceOperInfo';
import { TbServiceOperLog } from '../../entities/TbServiceOperLog';
import { TbPointEventDtls } from '../../entities/TbPointEventDtls';
import { TbUserPoint } from '../../entities/TbUserPoint';

@Injectable()
export class PointEventService {
  constructor(
    @InjectRepository(TbPointEvent)
    private pointEventRepository: Repository<TbPointEvent>,
    @InjectRepository(TbPointPool)
    private pointPoolRepository: Repository<TbPointPool>,
    @InjectRepository(TbServiceOperInfo)
    private serviceOperInfoRepository: Repository<TbServiceOperInfo>,
    @InjectRepository(TbServiceOperLog)
    private serviceOperLogRepository: Repository<TbServiceOperLog>,
    @InjectRepository(TbPointEventDtls)
    private pointEventDtlsRepository: Repository<TbPointEventDtls>,
    @InjectRepository(TbUserPoint)
    private userPointRepository: Repository<TbUserPoint>,
  ) {}

}
