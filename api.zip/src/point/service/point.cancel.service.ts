import {
  ForbiddenException,
  Injectable,
  NotFoundException,
} from '@nestjs/common';
import { TbPointEvent } from '../../entities/TbPointEvent';
import { DataSource, Repository } from 'typeorm';
import { InjectRepository } from '@nestjs/typeorm';
import { TbPointPool } from '../../entities/TbPointPool';
import { TbServiceOperInfo } from '../../entities/TbServiceOperInfo';
import { TbServiceOperLog } from '../../entities/TbServiceOperLog';
import { TbPointEventDtls } from '../../entities/TbPointEventDtls';
import { TbUserPoint } from '../../entities/TbUserPoint';
import { CreateUserDto } from './../dto/request/create-user.dto';
import { CancelPointDto } from '../dto/request/cancel-point.dto';
import { CancelBatchPointDto } from '../dto/request/cancel-batch-point.dto';
import { CancelBatchResponseDto } from '../dto/response/cancel-batch.response.dto';

@Injectable()
export class PointCancelService {
  private isUser: boolean | true;

  constructor(
    @InjectRepository(TbPointEvent)
    private pointEventRepository: Repository<TbPointEvent>,
    @InjectRepository(TbPointPool)
    private pointPoolRepository: Repository<TbPointPool>,
    @InjectRepository(TbServiceOperInfo)
    private serviceOperInfoRepository: Repository<TbServiceOperInfo>,
    @InjectRepository(TbServiceOperLog)
    private serviceOperLogRepository: Repository<TbServiceOperLog>,
    @InjectRepository(TbPointEventDtls)
    private pointEventDtlsRepository: Repository<TbPointEventDtls>,
    @InjectRepository(TbUserPoint)
    private userPointRepository: Repository<TbUserPoint>,
    private dataSource: DataSource,
  ) {}

  /**
   * 사용된 포인트 취소
   * @param CancelPointDto - 사용된 포인트 요청일련번호 인지 확인을 위한 입력 정보 DTO
   * @return boolean 취소처리여부
   * @see ""
   */
  async cancelPoint(cancelPointDto: CancelPointDto): Promise<CancelPointDto> {
    // 요청일련번호 포인트풀 사용 내역조회
    const reqEvent = await this.pointEventRepository.findOne({
      where: { serialNumber: cancelPointDto.serialNumber },
    });
    if (reqEvent) {
      throw new ForbiddenException({
        message: '요청일련번호 중복 에러',
      });
    }

    // 취소내역 조회
    const cancelEvent = await this.pointEventRepository.findOne({
      where: {
        pointEventSeq: cancelPointDto.pointEventSeq,
        eventTypeCd: '1',
        pointStateCd: 'CANCEL',
      },
    });
    if (cancelEvent) {
      throw new ForbiddenException(
        `already Canceled ${cancelPointDto.serialNumber}`,
      );
    }
    // pointEventSeq 포인트풀 사용 내역조회
    const event = await this.pointEventRepository.findOne({
      where: { pointEventSeq: cancelPointDto.pointEventSeq },
    });
    if (!event) {
      throw new NotFoundException(
        `Can't find pointEventSeq ${cancelPointDto.pointEventSeq}`,
      );
    }

    // 동일 사용자번호 인지 체크 ( 동일 사용자인 경우만 취소가능 )
    if (event.userNo != cancelPointDto.userNo) {
      throw new NotFoundException(
        `Can't find pointEventSeq ${cancelPointDto.pointEventSeq}`,
      );
    }

    const queryRunner = this.dataSource.createQueryRunner();
    await queryRunner.connect();
    await queryRunner.startTransaction();

    // 트랜잭션 START
    try {
      // 취소가능금액 조회
      // querybuilder 사용내역 조회
      const queryBuilder = this.dataSource
        .getRepository(TbPointEventDtls)
        .createQueryBuilder('eventDtls');

      const validateCheck = await queryBuilder
        .where('eventDtls.point_event_seq = :pointEventSeq', {
          pointEventSeq: cancelPointDto.pointEventSeq,
        })
        .select('SUM(eventDtls.amt_use_point)', 'usePoint')
        .getRawOne();

      console.log(validateCheck);

      if (validateCheck.usePoint >= 0) {
        throw new NotFoundException(
          `포인트 사용취소 대상 내역이 없습니다. pointEventSeq: ${cancelPointDto.pointEventSeq}`,
        );
      }

      // 취소 포인트 이벤트 인서트
      delete event.pointEventSeq;
      delete event.recDate;
      delete event.modDate;
      event.amtUsePoint = event.amtUsePoint * -1;
      event.serialNumber = cancelPointDto.serialNumber;
      event.pointStateCd = 'CANCEL';
      event.eventCtnts = `포인트 시용취소 `;
      const returned = await queryRunner.manager
        .getRepository(TbPointEvent)
        .save(event);
      console.log(returned);

      // 사용내역 조회
      const queryBuilder2 = this.dataSource
        .getRepository(TbPointEventDtls)
        .createQueryBuilder('eventDtls');
      const eventDtls = await queryBuilder2
        .where('eventDtls.point_event_seq = :pointEventSeq', {
          pointEventSeq: cancelPointDto.pointEventSeq,
        })
        .andWhere(' amt_use_point < 0 ')
        .getMany();

      const rows = eventDtls;
      for (const element of rows) {
        // 사용취소처리
        const rowEventDtls = element;
        delete rowEventDtls.pointEventDtlsSeq;
        rowEventDtls.pointEventSeq = cancelPointDto.pointEventSeq;
        rowEventDtls.amtUsePoint = rowEventDtls.amtUsePoint * -1;
        rowEventDtls.pointStateCd = 'CANCEL';
        await queryRunner.manager
          .getRepository(TbPointEventDtls)
          .save(rowEventDtls);
      }

      // 정상처리
      await queryRunner.commitTransaction();
      cancelPointDto.amtCancelPoint = event.amtUsePoint;
      return cancelPointDto;
    } catch (error) {
      console.error(error);
      await queryRunner.rollbackTransaction();
      throw error;
    } finally {
      // 사용자 포인트 업데이트
      const queryBuilder = this.dataSource
        .getRepository(TbPointEventDtls)
        .createQueryBuilder('eventDtls');
      const sum = await queryBuilder
        .where('eventDtls.user_no = :userNo', { userNo: cancelPointDto.userNo })
        .select('SUM(eventDtls.amt_use_point)', 'totalPoint')
        .getRawOne();

      const updateUserDto = new CreateUserDto();
      updateUserDto.userNo = cancelPointDto.userNo;
      updateUserDto.modUserId = process.env.SYSTEM_NAME || 'system';
      updateUserDto.amtTotalPoint = sum.totalPoint;
      await queryRunner.manager
        .getRepository(TbUserPoint)
        .update(updateUserDto.userNo, updateUserDto);

      await queryRunner.release();
    }
  }

  /**
   * 사용된 포인트 일괄취소
   * @param CancelBatchPointDto - 지급된 포인트 요청일련번호 인지 확인을 위한 입력 정보 DTO
   * @return boolean 회수 처리여부
   * @see ""
   */
  async cancelBatchPoint(
    cancelBatchPointDto: CancelBatchPointDto<TbPointEvent>,
  ): Promise<CancelBatchResponseDto<any>> {
    // 취소건 체크
    console.log(cancelBatchPointDto.data.length);
    if (cancelBatchPointDto.data.length == 0) {
      throw new NotFoundException(`Can't find data`);
    }
    const rows = cancelBatchPointDto.data;

    // 취소응답값 초기화
    const cancelBatchResponseDto = new CancelBatchResponseDto();
    cancelBatchResponseDto.totalCnt = rows.length;
    cancelBatchResponseDto.sucessCnt = 0;
    cancelBatchResponseDto.failCnt = 0;
    cancelBatchResponseDto.failData = [];
    for (const element of rows) {
      let failJson = {};
      console.log('pointEventSeq:' + element.pointEventSeq);
      const cancelPointDto = new CancelPointDto();
      cancelPointDto.pointEventSeq = element.pointEventSeq;
      cancelPointDto.userNo = element.userNo;
      cancelPointDto.isBatch = true;

      // 취소내역 조회
      const cancelEvent = await this.pointEventRepository.findOne({
        where: {
          pointEventSeq: cancelPointDto.pointEventSeq,
          eventTypeCd: '1',
          pointStateCd: 'CANCEL',
        },
      });
      if (cancelEvent) {
        cancelBatchResponseDto.failCnt++;
        failJson = {
          pointEventSeq: cancelPointDto.pointEventSeq,
          failReason: `already Canceled ${cancelPointDto.serialNumber}`,
        };
        cancelBatchResponseDto.failData.push(failJson);
      }
      // pointEventSeq 포인트풀 사용 내역조회
      const event = await this.pointEventRepository.findOne({
        where: {
          pointEventSeq: cancelPointDto.pointEventSeq,
          eventTypeCd: '1',
          pointStateCd: 'USE',
        },
      });
      if (!event) {
        cancelBatchResponseDto.failCnt++;
        failJson = {
          pointEventSeq: cancelPointDto.pointEventSeq,
          failReason: `Can't find pointEventSeq ${cancelPointDto.pointEventSeq}`,
        };
        cancelBatchResponseDto.failData.push(failJson);
      }

      const queryRunner = this.dataSource.createQueryRunner();
      await queryRunner.connect();
      await queryRunner.startTransaction();

      // 트랜잭션 START
      try {
        // 취소가능금액 조회
        // querybuilder 사용내역 조회
        const queryBuilder = this.dataSource
          .getRepository(TbPointEventDtls)
          .createQueryBuilder('eventDtls');

        const validateCheck = await queryBuilder
          .where('eventDtls.point_event_seq = :pointEventSeq', {
            pointEventSeq: cancelPointDto.pointEventSeq,
          })
          .select('SUM(eventDtls.amt_use_point)', 'usePoint')
          .getRawOne();

        if (validateCheck.usePoint >= 0) {
          console.error(
            `포인트 사용취소 대상 내역이 없습니다. pointEventSeq: ${cancelPointDto.pointEventSeq}`,
          );
          cancelBatchResponseDto.failCnt++;
        }

        // 포인트 취소 내역조회
        const canceled = await this.pointEventDtlsRepository.findOne({
          where: {
            pointEventSeq: cancelPointDto.pointEventSeq,
            pointStateCd: 'CANCEL',
          },
        });
        if (canceled) {
          throw new NotFoundException(
            `이미 취소된 포인트입니다 pointEventSeq: ${cancelPointDto.pointEventSeq}`,
          );
        }

        await console.log(event);
        // 취소 포인트 이벤트 인서트
        delete event.pointEventSeq;
        event.amtUsePoint = event.amtUsePoint * -1;
        event.eventTypeCd = '1';
        event.pointStateCd = 'CANCEL';
        event.serialNumber = event.serialNumber + '_CANCEL';
        event.eventCtnts = `포인트 시용 일괄 취소 ${event.amtUsePoint} ( pointEventSeq : ${cancelPointDto.pointEventSeq} )`;
        const returned = await queryRunner.manager
          .getRepository(TbPointEvent)
          .save(event);
        console.log(returned);

        // 사용내역 조회
        const queryBuilder2 = this.dataSource
          .getRepository(TbPointEventDtls)
          .createQueryBuilder('eventDtls');
        const eventDtls = await queryBuilder2
          .where('eventDtls.point_event_seq = :pointEventSeq', {
            pointEventSeq: cancelPointDto.pointEventSeq,
          })
          .andWhere(' amt_use_point < 0 ')
          .getMany();

        const rows = eventDtls;
        for (const element of rows) {
          // 사용취소처리
          const rowEventDtls = element;
          delete rowEventDtls.pointEventDtlsSeq;
          rowEventDtls.amtUsePoint = rowEventDtls.amtUsePoint * -1;
          rowEventDtls.pointStateCd = 'CANCEL';
          rowEventDtls.serialNumber = rowEventDtls.serialNumber;
          await queryRunner.manager
            .getRepository(TbPointEventDtls)
            .save(rowEventDtls);
          console.log(rowEventDtls);
        }

        // 정상처리
        cancelBatchResponseDto.sucessCnt++;
        await queryRunner.commitTransaction();
        cancelPointDto.amtCancelPoint = event.amtUsePoint;
      } catch (error) {
        console.error(error);
        await queryRunner.rollbackTransaction();
      } finally {
        // 사용자 포인트 업데이트
        const queryBuilder = this.dataSource
          .getRepository(TbPointEventDtls)
          .createQueryBuilder('eventDtls');

        const sum = await queryBuilder
          .where('eventDtls.user_no = :userNo', {
            userNo: cancelPointDto.userNo,
          })
          .select('SUM(eventDtls.amt_use_point)', 'totalPoint')
          .getRawOne();

        const updateUserDto = new CreateUserDto();
        updateUserDto.userNo = cancelPointDto.userNo;
        updateUserDto.modUserId = process.env.SYSTEM_NAME || 'system';
        updateUserDto.amtTotalPoint = sum.totalPoint;
        await queryRunner.manager
          .getRepository(TbUserPoint)
          .update(updateUserDto.userNo, updateUserDto);

        await queryRunner.release();
      }
    }

    return cancelBatchResponseDto;
  }
}
