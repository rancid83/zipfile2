import {
  Injectable,
  NotFoundException,
} from '@nestjs/common';
import { TbPointEvent } from '../../entities/TbPointEvent';
import { DataSource, Repository } from 'typeorm';
import { InjectRepository } from '@nestjs/typeorm';
import { TbPointPool } from '../../entities/TbPointPool';
import { TbServiceOperInfo } from '../../entities/TbServiceOperInfo';
import { TbServiceOperLog } from '../../entities/TbServiceOperLog';
import { TbPointEventDtls } from '../../entities/TbPointEventDtls';
import { TbUserPoint } from '../../entities/TbUserPoint';
import { TransactionPointDto } from '../dto/request/transaction-point.dto';
import { LocalDateTime } from 'js-joda';

@Injectable()
export class PointSettleService {
  constructor(
    @InjectRepository(TbPointEvent)
    private pointEventRepository: Repository<TbPointEvent>,
    @InjectRepository(TbPointPool)
    private pointPoolRepository: Repository<TbPointPool>,
    @InjectRepository(TbServiceOperInfo)
    private serviceOperInfoRepository: Repository<TbServiceOperInfo>,
    @InjectRepository(TbServiceOperLog)
    private serviceOperLogRepository: Repository<TbServiceOperLog>,
    @InjectRepository(TbPointEventDtls)
    private pointEventDtlsRepository: Repository<TbPointEventDtls>,
    @InjectRepository(TbUserPoint)
    private userPointRepository: Repository<TbUserPoint>,
    private dataSource: DataSource,
  ) {}

  /**
   * 사용된 포인트 정산
   * @param TransactionPointDto - 지급된 포인트 요청일련번호 인지 확인을 위한 입력 정보 DTO
   * @return boolean 회수 처리여부
   * @see ""
   */
  async settlePoint(
    transactionPointDto: TransactionPointDto,
  ): Promise<TransactionPointDto> {
    // 요청일련번호 포인트풀 사용 내역조회
    const event = await this.pointEventRepository.findOne({
      where: {
        pointEventSeq: transactionPointDto.pointEventSeq,
        pointStateCd: 'USE',
      },
    });
    if (!event) {
      throw new NotFoundException(
        `사용내역이 없습니다. pointEventSeq: ${transactionPointDto.pointEventSeq}`,
      );
    }

    const queryRunner = this.dataSource.createQueryRunner();
    await queryRunner.connect();
    await queryRunner.startTransaction();

    // 트랜잭션 START
    try {
      //주문번호 업데이트
      event.orderNo = transactionPointDto.settleId;
      const nowTime = LocalDateTime.now();
      console.log(nowTime);
      await queryRunner.manager
        .getRepository(TbPointEvent)
        .update(event.pointEventSeq, event);
      transactionPointDto.modUserId = process.env.SYSTEM_NAME || 'system';
      transactionPointDto.pointEventSeq = event.pointEventSeq;
      transactionPointDto.amtUsePoint = event.amtUsePoint;
      // 정상처리
      await queryRunner.commitTransaction();
      return transactionPointDto;
    } catch (error) {
      console.error(error);
      await queryRunner.rollbackTransaction();
      throw error;
    } finally {
      await queryRunner.release();
    }
  }
}
