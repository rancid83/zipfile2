import { Test, TestingModule } from '@nestjs/testing';
import { PointSaveService } from './point.save.service';

describe('PointService', () => {
  let service: PointSaveService;

  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
      providers: [PointSaveService],
    }).compile();

    service = module.get<PointSaveService>(PointSaveService);
  });

  it('should be defined', () => {
    expect(service).toBeDefined();
  });
});
