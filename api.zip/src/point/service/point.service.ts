import {
  Injectable,
} from '@nestjs/common';
import { TbPointEvent } from '../../entities/TbPointEvent';
import { Brackets, DataSource, Repository } from 'typeorm';
import { InjectRepository } from '@nestjs/typeorm';
import { TbPointPool } from '../../entities/TbPointPool';
import { TbServiceOperInfo } from '../../entities/TbServiceOperInfo';
import { TbServiceOperLog } from '../../entities/TbServiceOperLog';
import { TbPointEventDtls } from '../../entities/TbPointEventDtls';
import { TbUserPoint } from '../../entities/TbUserPoint';
import { PagingDto } from '../../common/paging/dto/paging.dto';
import { PageMetaDto } from '../../common/paging/dto/page-meta.dto';
import { PageOptionsDto } from '../../common/paging/dto/page-optons.dto';
import { TbPointPoolSchedule } from '../../entities/TbPointPoolSchedule';
import { LocalDate, TemporalAdjusters } from 'js-joda';
@Injectable()
export class PointService {
  private isUser: boolean | true;
  constructor(
    @InjectRepository(TbPointEvent)
    private pointEventRepository: Repository<TbPointEvent>,
    @InjectRepository(TbPointPool)
    private pointPoolRepository: Repository<TbPointPool>,
    @InjectRepository(TbServiceOperInfo)
    private serviceOperInfoRepository: Repository<TbServiceOperInfo>,
    @InjectRepository(TbServiceOperLog)
    private serviceOperLogRepository: Repository<TbServiceOperLog>,
    @InjectRepository(TbPointEventDtls)
    private pointEventDtlsRepository: Repository<TbPointEventDtls>,
    @InjectRepository(TbUserPoint)
    private userPointRepository: Repository<TbUserPoint>,
    @InjectRepository(TbPointPoolSchedule)
    private pointPoolScheduleRepository: Repository<TbPointPoolSchedule>,
    private dataSource: DataSource,
  ) {}

  async getUserPoint(userNo: number): Promise<TbUserPoint> {
    try {
      const userPoint = await this.userPointRepository.findOne({
        where: { userNo: userNo },
      });
      return userPoint;
    }catch (err) {
      return null
    }
  }
  /**
   * 사용자 포인트 내역조회
   * @param PagingDto - 이벤트 포인트 내역 페이징 정보 DTO
   * @return boolean 지급처리 여부
   * @see ""
   */
  async getUserPointList(
    userNo: number,
    pageOptionsDto: PageOptionsDto,
  ): Promise<PagingDto<TbPointEvent>> {
    const queryBuilder = this.dataSource
      .getRepository(TbPointEvent)
      .createQueryBuilder('event');

    await queryBuilder
      .where('event.user_no = :userNo', { userNo: userNo })
      .orderBy('event.point_event_seq', pageOptionsDto.order)
      .skip(pageOptionsDto.skip)
      .take(pageOptionsDto.take)
      .getMany();

    if (pageOptionsDto.startdate && pageOptionsDto.enddate) {
      queryBuilder.andWhere(
        `event.rec_date BETWEEN '${pageOptionsDto.startdate} 00:00:00' AND '${pageOptionsDto.enddate} 23:59:59'`,
      );
    }
    if (pageOptionsDto.pointStateCd && pageOptionsDto.pointStateCd != 'ALL') {
      queryBuilder.andWhere(`event.point_state_cd = :pointStateCd`, {
        pointStateCd: pageOptionsDto.pointStateCd,
      });
    }

    const itemCount = await queryBuilder.getCount();
    const { entities } = await queryBuilder.getRawAndEntities();

    const pageMetaDto = new PageMetaDto({ itemCount, pageOptionsDto });

    return new PagingDto(entities, pageMetaDto, []);
  }

  /**
   * 사용자 포인트 출석체크 내역조회
   * @param PagingDto - 이벤트 포인트 내역 페이징 정보 DTO
   * @return boolean 지급처리 여부
   * @see ""
   */
  async getUserPointDailyList(
    userNo: number,
    pageOptionsDto: PageOptionsDto,
  ): Promise<PagingDto<TbPointEvent>> {
    const queryBuilder = this.dataSource
      .getRepository(TbPointEvent)
      .createQueryBuilder('event');
    await queryBuilder
      .where('event.user_no = :userNo', { userNo: userNo })
      .orderBy('event.point_event_seq', pageOptionsDto.order)
      .skip(pageOptionsDto.skip)
      .take(pageOptionsDto.take)
      .getMany();

    // eventTypeCd, actionCd  이벤트 조회 ( *2 , *3 , D+15, D+END ) 조회조건 추가
    if (pageOptionsDto.startdate && pageOptionsDto.enddate) {
      queryBuilder.andWhere(
        `event.rec_date BETWEEN '${pageOptionsDto.startdate} 00:00:00' AND '${pageOptionsDto.enddate} 23:59:59'`,
      );
    }
    if (pageOptionsDto.pointStateCd && pageOptionsDto.pointStateCd != 'ALL') {
      queryBuilder.andWhere(`event.point_state_cd = :pointStateCd`, {
        pointStateCd: pageOptionsDto.pointStateCd,
      });
    }

    // eventTypeCd 조회조건 추가
    if (pageOptionsDto.eventTypeCd) {
      const eventTypeCd = pageOptionsDto.eventTypeCd.split(',');
      queryBuilder.andWhere(
        new Brackets((qb) => {
          if (eventTypeCd.length == 0) {
            qb.where('event.eventTypeCd = :eventTypeCd', {
              eventTypeCd: pageOptionsDto.eventTypeCd,
            });
          }
          if (eventTypeCd.length > 0) {
            eventTypeCd.forEach(function (value, index) {
              if (value == 'DAILY') {
                qb.orWhere(`event.eventTypeCd = 'DAILY' `);
              }
              if (value == 'REWARDS_DRAW') {
                qb.orWhere(`event.eventTypeCd = 'REWARDS_DRAW' `);
              }
              if (value == 'REWARDS_BUY') {
                qb.orWhere(`event.eventTypeCd = 'REWARDS_BUY' `);
              }
            });
          }
        }),
      );
    }

    // 해당월 이벤트 조회 ( *2 , *3 , D+15, D+END ) eventData 추가
    if (pageOptionsDto.actionTypeCd) {
      const actionTypeCd = pageOptionsDto.actionTypeCd.split(',');
      queryBuilder.andWhere(
        new Brackets((qb) => {
          if (actionTypeCd.length == 0) {
            qb.where('event.actionTypeCd = :actionTypeCd', {
              actionTypeCd: pageOptionsDto.actionTypeCd,
            });
          }
          if (actionTypeCd.length > 0) {
            actionTypeCd.forEach(function (value, index) {
              if (value == 'NORMAL') {
                qb.orWhere(`event.actionTypeCd = 'NORMAL' `);
              }
              if (value == 'RANDOM') {
                qb.orWhere(`event.actionTypeCd = 'RANDOM' `);
              }
              if (value == 'X2') {
                qb.orWhere(`event.actionTypeCd = 'X2' `);
              }
              if (value == 'X3') {
                qb.orWhere(`event.actionTypeCd = 'X3' `);
              }
              if (value == 'D+15') {
                qb.orWhere(`event.actionTypeCd = 'D+15' `);
              }
              if (value == 'D+END') {
                qb.orWhere(`event.actionTypeCd = 'D+END' `);
              }
            });
          }
        }),
      );
    }

    // event Date 현재달 출석체크 조회
    const queryBuilderEvent = this.dataSource
      .getRepository(TbPointPoolSchedule)
      .createQueryBuilder('events');
    const d = LocalDate.parse(LocalDate.now().toString());
    const start = d.with(TemporalAdjusters.firstDayOfMonth()).toString();
    const end = d.with(TemporalAdjusters.lastDayOfMonth()).toString();
    await queryBuilderEvent
      .select('events.event_schedule_id', 'scheduleId')
      .addSelect('events.schedule_name', 'scheduleName')
      .addSelect('events.schedule_date', 'scheduleDate')
      .addSelect('events.action_type_cd', 'actionTypeCd')
      .addSelect('events.amt_save_option', 'amtSaveOption')
      .where('events.schedule_date between :startDate and :endDate', {
        startDate: start,
        endDate: end,
      })
      .andWhere(` events.use_yn = 'Y' `)
      .orderBy('events.schedule_date', pageOptionsDto.order)
      .getMany();

    const itemCount = await queryBuilder.getCount();
    const { entities } = await queryBuilder.getRawAndEntities();
    const pageMetaDto = new PageMetaDto({ itemCount, pageOptionsDto });
    const { raw } = await queryBuilderEvent.getRawAndEntities();
    return new PagingDto(entities, pageMetaDto, raw);
  }
}
