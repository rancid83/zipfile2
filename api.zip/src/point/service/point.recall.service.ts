import {
  ForbiddenException,
  Injectable,
  NotFoundException,
} from '@nestjs/common';
import { TbPointEvent } from '../../entities/TbPointEvent';
import { DataSource, Repository } from 'typeorm';
import { InjectRepository } from '@nestjs/typeorm';
import { TbPointPool } from '../../entities/TbPointPool';
import { TbServiceOperInfo } from '../../entities/TbServiceOperInfo';
import { TbServiceOperLog } from '../../entities/TbServiceOperLog';
import { TbPointEventDtls } from '../../entities/TbPointEventDtls';
import { TbUserPoint } from '../../entities/TbUserPoint';
import { CreateUserDto } from './../dto/request/create-user.dto';
import { RecallPointDto } from '../dto/request/recall-point.dto';

@Injectable()
export class PointRecallService {
  private isUser: boolean | true;
  constructor(
    @InjectRepository(TbPointEvent)
    private pointEventRepository: Repository<TbPointEvent>,
    @InjectRepository(TbPointPool)
    private pointPoolRepository: Repository<TbPointPool>,
    @InjectRepository(TbServiceOperInfo)
    private serviceOperInfoRepository: Repository<TbServiceOperInfo>,
    @InjectRepository(TbServiceOperLog)
    private serviceOperLogRepository: Repository<TbServiceOperLog>,
    @InjectRepository(TbPointEventDtls)
    private pointEventDtlsRepository: Repository<TbPointEventDtls>,
    @InjectRepository(TbUserPoint)
    private userPointRepository: Repository<TbUserPoint>,
    private dataSource: DataSource,
  ) {}

  /**
   * 사용된 포인트 회수
   * @param RecallPointDto - 지급된 포인트 요청일련번호 인지 확인을 위한 입력 정보 DTO
   * @return boolean 회수 처리여부
   * @see ""
   */
  async recallPoint(recallPointDto: RecallPointDto): Promise<RecallPointDto> {
    // 요청일련번호 포인트풀 사용 내역조회
    const eventCheck = await this.pointEventRepository.findOne({
      where: { serialNumber: recallPointDto.serialNumber },
    });
    if (eventCheck) {
      throw new ForbiddenException({
        message: '요청일련번호 중복 에러',
      });
    }
    // 요청일련번호 포인트풀 사용 내역조회
    // const useEvent = await this.pointEventDtlsRepository.findOne({
    //   where: {
    //     pointEventSeq: recallPointDto.pointEventSeq,
    //     pointStateCd: 'USE',
    //   },
    // });
    // if (useEvent) {
    //   throw new NotFoundException(
    //     `사용된 포인트라 회수가 불가능합니다. pointEventSeq: ${recallPointDto.pointEventSeq}`,
    //   );
    // }
    // 요청일련번호 포인트풀 회수 내역조회
    const recallEvent = await this.pointEventDtlsRepository.findOne({
      where: {
        savePointEventDtlsSeq: recallPointDto.pointEventSeq,
        pointStateCd: 'RECALL',
      },
    });
    if (recallEvent) {
      throw new NotFoundException(
        `이미 회수된 포인트라 회수가 불가능합니다. pointEventSeq: ${recallPointDto.pointEventSeq}`,
      );
    }
    // 요청일련번호로 지급내역 조회
    const event = await this.pointEventRepository.findOne({
      where: {
        pointEventSeq: recallPointDto.pointEventSeq,
        pointStateCd: 'SAVE',
      },
    });
    if (!event) {
      throw new NotFoundException(
        `Can't find pointEventSeq ${recallPointDto.pointEventSeq}`,
      );
    }

    // 동일 사용자번호 인지 체크 ( 동일 사용자인 경우만 회수가능 )
    if (event.userNo != recallPointDto.userNo) {
      throw new NotFoundException(
        `Can't find pointEventSeq ${recallPointDto.pointEventSeq}`,
      );
    }


    const queryRunner = this.dataSource.createQueryRunner();
    await queryRunner.connect();
    await queryRunner.startTransaction();

    // 트랜잭션 START
    try {
      const user = await queryRunner.manager
        .getRepository(TbUserPoint)
        .findOne({ where: { userNo: recallPointDto.userNo } });
      if (user.amtTotalPoint < event.amtEventPoint) {
        throw new NotFoundException(`포인트가 부족하여 회수가 불가능합니다. `);
      }

      event.amtEventPoint = event.amtEventPoint * -1;
      event.eventCtnts = `포인트 회수 `;
      event.pointStateCd = 'RECALL';
      event.serialNumber = recallPointDto.serialNumber;

      // 지급내역 회수 이벤트
      delete event.pointEventSeq;
      delete event.recDate;
      delete event.modDate;
      event.amtUsePoint = 0;
      const returned = await queryRunner.manager
        .getRepository(TbPointEvent)
        .save(event);
      console.log(returned);

      const eventDtls = await this.pointEventDtlsRepository.findOne({
        where: {
          pointEventSeq: recallPointDto.pointEventSeq,
          pointStateCd: 'SAVE',
        },
      });
      console.log(eventDtls);

      delete eventDtls.pointEventDtlsSeq;
      eventDtls.pointStateCd = 'RECALL';
      eventDtls.amtUsePoint = returned.amtEventPoint; // 포인트 회수

      await queryRunner.manager
        .getRepository(TbPointEventDtls)
        .save(eventDtls);

      // 정상처리
      recallPointDto.amtEventPoint = eventDtls.amtUsePoint;
      await queryRunner.commitTransaction();
      return recallPointDto;
    } catch (error) {
      console.error(error);
      await queryRunner.rollbackTransaction();
      throw error;
    } finally {
      // 사용자 포인트 업데이트
      const queryBuilder = this.dataSource
        .getRepository(TbPointEventDtls)
        .createQueryBuilder('eventDtls');

      const sum = await queryBuilder
        .where('eventDtls.user_no = :userNo', {
          userNo: recallPointDto.userNo,
        })
        .select('SUM(eventDtls.amt_use_point)', 'totalPoint')
        .getRawOne();

      console.log(sum);
      const updateUserDto = new CreateUserDto();
      updateUserDto.userNo = recallPointDto.userNo;
      updateUserDto.modUserId = process.env.SYSTEM_NAME || 'system';
      updateUserDto.amtTotalPoint = sum.totalPoint;
      await queryRunner.manager
        .getRepository(TbUserPoint)
        .update(updateUserDto.userNo, updateUserDto);

      await queryRunner.release();
    }
  }
}
