import { Test, TestingModule } from '@nestjs/testing';
import { PointRecallService } from './point.recall.service';

describe('PointRecallService', () => {
  let service: PointRecallService;

  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
      providers: [PointRecallService],
    }).compile();

    service = module.get<PointRecallService>(PointRecallService);
  });

  it('should be defined', () => {
    expect(service).toBeDefined();
  });
});
