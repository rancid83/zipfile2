import { Module } from '@nestjs/common';
import { ConfigModule } from '@nestjs/config';
import { PointService } from './service/point.service';
import { PointUseService } from './service/point.use.service';
import { PointSaveService } from './service/point.save.service';
import { PointCancelService } from './service/point.cancel.service';
import { PointRecallService } from './service/point.recall.service';
import { PointSettleService } from './service/point.settle.service';
import { PointEventService } from './service/point.event.service';
import { PointController } from './point.controller';
import { TypeOrmModule } from '@nestjs/typeorm';
import { TbPointPool } from '../entities/TbPointPool';
import { TbPointEvent } from '../entities/TbPointEvent';
import { TbServiceOperInfo } from '../entities/TbServiceOperInfo';
import { TbServiceOperLog } from '../entities/TbServiceOperLog';
import { TbPointEventDtls } from '../entities/TbPointEventDtls';
import { TbPointPoolSchedule } from '../entities/TbPointPoolSchedule';
import { TbUserPoint } from '../entities/TbUserPoint';
import { TbPointCheck } from "../entities/TbPointCheck";

@Module({
  imports: [
    TypeOrmModule.forFeature([
      TbPointEvent,
      TbPointPool,
      TbServiceOperInfo,
      TbServiceOperLog,
      TbPointEventDtls,
      TbUserPoint,
      TbPointPoolSchedule,
      TbPointCheck,
    ]),
    ConfigModule.forRoot(),
  ],
  controllers: [PointController],
  providers: [
    PointService,
    PointUseService,
    PointSaveService,
    PointCancelService,
    PointRecallService,
    PointSettleService,
    PointEventService,
  ],
  exports: [PointService],
})
export class PointModule {}
