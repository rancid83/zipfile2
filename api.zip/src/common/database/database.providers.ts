import { DataSource } from 'typeorm';
import { TbPointPool } from '../../entities/TbPointPool';

export const databaseProviders = [
  {
    provide: 'DATA_SOURCE',
    useFactory: async () => {
      const dataSource = new DataSource({
        type: 'mysql',
        entities: [
          __dirname + '/../**/*.entity{.ts,.js}',
          __dirname + '/../**/Tb*{.ts,.js}',
        ],
        synchronize: false,
        logging: true,
      });

      return dataSource.initialize();
    },
  },
];
