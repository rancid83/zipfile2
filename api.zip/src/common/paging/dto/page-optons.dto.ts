import { ApiPropertyOptional } from '@nestjs/swagger';
import { Type } from 'class-transformer';
import { IsEnum, IsInt, IsOptional, Max, Min } from 'class-validator';
import { Order } from '../interfaces/constants';

export class PageOptionsDto {
  @ApiPropertyOptional({ enum: Order, default: Order.ASC })
  // @IsEnum(Order)
  @IsOptional()
  readonly order?: Order = Order.ASC;

  @ApiPropertyOptional({
    minimum: 1,
    default: 1,
  })
  @Type(() => Number)
  @IsInt()
  @Min(1)
  @IsOptional()
  readonly page?: number = 1;

  @ApiPropertyOptional({
    minimum: 1,
    maximum: 50,
    default: 10,
  })
  @Type(() => Number)
  @IsInt()
  @Min(1)
  @Max(50)
  @IsOptional()
  readonly take?: number = 10;

  get skip(): number {
    return (this.page - 1) * this.take;
  }

  @ApiPropertyOptional({
    // minimum: 1,
    default: '2023-01-01',
  })
  @Type(() => String)
  @IsOptional()
  readonly startdate: '2023-01-01';

  @ApiPropertyOptional({
    // minimum: 1,
    default: '2023-01-31',
  })
  @Type(() => String)
  @IsOptional()
  readonly enddate: '2023-01-31';

  @ApiPropertyOptional({
    // minimum: 1,
    default: 'USE,SAVE,RECALL,CANCEL,ALL',
  })
  @Type(() => String)
  @IsOptional()
  readonly pointStateCd: string;

  @ApiPropertyOptional({
    // minimum: 1,
    default: 'DAILY,REWARDS_DRAW,REWARDS_BUY',
  })
  @Type(() => String)
  @IsOptional()
  readonly eventTypeCd: string;

  @ApiPropertyOptional({
    // minimum: 1,
    default: 'NORMAL,X2,X3,D+15,D+END',
  })
  @Type(() => String)
  @IsOptional()
  readonly actionTypeCd: string;
}
