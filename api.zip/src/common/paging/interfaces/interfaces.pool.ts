import { PageOptionsPoolDto } from '../dto/page-optons.pool.dto';

export interface PageMetaPoolDtoParameters {
  pageOptionsPoolDto: PageOptionsPoolDto;
  itemCount: number;
}
