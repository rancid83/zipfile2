import {
  Column,
  CreateDateColumn,
  Entity,
  UpdateDateColumn,
} from 'typeorm';

@Entity('tb_user_point', { schema: 'musicow_point' })
export class TbUserPoint {
  @Column('bigint', { primary: true, name: 'user_no', comment: '사용자 번호' })
  userNo: number;

  @Column('float', {
    name: 'amt_total_point',
    comment: '포인트잔액',
    precision: 12,
    default: () => "'0'",
  })
  amtTotalPoint: number;

  @CreateDateColumn()
  recDate: Date | null;

  @Column('varchar', { name: 'rec_user_id', nullable: true, length: 32 })
  recUserId: string | null;

  @UpdateDateColumn()
  modDate: Date | null;

  @Column('varchar', { name: 'mod_user_id', nullable: true, length: 32 })
  modUserId: string | null;
}
