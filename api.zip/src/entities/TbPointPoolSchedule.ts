import { Column, Entity, PrimaryGeneratedColumn } from 'typeorm';

@Entity('tb_point_pool_schedule', { schema: 'musicow_point' })
export class TbPointPoolSchedule {
  @PrimaryGeneratedColumn({
    type: 'int',
    name: 'event_schedule_id',
    comment: '이벤트스케줄아이디',
  })
  eventScheduleId: number;

  @Column('int', {
    name: 'point_pool_id',
    nullable: true,
    comment: '포인트풀아이디',
  })
  pointPoolId: number | null;

  @Column('varchar', {
    name: 'schedule_name',
    nullable: true,
    comment: '스케줄명',
    length: 255,
  })
  scheduleName: string | null;

  @Column('varchar', {
    name: 'schedule_date',
    nullable: true,
    comment: '스케줄일자',
    length: 32,
  })
  scheduleDate: string | null;

  @Column('varchar', {
    name: 'action_type_cd',
    nullable: true,
    comment: '액션타입코드',
    length: 32,
  })
  actionTypeCd: string | null;

  @Column('varchar', {
    name: 'use_yn',
    nullable: true,
    comment: '사용여부',
    length: 32,
  })
  useYn: string | null;

  @Column('datetime', { name: 'rec_date', nullable: true, comment: '등록일자' })
  recDate: Date | null;

  @Column('varchar', {
    name: 'rec_user_id',
    nullable: true,
    comment: '등록자아이디',
    length: 32,
  })
  recUserId: string | null;

  @Column('datetime', { name: 'mod_date', nullable: true, comment: '수정일자' })
  modDate: Date | null;

  @Column('varchar', {
    name: 'mod_usesr_id',
    nullable: true,
    comment: '수정일자',
    length: 32,
  })
  modUsesrId: string | null;
}
