import { Column, Entity, OneToMany } from 'typeorm';
import { TbComnCodeDtls } from './TbComnCodeDtls';

@Entity('tb_comn_code', { schema: 'musicow_point' })
export class TbComnCode {
  @Column('varchar', {
    primary: true,
    name: 'comm_grp_cd',
    comment: '공통그룹코드',
    length: 32,
  })
  commGrpCd: string;

  @Column('varchar', {
    name: 'comm_grp_cd_nm',
    comment: '공통그룹코드명',
    length: 512,
  })
  commGrpCdNm: string;

  @Column('varchar', {
    name: 'rmk_ctnts',
    nullable: true,
    comment: '비고내용',
    length: 1024,
  })
  rmkCtnts: string | null;

  @Column('varchar', {
    name: 'use_yn',
    nullable: true,
    comment: '사용여부',
    length: 32,
  })
  useYn: string | null;

  @Column('datetime', { name: 'rec_date', nullable: true, comment: '등록일자' })
  recDate: Date | null;

  @Column('varchar', {
    name: 'rec_user_id',
    nullable: true,
    comment: '등록자아이디',
    length: 32,
  })
  recUserId: string | null;

  @Column('datetime', { name: 'mod_date', nullable: true, comment: '수정일자' })
  modDate: Date | null;

  @Column('varchar', {
    name: 'mod_user_id',
    nullable: true,
    comment: '수정자아이디',
    length: 32,
  })
  modUserId: string | null;

  @OneToMany(
    () => TbComnCodeDtls,
    (tbComnCodeDetail) => tbComnCodeDetail.commGrpCd2,
  )
  TbComnCodeDetails: TbComnCodeDtls[];
}
