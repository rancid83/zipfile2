import {
  Column,
  CreateDateColumn,
  Entity,
  Index,
  JoinColumn,
  ManyToOne,
  PrimaryGeneratedColumn,
  Unique,
  UpdateDateColumn,
} from 'typeorm';
import { TbPointPool } from './TbPointPool';
@Index('tb_point_event_tb_user_point_user_no_fk', ['userNo'], {})
@Index('tb_point_event_tb_point_pool_point_pool_id_fk', ['pointPoolId'], {})
@Entity('tb_point_event', { schema: 'musicow_point' })
@Unique(['serialNumber'])
export class TbPointEvent {
  @PrimaryGeneratedColumn({
    type: 'bigint',
    name: 'point_event_seq',
    comment: '적립내역 일련번호',
  })
  pointEventSeq: number;

  @Column('bigint', { name: 'point_pool_id', comment: '포인트풀 아이디' })
  pointPoolId: number;

  @Column('varchar', {
    name: 'serial_number',
    comment: '요청일련번호',
    length: 32,
    unique: true,
  })
  serialNumber: string;

  @Column('bigint', { name: 'user_no', comment: '사용자 번호' })
  userNo: number;

  @Column('varchar', {
    name: 'point_state_cd',
    comment: '포인트상태코드',
    length: 32,
  })
  pointStateCd: string;

  @Column('varchar', {
    name: 'event_type_cd',
    comment: '적립타입코드',
    length: 32,
  })
  eventTypeCd: string;
  @Column('varchar', {
    name: 'action_type_cd',
    comment: '액션타입코드',
    length: 32,
  })
  actionTypeCd: string;

  @Column('varchar', {
    name: 'order_type_cd',
    comment: '주문타입코드',
    length: 32,
  })
  orderTypeCd: string;

  @Column('varchar', {
    name: 'order_no',
    comment: '주문번호',
    length: 32,
  })
  orderNo: string;
  @Column('varchar', { name: 'event_ctnts', comment: '적립내용', length: 1024 })
  eventCtnts: string;

  @Column('float', {
    name: 'amt_event_point',
    comment: '적립 포인트',
    precision: 12,
    default: () => "'0'",
  })
  amtEventPoint: number;

  @Column('float', {
    name: 'amt_use_point',
    nullable: true,
    comment: '사용포인트',
    precision: 12,
    default: () => "'0'",
  })
  amtUsePoint: number | null;

  @Column('float', {
    name: 'amt_remain_point',
    nullable: true,
    comment: '잔액포인트',
    precision: 12,
    default: () => "'0'",
  })
  amtRemainPoint: number | null;

  // @Column('datetime', {
  //   name: 'exp_date',
  //   nullable: true,
  //   comment: '포인트 만료일자',
  // })
  @CreateDateColumn({ name: 'exp_date', type: 'timestamp' })
  expDate: Date | null;

  @CreateDateColumn({ name: 'rec_date', type: 'timestamp' })
  recDate: Date;

  @Column('varchar', {
    name: 'rec_user_id',
    nullable: true,
    comment: '등록자 아이디',
    length: 32,
  })
  recUserId: string | null;

  @UpdateDateColumn({ name: 'mod_date', type: 'timestamp' })
  modDate: Date;

  @Column('varchar', {
    name: 'mod_user_id',
    nullable: true,
    comment: '수정자 아이디',
    length: 32,
  })
  modUserId: string | null;

  @ManyToOne(() => TbPointPool, (tbPointPool) => tbPointPool.tbPointEvents, {
    onDelete: 'NO ACTION',
    onUpdate: 'NO ACTION',
  })
  @JoinColumn([{ name: 'point_pool_id', referencedColumnName: 'pointPoolId' }])
  pointPool: TbPointPool;
}
