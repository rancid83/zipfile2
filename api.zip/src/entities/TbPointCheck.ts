import { Column, Entity } from "typeorm";

@Entity("tb_point_check", { schema: "musicow_point" })
export class TbPointCheck {
  @Column("varchar", {
    primary: true,
    name: "event_type_cd",
    comment: "이벤트타입코드",
    length: 32,
  })
  eventTypeCd: string;

  @Column("int", { primary: true, name: "user_no", comment: "사용자번호" })
  userNo: number;

  @Column("varchar", {
    primary: true,
    name: "regdate",
    comment: "출석일자(YYYYMMDD)",
    length: 32,
  })
  regdate: string;
}
