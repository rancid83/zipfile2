import { Column, Entity } from 'typeorm';

@Entity('tb_service_oper_log', { schema: 'musicow_point' })
export class TbServiceOperLog {
  @Column('bigint', {
    primary: true,
    name: 'sys_log_seq',
    comment: '로그일련번호',
  })
  sysLogSeq: string;

  @Column('bigint', { name: 'service_id', comment: '서비스아이디' })
  serviceId: string;

  @Column('varchar', {
    name: 'mngr_id',
    nullable: true,
    comment: '관리자 아이디',
    length: 32,
  })
  mngrId: string | null;

  @Column('varchar', {
    name: 'log_type_cd',
    nullable: true,
    comment: '시스템 로그타입',
    length: 32,
  })
  logTypeCd: string | null;

  @Column('varchar', {
    name: 'log_ctnts',
    nullable: true,
    comment: '로그내용',
    length: 1024,
  })
  logCtnts: string | null;

  @Column('varchar', {
    name: 'rec_date',
    nullable: true,
    comment: '등록일자',
    length: 32,
  })
  recDate: string | null;

  @Column('datetime', {
    name: 'rec_user_id',
    nullable: true,
    comment: '등록자아이디',
  })
  recUserId: Date | null;

  @Column('varchar', {
    name: 'mod_date',
    nullable: true,
    comment: '수정일자',
    length: 32,
  })
  modDate: string | null;

  @Column('datetime', {
    name: 'mod_user_id',
    nullable: true,
    comment: '수정자아이디',
  })
  modUserId: Date | null;
}
