import { Column, Entity, JoinColumn, ManyToOne } from 'typeorm';
import { TbComnCode } from './TbComnCode';

@Entity('tb_comn_code_dtls', { schema: 'musicow_point' })
export class TbComnCodeDtls {
  @Column('varchar', {
    primary: true,
    name: 'comm_cd',
    comment: '공통코드',
    length: 32,
  })
  commCd: string;

  @Column('varchar', {
    primary: true,
    name: 'comm_grp_cd',
    comment: '공통그룹코드',
    length: 32,
  })
  commGrpCd: string;

  @Column('varchar', {
    name: 'comm_cd_nm',
    nullable: true,
    comment: '공통코드명',
    length: 512,
  })
  commCdNm: string | null;

  @Column('varchar', {
    name: 'ref_1_val',
    nullable: true,
    comment: '참조1값',
    length: 32,
  })
  ref_1Val: string | null;

  @Column('varchar', {
    name: 'ref_2_val',
    nullable: true,
    comment: '참조1값',
    length: 32,
  })
  ref_2Val: string | null;

  @Column('varchar', {
    name: 'ref_3_val',
    nullable: true,
    comment: '참조1값',
    length: 32,
  })
  ref_3Val: string | null;

  @Column('varchar', {
    name: 'ref_4_val',
    nullable: true,
    comment: '참조1값',
    length: 32,
  })
  ref_4Val: string | null;

  @Column('varchar', {
    name: 'ref_5_val',
    nullable: true,
    comment: '참조1값',
    length: 32,
  })
  ref_5Val: string | null;

  @Column('int', {
    name: 'sort_ordr_no',
    nullable: true,
    comment: '정렬순서번호',
  })
  sortOrdrNo: number | null;

  @Column('varchar', {
    name: 'use_yn',
    nullable: true,
    comment: '사용여부',
    length: 32,
  })
  useYn: string | null;

  @Column('datetime', { name: 'rec_date', nullable: true, comment: '등록일자' })
  recDate: Date | null;

  @Column('varchar', {
    name: 'rec_user_id',
    nullable: true,
    comment: '등록자아이디',
    length: 32,
  })
  recUserId: string | null;

  @Column('datetime', { name: 'mod_date', nullable: true, comment: '수정일자' })
  modDate: Date | null;

  @Column('varchar', {
    name: 'mod_user_id',
    nullable: true,
    comment: '수정자아이디',
    length: 32,
  })
  modUserId: string | null;

  @ManyToOne(() => TbComnCode, (tbComnCode) => tbComnCode.TbComnCodeDetails, {
    onDelete: 'NO ACTION',
    onUpdate: 'NO ACTION',
  })
  @JoinColumn([{ name: 'comm_grp_cd', referencedColumnName: 'commGrpCd' }])
  commGrpCd2: TbComnCode;
}
