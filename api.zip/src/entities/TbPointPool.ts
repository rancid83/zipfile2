import {
  Column,
  Entity,
  OneToMany,
  PrimaryGeneratedColumn,
} from 'typeorm';
import { TbPointEvent } from './TbPointEvent';

@Entity('tb_point_pool', { schema: 'musicow_point' })
export class TbPointPool {
  @PrimaryGeneratedColumn({
    type: 'bigint',
    name: 'point_pool_id',
    comment: '포인트풀 아이디',
  })
  pointPoolId: number;

  @Column('bigint', {
    name: 'service_id',
    nullable: true,
    comment: '서비스 아이디',
  })
  serviceId: number | null;
  @Column('varchar', {
    name: 'point_pool_type_cd',
    nullable: true,
    comment: '포인트풀 타입',
    length: 32,
  })
  pointPoolTypeCd: string | null;
  @Column('varchar', {
    name: 'event_type_cd',
    nullable: true,
    comment: '이벤트 타입',
    length: 32,
  })
  eventType: string | null;
  @Column('varchar', {
    name: 'point_pool_type_cd',
    nullable: true,
    comment: '포인트풀 타입',
    length: 32,
  })
  actionType: string | null;
  @Column('varchar', {
    name: 'event_ctnts',
    nullable: true,
    comment: '이벤트 내용',
    length: 1024,
  })
  eventCtnts: string | null;

  @Column('datetime', { name: 'startdate', comment: '이벤트 시작일' })
  startdate: string;

  @Column('datetime', {
    name: 'enddate',
    nullable: true,
    comment: '이벤트 종료일',
  })
  enddate: string | null;

  @Column('int', {
    name: 'amt_total',
    comment: '예산 총액',
    default: () => "'0'",
  })
  amtTotal: number;

  @Column('int', {
    name: 'amt_remain',
    comment: '잔여 금액',
    default: () => "'0'",
  })
  amtRemain: number;

  @Column('int', {
    name: 'amt_save',
    comment: '적립 금액',
    default: () => "'0'",
  })
  amtSave: number;
  @Column('int', {
    name: 'amt_save_min',
    comment: '적립 최소금액',
    default: () => "'0'",
  })
  amtSaveMin: number;
  @Column('int', {
    name: 'amt_save_max',
    comment: '적립 최대금액',
    default: () => "'0'",
  })
  amtSaveMax: number;
  @Column('int', {
    name: 'validity_days',
    comment: '사용유효일수',
    default: () => "'0'",
  })
  validityDays: number;

  // @CreateDateColumn({ name: 'rec_date' })
  // recDate: Date;

  @Column('varchar', {
    name: 'use_yn',
    nullable: true,
    comment: '사용여부',
    length: 1024,
  })
  useYn: string | null;

  @Column('varchar', {
    name: 'rec_user_id',
    nullable: true,
    comment: '등록자 아이디',
    length: 32,
  })
  recUserId: string | 'system';

  //@Column('datetime', { name: 'mod_date', nullable: true, comment: '수정일자' })
  // @UpdateDateColumn({ name: 'mod_date' })
  // modDate: Date;

  @Column('varchar', {
    name: 'mod_user_id',
    nullable: true,
    comment: '수정자 아이디',
    length: 32,
  })
  modUserId: string | 'system';


  @OneToMany(() => TbPointEvent, (tbPointEvent) => tbPointEvent.pointPool)
  tbPointEvents: TbPointEvent[];
}
