import { Column, Entity } from 'typeorm';

@Entity('tb_mngr_mastr', { schema: 'musicow_point' })
export class TbMngrMastr {
  @Column('bigint', {
    primary: true,
    name: 'service_id',
    comment: '서비스아이디',
  })
  serviceId: string;

  @Column('varchar', {
    primary: true,
    name: 'mngr_id',
    comment: '관리자 아이디',
    length: 32,
  })
  mngrId: string;

  @Column('varchar', {
    name: 'password',
    nullable: true,
    comment: '비밀번호',
    length: 512,
  })
  password: string | null;

  @Column('varchar', {
    name: 'mngr_nm',
    nullable: true,
    comment: '관리자이름',
    length: 32,
  })
  mngrNm: string | null;

  @Column('datetime', { name: 'rec_date', nullable: true, comment: '등록일자' })
  recDate: Date | null;

  @Column('varchar', {
    name: 'rec_user_id',
    nullable: true,
    comment: '등록자아이디',
    length: 32,
  })
  recUserId: string | null;

  @Column('datetime', { name: 'mod_date', nullable: true, comment: '수정일자' })
  modDate: Date | null;

  @Column('varchar', {
    name: 'mod_user_id',
    nullable: true,
    comment: '수정자아이디',
    length: 32,
  })
  modUserId: string | null;
}
