import {
  Column,
  CreateDateColumn,
  Entity,
  PrimaryGeneratedColumn,
  UpdateDateColumn,
} from 'typeorm';

@Entity('tb_point_pool_dtls', { schema: 'musicow_point' })
export class TbPointPoolDtls {
  @PrimaryGeneratedColumn({
    type: 'bigint',
    name: 'point_pool_log_seq',
    comment: '포인트풀내역 일련번호',
  })
  pointPoolLogSeq: string;


  @Column('varchar', {
    name: 'pool_status_cd',
    comment: '포인트풀 상태코드',
    length: 32,
  })
  poolStatusCd: string;

  @Column('int', {
    name: 'pool_change_total',
    nullable: true,
    comment: '포인트풀 변경금액',
  })
  poolChangeTotal: number | null;

  @CreateDateColumn({ name: 'rec_date' })
  recDate: Date;

  @Column('int', {
    name: 'rec_user_id',
    nullable: true,
    comment: '등록자 아이디',
  })
  recUserId: number | null;

  @UpdateDateColumn({ name: 'mod_date' })
  modDate: Date;

  @Column('int', {
    name: 'mod_user_id',
    nullable: true,
    comment: '수정자 아이디',
  })
  modUserId: number | null;

}
