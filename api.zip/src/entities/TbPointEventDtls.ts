import {
  Column,
  CreateDateColumn,
  Entity,
  Index, PrimaryGeneratedColumn,
  UpdateDateColumn,
} from 'typeorm';
@Index(
  'tb_point_event_dtls_tb_point_event_point_event_seq_fk',
  ['pointEventSeq'],
  {},
)
@Entity('tb_point_event_dtls', { schema: 'musicow_point' })
export class TbPointEventDtls {
  @PrimaryGeneratedColumn({
    type: 'bigint',
    name: 'point_event_dtls_seq',
    comment: '적립내역 일련번호',
  })
  @Column('bigint', { primary: true, name: 'point_event_dtls_seq' })
  pointEventDtlsSeq: number;

  @Column('bigint', {
    name: 'save_point_event_dtls_seq',
    nullable: true,
    comment: '포인트적립 일련번호',
  })
  savePointEventDtlsSeq: number;

  @Column('bigint', {
    name: 'point_event_seq',
    nullable: true,
    comment: '사용내역 일련번호',
  })
  pointEventSeq: number;

  @Column('varchar', {
    name: 'serial_number',
    comment: '요청일련번호',
    length: 32,
  })
  serialNumber: string;

  @Column('bigint', { name: 'user_no', comment: '사용자 번호' })
  userNo: number;

  @Column('varchar', {
    name: 'point_state_cd',
    nullable: true,
    comment: '포인트상태코드 ',
    length: 32,
  })
  pointStateCd: string | null;

  @Column('float', {
    name: 'amt_use_point',
    nullable: true,
    comment: '사용포인트',
    precision: 12,
  })
  amtUsePoint: number | null;

  @Column('datetime', {
    name: 'remain_exp_date',
    comment: '포인트잔액 만료일자',
  })
  remainExpDate: string;

  @CreateDateColumn({ name: 'rec_date' })
  recDate: Date;

  @Column('varchar', {
    name: 'rec_user_id',
    nullable: true,
    comment: '등록자아이디',
    length: 32,
  })
  recUserId: string | null;

  @UpdateDateColumn({ name: 'mod_date' })
  modDate: Date;

  @Column('varchar', {
    name: 'mod_user_id',
    nullable: true,
    comment: '수정자아이디',
    length: 32,
  })
  modUserId: string | null;

}
