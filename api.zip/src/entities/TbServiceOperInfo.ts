import { Column, Entity, PrimaryGeneratedColumn } from 'typeorm';

@Entity('tb_service_oper_info', { schema: 'musicow_point' })
export class TbServiceOperInfo {
  @PrimaryGeneratedColumn({
    type: 'bigint',
    name: 'service_id',
    comment: '서비스아이디',
  })
  serviceId: string;

  @Column('int', {
    name: 'point_pool_colct_type',
    comment: '배치 수집주기(초)',
  })
  pointPoolColctType: number;

  @Column('int', {
    name: 'account_inquire_type',
    comment: '법인계좌 조회주기(초)',
  })
  accountInquireType: number;

  @Column('varchar', {
    name: 'account_limit_amount',
    nullable: true,
    comment: '법인계좌 설정금액',
    length: 32,
  })
  accountLimitAmount: string | null;

  @Column('varchar', {
    name: 'jira_api_key',
    nullable: true,
    comment: 'JIRA API KEY',
    length: 32,
  })
  jiraApiKey: string | null;

  @Column('varchar', {
    name: 'oper_state_cd',
    comment: '운영상태 코드',
    length: 32,
  })
  operStateCd: string;

  @Column('datetime', { name: 'rec_date', comment: '등록일자' })
  recDate: Date;

  @Column('varchar', {
    name: 'rec_user_id',
    comment: '등록자 아이디',
    length: 32,
  })
  recUserId: string;

  @Column('datetime', { name: 'mod_date', comment: '수정일자' })
  modDate: Date;

  @Column('varchar', {
    name: 'mod_user_id',
    comment: '수정자 아이디',
    length: 32,
  })
  modUserId: string;
}
