import {
  Controller,
  Post,
  UseGuards,
  Req,
  Request,
} from '@nestjs/common';
import { AuthService } from './auth.service';
import { CreateAuthDto } from './dto/create-auth.dto';
import { LocalAuthGuard } from './local-auth.guard';
import {
  ApiCreatedResponse,
  ApiOperation,
  ApiResponse,
} from '@nestjs/swagger';
@Controller(['auth','//auth'])
export class AuthController {
  constructor(private readonly authService: AuthService) {}

  /**
   * 포인트시스템 로그인 JWT 토큰발급 [ IF-AUTH_01 ]
   * @param CreateAuthDto - 포인트시스템 로그인 JWT 토큰발급 DTO
   * @return token JWT 토큰
   * @see ""
   */
  // @UseGuards(AuthGuard('local'))
  @UseGuards(LocalAuthGuard)
  @Post('login')
  @ApiOperation({
    summary: '포인트시스템 로그인 JWT 토큰발급  [ IF-AUTH_01 ]',
    description: '포인트시스템에 로그인하여 JWT 토큰을 발급받는다.',
  })
  @ApiResponse({
    status: 401,
    description: '인증실패',
  })
  @ApiCreatedResponse({
    description:
      '포인트시스템 어드민에서 생성된 포인트시스템에 로그인하여 username, userpassword 로 JWT 토큰을 발급받는다.',
    type: CreateAuthDto,
  })
  async login(@Req() request: Request, @Request() req) {
    return this.authService.login(req.user);
  }

  // @UseGuards(JwtAuthGuard)
  // @Get('profile')
  // getProfile(@Request() req) {
  //   return req.user;
  // }
  //   @Get('/bcrypt')
  //   async bcrypt() {
  //     const saltOrRounds = 10;
  //     const password = 'random_password';
  //     const hash = await bcrypt.hash(password, saltOrRounds);
  //     const salt = await bcrypt.genSalt();
  //     const isMatch = await bcrypt.compare(password, hash);
  //     console.log(isMatch);
  //     return this.authService.bcrypt();
  //   }
}
