export const jwtConstants = {
  secret: 'asasa',
};
