import { ApiProperty } from '@nestjs/swagger';

export class CreateAuthDto {
  @ApiProperty({
    example: 'musicow-point-api-dev',
    description: 'username',
    required: true,
  })
  username!: string;

  @ApiProperty({ example: 'fr23fjwed0f9j!@Dwd2', description: 'password', required: true })
  password!: string;
}
