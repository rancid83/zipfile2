import { Injectable } from '@nestjs/common';
import { JwtService } from '@nestjs/jwt';
import { ConfigService } from '@nestjs/config';
import { InjectRepository } from '@nestjs/typeorm';
import { DataSource, Repository } from 'typeorm';
import { TbMngrMastr } from '../entities/TbMngrMastr';
@Injectable()
export class AuthService {
  constructor(
    @InjectRepository(TbMngrMastr)
    private mngrMasrRepository: Repository<TbMngrMastr>,
    private dataSource: DataSource,
    private jwtService: JwtService,
    private readonly config: ConfigService, // ConfigService 불러오기
  ) {}

  async validateUser(username: string, pass: string): Promise<any> {
    console.log('username', username);
    console.log('pass', pass);

    // querybuilder 사용내역 조회
    const queryBuilder = this.dataSource
      .getRepository(TbMngrMastr)
      .createQueryBuilder('mngrMastr');

    const user = await queryBuilder
      .where('mngrMastr.mngr_id = :mngrId', {
        mngrId: username,
      })
      .andWhere(
        `mngrMastr.password = HEX(AES_ENCRYPT( :password , SHA2('point-system', 256))) `,
        {
          password: pass,
        },
      )
      .select('mngr_id', 'mngr_id')
      .getRawOne();

    console.log(user);
    //
    // const user = await this.mngrMasrRepository.findOne({
    //   where: { mngrId: username },
    // });

    if (user) {
      const { password, ...result } = user;
      return result;
    }
    return null;
  }

  async login(user: any) {
    console.log(process.env.JWT_SECRET_KEY);
    const payload = { username: user.username, sub: user.userId };

    // const token = this.jwtService.sign(payload, jwtConstants.secret);

    return {
      access_token: this.jwtService.sign(payload, {
        secret: process.env.JWT_SECRET_KEY,
      }),
    };
  }
}
