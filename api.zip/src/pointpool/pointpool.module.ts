import { Module } from '@nestjs/common';
import { PointpoolService } from './pointpool.service';

import { PointpoolController } from './pointpool.controller';
import { TypeOrmModule } from '@nestjs/typeorm';
import { TbPointPool } from '../entities/TbPointPool';

@Module({
  imports: [TypeOrmModule.forFeature([TbPointPool])],
  controllers: [PointpoolController],
  providers: [PointpoolService],
  exports: [PointpoolService],
})
export class PointpoolModule {}
