import {
  Controller,
  Get,
  Post,
  Body,
  Param,
  UseGuards,
  ForbiddenException,
} from '@nestjs/common';
import { PointpoolService } from './pointpool.service';
import { JwtAuthGuard } from '../auth/jwt-auth.guard';
import { ApiOperation, ApiResponse } from '@nestjs/swagger';
import { PageOptionsPoolDto } from '../common/paging/dto/page-optons.pool.dto';

@Controller(['pointpool','//pointpool'])
export class PointpoolController {
  constructor(private readonly pointpoolService: PointpoolService) {}
  /**
   * 포인트풀 상세 조회 [ IF-POINT_03 ]
   * @param UsePointDto - 포인트풀 상세 조회를 위한 정보 DTO
   * @return
   * @see ""
   */
  @ApiOperation({ summary: '포인트풀 상세 조회 [ IF-POINT_03 ]' })
  @ApiResponse({
    status: 200,
    description: '포인트풀 상세 조회 [ IF-POINT_03 ]',
  })
  @ApiResponse({ status: 403, description: 'Forbidden.' })
  @UseGuards(JwtAuthGuard)
  @Get(':id')
  findOne(@Param('id') id: number) {
    const result = this.pointpoolService.findOne(id);
    if (result) {
      return result;
    } else {
      throw new ForbiddenException();
    }
  }
  /**
   *  포인트풀 목록 조회 [ IF-POINT_02 ]
   * @param UsePointDto - 포인트풀 목록 조회 DTO
   * @return boolean 목록 조회 여부
   * @see ""
   */
  @ApiOperation({ summary: '포인트풀 목록 조회 [ IF-POINT_02 ]' })
  @ApiResponse({
    status: 200,
    description: '포인트풀 목록',
  })
  @ApiResponse({ status: 403, description: 'Forbidden.' })
  @UseGuards(JwtAuthGuard)
  @Post()
  findAll(@Body() pageOptionsPoolDto: PageOptionsPoolDto) {
    const result = this.pointpoolService.findAll(pageOptionsPoolDto) || false;
    if (result) {
      return result;
    } else {
      throw new ForbiddenException();
    }
  }
  /**
   * 포인트풀 생성 [ IF-POINT_01 ]
   * @param CreatePointpoolDto - 포인트풀 생성 DTO
   * @return
   * @see ""
   */
  // @ApiOperation({ summary: '포인트풀 생성 [ IF-POINT_01 ]' })
  // @ApiResponse({
  //   status: 201,
  //   description: '포인트풀 생성 [ IF-POINT_01 ]',
  // })
  // @ApiResponse({ status: 403, description: 'Forbidden.' })
  // @Post()
  // async create(@Body() pointpoolData: CreatePointpoolDto) {
  //   const result = await this.pointpoolService.create(pointpoolData);
  //   return {
  //     success: true,
  //     code: '0',
  //     data: result.pointPoolId,
  //   };
  // }
}