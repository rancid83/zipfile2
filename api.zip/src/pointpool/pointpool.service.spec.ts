import { Test, TestingModule } from '@nestjs/testing';
import { PointpoolService } from './pointpool.service';

describe('PointpoolService', () => {
  let service: PointpoolService;

  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
      providers: [PointpoolService],
    }).compile();

    service = module.get<PointpoolService>(PointpoolService);
  });

  it('should be defined', () => {
    expect(service).toBeDefined();
  });
});
