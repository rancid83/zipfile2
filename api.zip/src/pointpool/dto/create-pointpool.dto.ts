import { ApiProperty } from '@nestjs/swagger';
import { IsNotEmpty, IsNumber, IsString } from 'class-validator';

export class CreatePointpoolDto {
  @IsNotEmpty()
  @ApiProperty({
    example: '1',
    description: '서비스아이디',
  })
  public serviceId: number;

  @IsString()
  @IsNotEmpty()
  @ApiProperty({
    example: 'REQ220109000001',
    description: '요청일련번호',
  })
  public serialNumber: string;

  @IsString()
  @IsNotEmpty()
  @ApiProperty({
    example: 'DAILY',
    description: 'eventTypeCd',
  })
  public eventType: string;

  @IsString()
  @IsNotEmpty()
  @ApiProperty({
    example: 'NORMAL',
    description: 'actionTypeCd ',
  })
  public actionType: string;

  @IsString()
  @IsNotEmpty()
  @ApiProperty({
    example: '가입이벤트 포인트풀 생성',
    description: '이벤트 내용',
  })
  public eventCtnts: string;

  @IsString()
  @IsNotEmpty()
  @ApiProperty({
    example: '2022-12-12',
    description: '이벤트 시작일',
  })
  public startdate: string;

  @IsString()
  @IsNotEmpty()
  @ApiProperty({
    example: '2022-12-12',
    description: '이벤트 종료일',
  })
  public enddate: string;

  @IsNumber()
  @IsNotEmpty()
  @ApiProperty({
    example: '5000000',
    description: '예산 총액',
  })
  public amtTotal: number;

  @IsNumber()
  @IsNotEmpty()
  @ApiProperty({
    example: '5000',
    description: '포인트지급금액',
  })
  public amtSave: number;
  @IsNumber()
  @IsNotEmpty()
  @ApiProperty({
    example: '180',
    description: '포인트사용유효일수',
  })
  public validityDays: number;

  public recUserId: string;
  public modUserId: string;
}
