import { Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { DataSource, Repository } from 'typeorm';
import { TbPointPool } from '../entities/TbPointPool';
import { CreatePointpoolDto } from './dto/create-pointpool.dto';
import { PageOptionsPoolDto } from '../common/paging/dto/page-optons.pool.dto';
import { PagingDto } from '../common/paging/dto/paging.dto';
import { PageMetaPoolDto } from '../common/paging/dto/page-meta.pool.dto';

@Injectable()
export class PointpoolService {
  constructor(
    @InjectRepository(TbPointPool)
    private pointPoolRepository: Repository<TbPointPool>,
    private dataSource: DataSource,
  ) {
    this.pointPoolRepository = pointPoolRepository;
  }
  /**
   * 포인트풀 상세 조회 [ IF-POINT_03 ]
   * @param UsePointDto - 포인트풀 상세 조회를 위한 정보 DTO
   * @return
   * @see ""
   */
  async findOne(id: number) {
    return this.pointPoolRepository.findOne({ where: { pointPoolId: id } });
  }
  /**
   *  포인트풀 목록 조회 [ IF-POINT_02 ]
   * @param UsePointDto - 포인트풀 목록 조회 DTO
   * @return boolean 목록 조회 여부
   * @see ""
   */
  async findAll(
    pageOptionsPoolDto: PageOptionsPoolDto,
  ): Promise<PagingDto<TbPointPool>> {
    const queryBuilder = this.dataSource
      .getRepository(TbPointPool)
      .createQueryBuilder('pool');

    await queryBuilder
      .skip(pageOptionsPoolDto.skip)
      .take(pageOptionsPoolDto.take)
      .getMany();

    const itemCount = await queryBuilder.getCount();
    const { entities } = await queryBuilder.getRawAndEntities();

    console.log(entities);
    const pageMetaPoolDto = new PageMetaPoolDto({
      pageOptionsPoolDto,
      itemCount,
    });
    return new PagingDto(entities, pageMetaPoolDto, []);
  }
  /**
   * 사용자 포인트 적립 [ IF-POINT_06 ]
   * @param UsePointDto - 이벤트 포인트 적립을 위한 정보 DTO
   * @return boolean 적립 처리 여부
   * @see ""
   */
  async create(createPointpoolDto: CreatePointpoolDto): Promise<TbPointPool> {
    const pool = this.pointPoolRepository.create(createPointpoolDto);
    pool.recUserId = createPointpoolDto.recUserId || 'system';
    pool.modUserId = createPointpoolDto.modUserId || 'system';
    pool.amtRemain = createPointpoolDto.amtTotal;
    pool.amtSave = createPointpoolDto.amtSave;
    pool.eventType = createPointpoolDto.eventType;
    pool.actionType = createPointpoolDto.actionType;
    await this.pointPoolRepository.save(pool); // db에 만들어진 객체를 저장
    console.log(pool);
    return pool;
  }
}
