import { Test, TestingModule } from '@nestjs/testing';
import { PointpoolController } from './pointpool.controller';
import { PointpoolService } from './pointpool.service';

describe('PointpoolController', () => {
  let controller: PointpoolController;

  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
      controllers: [PointpoolController],
      providers: [PointpoolService],
    }).compile();

    controller = module.get<PointpoolController>(PointpoolController);
  });

  it('should be defined', () => {
    expect(controller).toBeDefined();
  });
});
