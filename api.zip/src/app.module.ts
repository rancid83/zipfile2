import { MiddlewareConsumer, Module } from '@nestjs/common';
import { LoggerMiddleware } from './common/middleware/logger.middleware';
import { AppController } from './app.controller';
import { AuthController } from './auth/auth.controller';
import { PointController } from './point/point.controller';
import { PointpoolController } from './pointpool/pointpool.controller';
import { AppService } from './app.service';
import { ConfigModule, ConfigService } from '@nestjs/config';
import { AuthService } from './auth/auth.service';
import { JwtService } from '@nestjs/jwt';
import { PointService } from './point/service/point.service';
import { PointUseService } from './point/service/point.use.service';
import { PointSaveService } from './point/service/point.save.service';
import { PointCancelService } from './point/service/point.cancel.service';
import { PointRecallService } from './point/service/point.recall.service';
import { PointSettleService } from './point/service/point.settle.service';
import { PointEventService } from './point/service/point.event.service';
import { PointModule } from './point/point.module';
import { AuthModule } from './auth/auth.module';
import { PointpoolModule } from './pointpool/pointpool.module';
import { PointpoolService } from './pointpool/pointpool.service';
import { TbPointEvent } from './entities/TbPointEvent';
import { TypeOrmModule } from '@nestjs/typeorm';
import { TbPointPool } from './entities/TbPointPool';
import { TbServiceOperInfo } from './entities/TbServiceOperInfo';
import { TbServiceOperLog } from './entities/TbServiceOperLog';
import { TbPointEventDtls } from './entities/TbPointEventDtls';
import { TbUserPoint } from './entities/TbUserPoint';
import { TbMngrMastr } from './entities/TbMngrMastr';
import { TbPointPoolSchedule } from './entities/TbPointPoolSchedule';
import { TbPointCheck } from "./entities/TbPointCheck";

@Module({
  imports: [
    AuthModule,
    PointModule,
    PointpoolModule,
    // ConfigModule.forRoot({
    //   load: [appConfiguration],
    //   isGlobal: true
    // }),
    ConfigModule.forRoot({
      isGlobal: true,
    }),

    TypeOrmModule.forRoot({
      type: 'mysql',

      // host: 'musicow-point.csjyhhlhcodz.ap-northeast-2.rds.amazonaws.com',
      // port: 3306,
      // username: 'mupoint',
      // password: '9UvUf7@ATot2',
      // database: 'musicow_point',

      host: process.env.DATABASE_HOST,
      port: 3306,
      username: process.env.DATABASE_USER,
      password: process.env.DATABASE_PASSWORD,
      database: process.env.DATABASE_NAME,

      timezone: 'Z',
      retryAttempts: 3,
      dateStrings: true,
      entities: [
        TbMngrMastr,
        TbPointPool,
        TbPointEvent,
        TbServiceOperInfo,
        TbServiceOperLog,
        TbPointEventDtls,
        TbUserPoint,
        TbPointPoolSchedule,
        TbPointCheck,
      ],
      synchronize: false, // false로 해두는 게 안전하다.
      logging: true,
    }),
    TypeOrmModule.forFeature([
      TbMngrMastr,
      TbPointPool,
      TbPointEvent,
      TbServiceOperInfo,
      TbServiceOperLog,
      TbPointEventDtls,
      TbUserPoint,
      TbPointPoolSchedule,
      TbPointCheck,

    ]),

    // TypeOrmModule.forFeature([ TbPointPoolDtls]),
  ],

  controllers: [
    AppController,
    AuthController,
    PointController,
    PointpoolController,
  ],
  providers: [
    AppService,
    AuthService,
    JwtService,
    ConfigService,
    PointService,
    PointUseService,
    PointpoolService,
    PointSaveService,
    PointCancelService,
    PointRecallService,
    PointSettleService,
    PointEventService,
  ],
})
export class AppModule {
  configure(consumer: MiddlewareConsumer) {
    consumer.apply(LoggerMiddleware).forRoutes('');

  }
}
